-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le : ven. 11 mars 2022 à 17:11
-- Version du serveur :  8.0.21
-- Version de PHP : 7.4.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `fablabsaga`
--
CREATE DATABASE IF NOT EXISTS `fablabsaga` DEFAULT CHARACTER SET utf8 COLLATE utf8_unicode_ci;
USE `fablabsaga`;

-- --------------------------------------------------------

--
-- Structure de la table `adherent`
--

DROP TABLE IF EXISTS `adherent`;
CREATE TABLE IF NOT EXISTS `adherent` (
  `IDADHERENT` smallint NOT NULL AUTO_INCREMENT,
  `NOM` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `PRENOM` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `TELEPHONE` text NOT NULL,
  `EMAIL` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `DATENAISSANCE` date NOT NULL,
  `IDENTIFIANTCONNEXION` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `PWDCONNEXION` text CHARACTER SET utf8 COLLATE utf8_unicode_ci,
  `MONTANTCREDITS` float NOT NULL DEFAULT '0',
  `DATE_CREATION_COMPTE` date DEFAULT NULL,
  `DATE_OUVERTURE_ABONNEMENT` date DEFAULT NULL,
  `DATE_FIN_ABONNEMENT` date DEFAULT NULL,
  PRIMARY KEY (`IDADHERENT`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `adherent`
--

INSERT INTO `adherent` (`IDADHERENT`, `NOM`, `PRENOM`, `TELEPHONE`, `EMAIL`, `DATENAISSANCE`, `IDENTIFIANTCONNEXION`, `PWDCONNEXION`, `MONTANTCREDITS`, `DATE_CREATION_COMPTE`, `DATE_OUVERTURE_ABONNEMENT`, `DATE_FIN_ABONNEMENT`) VALUES
(1, 'Stac', 'quentin', '32767', 'quentin.stac@live.fr', '2021-08-15', 'essai', 'motdepasse', -574.15, '2021-10-06', '2021-08-15', '2022-10-06'),
(11, 'NomExemple', 'PrenomExemple', '0606060606', 'exemple@truc.com', '1981-06-09', 'NomExemplePrenomExemple61994', 'a9d8c783a2d74aa69484bbd8a7f32beeef4b481add98b639fe526f63852b1a1d', 145, '2021-10-31', '2022-10-31', '2023-10-31'),
(12, 'unnommm', 'unprenom', '0606060606', 'uneadresse@truc.com', '1985-08-11', 'unnomunprenom81985', '7fffcd7a8b9486f00732520c67c0a3e564603c123a5028575b48b7897521bfe1', -156, '2021-11-03', '2021-12-22', '2024-11-03'),
(13, 'sparrow', 'jack', '0606060606', 'jack@live.fr', '1995-08-17', 'sparrowjack81995', '6bf7d241f953461d99d01565cf2f73d7ee82ccb857bf0813833331fcc6d109a8', 135, '2021-12-15', '2021-12-22', '2024-12-15'),
(14, 'Tourres', 'Baptiste', '0781444721', 'baptiste.tourres@gmail.com', '2002-03-08', 'TourresBaptiste32002', '3356c65c8ef0d17d85e162178bdc4c5167d2b68bca67ac8607da4bf2cbdb82b4', 0, '2022-02-07', '2022-02-07', '2023-02-07'),
(7, 'cullet', 'victor', '6', 'victor@truc.com', '2001-03-15', 'culletvictor32001', '8546e80145bd97f92d0648fa81e73e2673a8984127377e062358b6894152f6ca', -27.85, '2021-10-21', '2021-10-21', '2022-10-21'),
(8, 'Etienne', 'aurélien', '0606060606', 'auré@truc.com', '2001-05-06', 'jesaispasaurélien92001', '2218e8421aa8b4922a29ecf5a1e47ea275d839b16c2a756b8b2d087da648a157', 997.15, '2021-10-21', '2021-10-21', '2022-10-21'),
(10, 'doisnel', 'thibaut', '0606060606', 'thibaut@machin.com', '1998-05-07', 'doisnelthibaut51998', '13558e3e32ad4b1ed9bbb628d10626403ac34804e8c1f267206f512cad1aa83d', -1625, '2021-10-30', '2021-10-30', '2022-10-30');

--
-- Déclencheurs `adherent`
--
DROP TRIGGER IF EXISTS `before_insert_adherent`;
DELIMITER $$
CREATE TRIGGER `before_insert_adherent` BEFORE INSERT ON `adherent` FOR EACH ROW BEGIN
set new.identifiantconnexion = concat(new.nom, new.prenom, month(new.DATENAISSANCE), year(new.DATENAISSANCE));
IF new.pwdconnexion IS null 
THEN set new.pwdconnexion = SHA2(new.identifiantconnexion, '256'); 
END IF;
set new.date_creation_compte = now();
set new.date_ouverture_abonnement = now();
set new.DATE_FIN_ABONNEMENT = new.DATE_OUVERTURE_ABONNEMENT + interval '1' year; 
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Structure de la table `consommable`
--

DROP TABLE IF EXISTS `consommable`;
CREATE TABLE IF NOT EXISTS `consommable` (
  `IDCONSOMMABLE` int NOT NULL AUTO_INCREMENT,
  `IDTYPECONSOMMABLE` int NOT NULL,
  `IDSOUSTYPECONSOMMABLE` int NOT NULL,
  `LIBELLE` char(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `PRIX` float(10,2) NOT NULL,
  PRIMARY KEY (`IDCONSOMMABLE`),
  KEY `FK_MATERIEL_TYPEMATERIEL` (`IDTYPECONSOMMABLE`)
) ENGINE=MyISAM AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `consommable`
--

INSERT INTO `consommable` (`IDCONSOMMABLE`, `IDTYPECONSOMMABLE`, `IDSOUSTYPECONSOMMABLE`, `LIBELLE`, `PRIX`) VALUES
(1, 2, 1, 'PLA Classique', 0.05),
(2, 2, 1, 'PLA Bois(15%)', 0.30),
(3, 2, 2, 'ABS Classique', 0.30),
(4, 3, 4, 'Contre plaqué', 10.00),
(5, 3, 5, 'Métal fin', 20.00),
(6, 4, 3, 'Kit découverte Arduino', 35.00),
(7, 4, 3, 'Kit découverte Raspberry', 50.00),
(8, 5, 6, 'PC Modélisation 3D', 4.00),
(9, 5, 7, 'PC Classique', 1.00),
(10, 4, 3, 'Kit avancé Arduino', 55.00),
(11, 1, 8, 'Utilisation atelier électronique', 5.00),
(12, 2, 1, 'PLA Noir', 0.05),
(15, 2, 1, 'PLA jaune', 0.50),
(14, 6, 10, 'Résine HT blanc Mate', 0.50),
(17, 2, 11, 'unNouveauTest', 0.56);

-- --------------------------------------------------------

--
-- Structure de la table `consommable_prestation`
--

DROP TABLE IF EXISTS `consommable_prestation`;
CREATE TABLE IF NOT EXISTS `consommable_prestation` (
  `IDPRESTATION` int NOT NULL,
  `IDCONSOMMABLE` int NOT NULL,
  `LIBELLE` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `QUANTITE` float(10,0) NOT NULL,
  `MONTANT` float(10,0) NOT NULL DEFAULT '0',
  PRIMARY KEY (`IDPRESTATION`,`IDCONSOMMABLE`),
  KEY `FK_MATERIEL_PRESTATION_MATERIEL` (`IDCONSOMMABLE`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `consommable_prestation`
--

INSERT INTO `consommable_prestation` (`IDPRESTATION`, `IDCONSOMMABLE`, `LIBELLE`, `QUANTITE`, `MONTANT`) VALUES
(1, 1, '', 250, 13),
(1, 2, '', 30, 9),
(1, 3, '', 15, 3),
(17, 1, 'test', 150, 8),
(18, 1, 'support', 150, 8),
(18, 3, 'socle', 350, 70),
(36, 4, 'tytyt', 50, 500),
(21, 1, 'tyty', 45, 2),
(24, 1, 'rtrtr', 150, 8),
(24, 3, 'test trigger', 1, 0),
(24, 2, 'hghg', 1, 0),
(26, 10, 'hh', 2, 110),
(26, 1, 'ff', 25, 1),
(53, 4, 'un essai', 5, 50),
(31, 1, 'azazaz', 150, 8),
(41, 2, 'test grosse piece', 500, 150),
(35, 3, 'fgfgf', 45, 9),
(42, 3, 'ma premiere création', 150, 30),
(42, 2, 'efef', 50, 15),
(43, 14, 'essai', 10, 5),
(44, 2, 'unessai', 150, 45),
(44, 3, 'unautreessai', 250, 62),
(46, 17, 'un de plus', 150, 84),
(48, 4, 'test', 2, 20),
(49, 3, 'test', 50, 12),
(50, 11, 'test', 50, 250),
(51, 5, 'autre test', 50, 1000),
(52, 5, 'ererer', 10, 200),
(54, 2, 'un essai', 50, 15),
(54, 7, 'wouaa', 45, 2250),
(55, 8, 'essai maquette', 10, 40),
(56, 11, 'jhjhj', 45, 225);

--
-- Déclencheurs `consommable_prestation`
--
DROP TRIGGER IF EXISTS `before_delete_consommable_prestation`;
DELIMITER $$
CREATE TRIGGER `before_delete_consommable_prestation` BEFORE DELETE ON `consommable_prestation` FOR EACH ROW BEGIN
UPDATE prestation SET montanttotal = montanttotal - (old.quantite * (select prix from consommable where idconsommable = old.idconsommable)) WHERE IDPRESTATION = old.idprestation;

END
$$
DELIMITER ;
DROP TRIGGER IF EXISTS `before_insert_consommable_prestation`;
DELIMITER $$
CREATE TRIGGER `before_insert_consommable_prestation` BEFORE INSERT ON `consommable_prestation` FOR EACH ROW BEGIN
UPDATE prestation SET montanttotal = montanttotal + (new.quantite * (select prix from consommable where IDCONSOMMABLE = new.idconsommable)) WHERE IDPRESTATION = new.idprestation;

SET new.montant = new.quantite * (select prix from consommable where idconsommable = new.idconsommable);
END
$$
DELIMITER ;
DROP TRIGGER IF EXISTS `before_update_consommable_prestation`;
DELIMITER $$
CREATE TRIGGER `before_update_consommable_prestation` BEFORE UPDATE ON `consommable_prestation` FOR EACH ROW BEGIN
UPDATE prestation SET montanttotal = montanttotal - (old.quantite * (select prix from consommable where idconsommable = old.idconsommable)) WHERE IDPRESTATION = old.idprestation;

UPDATE prestation SET montanttotal = montanttotal + (new.quantite * (select prix from consommable where idconsommable = new.idconsommable)) WHERE IDPRESTATION = new.idprestation;

SET new.montant = new.quantite * (select prix from consommable where idconsommable = new.idconsommable);
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Structure de la table `moyen_paiement`
--

DROP TABLE IF EXISTS `moyen_paiement`;
CREATE TABLE IF NOT EXISTS `moyen_paiement` (
  `idMoyenPaiement` int NOT NULL AUTO_INCREMENT,
  `codeMoyenPaiement` text COLLATE utf8_unicode_ci NOT NULL,
  `nomMoyenPaiement` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`idMoyenPaiement`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Déchargement des données de la table `moyen_paiement`
--

INSERT INTO `moyen_paiement` (`idMoyenPaiement`, `codeMoyenPaiement`, `nomMoyenPaiement`) VALUES
(1, 'ESP', 'Espèces'),
(2, 'CB', 'Carte Bancaire'),
(3, 'CHQ', 'Chèque'),
(4, 'AVR', 'Avoir');

-- --------------------------------------------------------

--
-- Structure de la table `prestation`
--

DROP TABLE IF EXISTS `prestation`;
CREATE TABLE IF NOT EXISTS `prestation` (
  `IDPRESTATION` int NOT NULL AUTO_INCREMENT,
  `IDTYPEPRESTATION` int NOT NULL,
  `IDADHERENT` int NOT NULL,
  `DATE` datetime NOT NULL,
  `MONTANTTOTAL` float(10,0) NOT NULL DEFAULT '0',
  `LIBELLE` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`IDPRESTATION`),
  KEY `FK_PRESTATION_TYPEPRESTATION` (`IDTYPEPRESTATION`),
  KEY `FK_PRESTATION_ADHERENT` (`IDADHERENT`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=57 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `prestation`
--

INSERT INTO `prestation` (`IDPRESTATION`, `IDTYPEPRESTATION`, `IDADHERENT`, `DATE`, `MONTANTTOTAL`, `LIBELLE`) VALUES
(1, 1, 1, '2021-09-18 00:00:00', 674, ''),
(17, 1, 7, '2021-10-27 14:23:31', 8, 'StarGate'),
(52, 2, 10, '2021-12-14 12:39:32', 200, 'SansNom'),
(42, 1, 10, '2021-10-30 14:17:32', 45, 'mon projet'),
(49, 2, 7, '2021-12-14 10:57:28', 12, 'SansNom'),
(21, 1, 7, '2021-10-21 10:16:37', 2, 'SansNom'),
(48, 3, 7, '2021-12-14 10:54:21', 20, 'SansNom'),
(47, 2, 7, '2021-12-14 10:51:09', 0, 'SansNom'),
(24, 1, 7, '2021-07-27 15:21:50', 8, 'SansNom'),
(46, 1, 12, '2021-11-03 15:47:02', 84, 'SansNom'),
(44, 1, 12, '2021-11-03 15:36:30', 107, 'mon premier projet'),
(43, 1, 10, '2021-10-31 11:00:21', 5, 'SansNom'),
(53, 2, 10, '2021-12-20 16:02:17', 50, 'SansNom'),
(31, 1, 7, '2021-02-27 16:43:41', 8, 'SansNom'),
(51, 1, 7, '2021-12-14 11:02:49', 1000, 'un test'),
(41, 1, 7, '2021-10-30 11:08:13', 150, 'prejet test'),
(50, 3, 7, '2021-12-14 10:59:15', 250, 'SansNom'),
(54, 2, 10, '2021-12-20 16:54:25', 2265, 'mmmh'),
(55, 5, 8, '2021-12-21 17:58:32', 40, 'SansNom'),
(56, 4, 10, '2021-12-22 16:46:41', 225, 'SansNom');

--
-- Déclencheurs `prestation`
--
DROP TRIGGER IF EXISTS `before_delete_prestation`;
DELIMITER $$
CREATE TRIGGER `before_delete_prestation` BEFORE DELETE ON `prestation` FOR EACH ROW BEGIN
UPDATE adherent set montantcredits = montantcredits + old.montanttotal where adherent.IDADHERENT = old.IDADHERENT;
END
$$
DELIMITER ;
DROP TRIGGER IF EXISTS `before_update_prestation`;
DELIMITER $$
CREATE TRIGGER `before_update_prestation` BEFORE UPDATE ON `prestation` FOR EACH ROW BEGIN
UPDATE adherent set montantcredits = montantcredits + old.montanttotal where adherent.IDADHERENT = new.IDADHERENT;
update ADHERENT set montantCredits = montantcredits - new.montanttotal where adherent.IDADHERENT = new.IDADHERENT;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Structure de la table `rechargement`
--

DROP TABLE IF EXISTS `rechargement`;
CREATE TABLE IF NOT EXISTS `rechargement` (
  `IDADHERENT` smallint NOT NULL,
  `DATE` datetime NOT NULL,
  `NBCREDIT` bigint NOT NULL,
  `idMoyenPaiement` int NOT NULL,
  `MontantEuro` float NOT NULL,
  `libelle` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  PRIMARY KEY (`IDADHERENT`,`DATE`),
  KEY `FK_IDMOYENPAIEMENT` (`idMoyenPaiement`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `rechargement`
--

INSERT INTO `rechargement` (`IDADHERENT`, `DATE`, `NBCREDIT`, `idMoyenPaiement`, `MontantEuro`, `libelle`) VALUES
(8, '2021-10-28 10:29:09', 40, 1, 0, ''),
(1, '2021-09-18 11:45:43', 10, 1, 0, ''),
(1, '2021-10-06 10:14:17', 300, 1, 0, ''),
(7, '2021-10-30 11:06:00', 500, 1, 0, ''),
(1, '2021-09-18 11:48:20', 5, 1, 0, ''),
(7, '2021-10-28 10:32:07', 250, 1, 0, ''),
(8, '2021-10-28 11:24:44', 100, 1, 0, ''),
(10, '2021-10-30 14:15:37', 40, 1, 0, ''),
(10, '2021-10-31 11:38:59', 40, 1, 0, ''),
(8, '2021-11-15 13:09:14', 100, 1, 0, ''),
(13, '2021-12-15 10:57:22', 100, 1, 0, ''),
(8, '2021-12-15 11:29:17', 200, 1, 0, ''),
(8, '2021-12-15 11:31:56', 100, 1, 0, ''),
(0, '0000-00-00 00:00:00', 35, 5, 0, ''),
(0, '2021-12-15 16:01:05', 35, 5, 0, ''),
(1, '2021-12-15 17:20:24', 50, 1, 100, ''),
(10, '2021-12-21 15:31:37', 300, 1, 150, ''),
(10, '2021-12-21 15:32:31', 400, 1, 200, ''),
(10, '2021-12-21 16:16:02', 100, 1, 50, ''),
(10, '2021-12-21 17:16:04', 100, 1, 50, 'Achat de crédits'),
(8, '2021-12-21 17:55:43', 1000, 1, 500, 'Achat de crédits'),
(8, '2021-12-21 17:56:01', 15, 4, 7.5, 'crédits offerts'),
(11, '2021-12-21 18:16:17', 10, 3, 5.1, 'Achat de crédits'),
(11, '2021-12-21 18:47:27', 100, 1, 50, 'Achat de crédits'),
(7, '2021-12-22 11:37:41', 60, 1, 30, 'Achat de crédits'),
(7, '2021-12-22 11:37:51', 180, 2, 90, 'Achat de crédits'),
(7, '2021-12-22 11:38:01', 112, 3, 56, 'Achat de crédits'),
(7, '2021-12-22 11:38:13', 35, 4, 17.5, 'Crédits offerts'),
(7, '2021-12-22 11:39:43', 1000, 2, 500, 'Achat de crédits'),
(8, '2021-12-22 15:20:21', 10, 1, 5, 'Achat de crédits'),
(13, '2021-12-22 15:16:03', 35, 1, 6, 'Prime d\'abonnement'),
(10, '2022-02-07 16:42:56', 150, 2, 75, 'Achat de crédits');

--
-- Déclencheurs `rechargement`
--
DROP TRIGGER IF EXISTS `after_delete_rechargement`;
DELIMITER $$
CREATE TRIGGER `after_delete_rechargement` AFTER DELETE ON `rechargement` FOR EACH ROW BEGIN
UPDATE ADHERENT SET montantCredits = montantCredits - old.nbCredit WHERE IDADHERENT = old.idADHERENT;
END
$$
DELIMITER ;
DROP TRIGGER IF EXISTS `after_insert_rechargement`;
DELIMITER $$
CREATE TRIGGER `after_insert_rechargement` AFTER INSERT ON `rechargement` FOR EACH ROW BEGIN
UPDATE ADHERENT SET montantCredits = montantCredits + new.nbCredit WHERE IDADHERENT = new.idADHERENT;
END
$$
DELIMITER ;
DROP TRIGGER IF EXISTS `after_update_rechargement`;
DELIMITER $$
CREATE TRIGGER `after_update_rechargement` AFTER UPDATE ON `rechargement` FOR EACH ROW BEGIN
UPDATE ADHERENT SET montantCredits = montantCredits - old.nbCredit WHERE IDADHERENT = old.idADHERENT;
UPDATE ADHERENT SET montantCredits = montantCredits + new.nbCredit WHERE IDADHERENT = new.idADHERENT;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Structure de la table `sous_type_consommable`
--

DROP TABLE IF EXISTS `sous_type_consommable`;
CREATE TABLE IF NOT EXISTS `sous_type_consommable` (
  `IDSOUSTYPECONSOMMABLE` int NOT NULL AUTO_INCREMENT,
  `IDTYPECONSOMMABLE` int NOT NULL,
  `LIBELLE` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`IDSOUSTYPECONSOMMABLE`),
  KEY `fk_typeconsommable` (`IDTYPECONSOMMABLE`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Déchargement des données de la table `sous_type_consommable`
--

INSERT INTO `sous_type_consommable` (`IDSOUSTYPECONSOMMABLE`, `IDTYPECONSOMMABLE`, `LIBELLE`) VALUES
(1, 2, 'PLA'),
(2, 2, 'ABS'),
(3, 4, 'KIT'),
(4, 3, 'BOIS'),
(5, 3, 'MÉTAL'),
(6, 5, 'PC de modélisation'),
(7, 5, 'PC ordinaire'),
(8, 1, 'Utilisation atelier'),
(10, 6, 'Haute Température'),
(11, 2, 'PET'),
(12, 6, 'Haute performance');

-- --------------------------------------------------------

--
-- Structure de la table `typeconsommable`
--

DROP TABLE IF EXISTS `typeconsommable`;
CREATE TABLE IF NOT EXISTS `typeconsommable` (
  `IDTYPECONSOMMABLE` int NOT NULL AUTO_INCREMENT,
  `TYPE` char(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `UNITE` char(32) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `idTypePrestation` int NOT NULL,
  PRIMARY KEY (`IDTYPECONSOMMABLE`),
  KEY `FK_IDTYPEPRESTATION` (`idTypePrestation`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `typeconsommable`
--

INSERT INTO `typeconsommable` (`IDTYPECONSOMMABLE`, `TYPE`, `UNITE`, `idTypePrestation`) VALUES
(1, 'Utilisation atelier électronique', 'heures', 4),
(2, 'Filament', 'grammes', 1),
(3, 'Matière à découpe laser', 'M²', 2),
(4, 'Consommables électroniques', 'unités', 3),
(5, 'Utilisation postes informatique', 'heures', 5),
(6, 'Résine', 'grammes', 1);

-- --------------------------------------------------------

--
-- Structure de la table `typeprestation`
--

DROP TABLE IF EXISTS `typeprestation`;
CREATE TABLE IF NOT EXISTS `typeprestation` (
  `IDTYPEPRESTATION` int NOT NULL AUTO_INCREMENT,
  `NOMPRESTATION` char(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`IDTYPEPRESTATION`)
) ENGINE=MyISAM AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `typeprestation`
--

INSERT INTO `typeprestation` (`IDTYPEPRESTATION`, `NOMPRESTATION`) VALUES
(1, 'Impression 3D'),
(2, 'Découpe laser'),
(3, 'Utilisation pièces électroniques'),
(4, 'Atelier électronique'),
(5, 'Postes informatiques'),
(6, 'Adhésion 12 Mois');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
