﻿using fablab_saga.controleur;
using fablab_saga.model;
using fablab_saga.vue.ControleUtilisateur;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace fablab_saga.vue
{
    public partial class FrmPrincipal : Form
    {
        #region Instances des UserControl

        /// <summary>
        /// Instance du UserControl usrcAjoutAdherent
        /// </summary>
        private UsrcAjoutAdherent usrcAjoutAdherent;

        /// <summary>
        /// Instance du UserControl usrcAjoutConsommable
        /// </summary>
        private UsrcAjoutConsommable usrcAjoutConsommable;

        /// <summary>
        /// Instance du UserControl usrcAuthentification
        /// </summary>
        private UsrcAuthentification usrcAuthentification;

        /// <summary>
        /// Instance du UserControl usrcConsultationAdherent
        /// </summary>
        private UsrcConsultationAdherent usrcConsultationAdherent;

        /// <summary>
        /// Instance du UserControl usrcConsulterTypesPrestations
        /// </summary>
        private UsrcConsulterTypesPrestations usrcConsulterTypesPrestations;

        /// <summary>
        /// Instance du UserControl usrcHistoriqueCredits
        /// </summary>
        private UsrcHistorique usrcHistorique;

        /// <summary>
        /// Instance du UserControl urscMenu
        /// </summary>
        private UsrcMenu usrcMenu;

        /// <summary>
        /// Instance du UserControl usrcMenuAdministrateur
        /// </summary>
        private UsrcMenuAdministrateur usrcMenuAdministrateur;

        /// <summary>
        /// Instance du UserControl usrcModifierConsommable
        /// </summary>
        private UsrcModifierConsommable usrcModifierConsommable;

        /// <summary>
        /// Instance du UserControl usrcNouvellePrestation
        /// </summary>
        private UsrcNouvellePrestation usrcNouvellePrestation;

        /// <summary>
        /// Instance du UserControl usrcRechercheAdherent
        /// </summary>
        private UsrcRechercheAdherent usrcRechercheAdherent;

        /// <summary>
        /// Instance du UserControl usrcRechercherConsommable
        /// </summary>
        private UsrcRechercherConsommable usrcRechercherConsommable;
        /// <summary>
        /// Instance du UserControl usrcRechargerCredits
        /// </summary>
        private UsrcRechargerCredits usrcRechargerCredits;
        private UsrcChargement usrcChargement;

        #endregion
        #region Propriétés Privée
        /// <summary>
        /// Instance du controleur
        /// </summary>
        private Controle controle;
        /// <summary>
        /// Permet de mémoriser l'identifiant utilisé
        /// </summary>
        private string identifiant;
        
        #endregion
        /// <summary>
        /// Le contructeur
        /// </summary>
        /// <param name="controle">Instance de controle</param>
        public FrmPrincipal(Controle controle)
        {
            this.controle = controle;
            InitializeComponent();
        }
        #region Méthodes d'ouverture
        /// <summary>
        ///  Instanciation du usrcAuthentification au chargement du fomulaire
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void FrmPrincipal_Load(object sender, EventArgs e)
        {
            ConsUsrcAuthentification();
        }
        /// <summary>
        /// Permet d'envoyer les identifiants de connexion et de récupérer la réussite de connexion
        /// </summary>
        /// <param name="identifiant">l'identifiant saisie</param>
        /// <param name="pwd">le mot de passe saisie</param>
        public void Authentification(string identifiant, string pwd)
        {
            this.identifiant = identifiant;
            if (controle.Authentification(identifiant, pwd))
            {
                usrcAuthentification.Dispose();
                ConsUsrcMenu();
            }
            else
            {
                MessageBox.Show("Impossible de vous connecter.\n\n [Code erreur 1 : La base de données n'a pas répondu favorablerment]\n\nImpossible de vous connecter, " +
                            "vérifiez vous identifiant ou bien appeler l'administrateur de la base de données", "Une erreur est survenue", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        /// <summary>
        /// Permet de retourner sur l'id en paramètre exite dans la table en paremètre
        /// </summary>
        /// <param name="tableBdd">table de la base de données</param>
        /// <param name="idAVerifier">id à vrifier</param>
        /// <param name="nomId">nom de l'id</param>
        /// <returns>retourne la présence ou non de l'id</returns>
        public bool RecupIDTableBdd(string tableBdd, int idAVerifier, string nomId)
        {
            return controle.RecupIDTableBdd(tableBdd, idAVerifier, nomId);
        }
        /// <summary>
        /// Permet de retourner au menu lors de son appel par n'importe quel UserControl
        /// </summary>
        public void RetourMenu()
        {
            DisposeAll();
            ConsUsrcMenu();
        }
        /// <summary>
        /// Évenement de déconnexion depuis usrcMenu
        /// </summary>
        public void Deconnexion()
        {
            usrcMenu.Dispose();
            controle.Deconnexion();
            ConsUsrcAuthentification();
        }
        public void RetourMenuAdmin()
        {
            DisposeAll();
            ConsUsrcMenuAdministrateur();
        }
        /// <summary>
        /// Évenement de création du usrcAjoutAdherent
        /// </summary>
        public void CreationAjoutAdherent()
        {
            usrcMenu.Dispose();
            ConsUsrcAjoutAdherent();
        }
        /// <summary>
        /// Permet de fermer tous les UserControl exitant et de créer le usrcRechercheAdherent
        /// </summary>
        public void CreationRechercheAdherent()
        {
            DisposeAll();
            ConsUsrcRechercheAdherent();
        }
        /// <summary>
        /// Permet de fermer le userControl ayant initialisé et de lancer la méthode d'ouverture du usrcConsultationAdherent
        /// </summary>
        /// <param name="unAdherent"></param>
        public void CreationConsultationAdherent(Adherents unAdherent)
        {
            DisposeAll();
            ConsUsrcConsultationAdherent(unAdherent);
        }
        /// <summary>
        /// Permet de fermer le UserControl usrcConsultationAdherent et de lancer la méthode d'ouverture du UsrcNouvellePrestation
        /// </summary>
        /// <param name="unAdherent"></param>
        public void CreationNouvellePrestation(Adherents unAdherent)
        {
            usrcConsultationAdherent.Dispose();
            ConsUsrcNouvellePrestation(unAdherent);
        }
        /// <summary>
        /// Permet de fermer le UserControl usrcConsultationAdherent et de lancer la méthode d'ouverture du UsrcRechargerCredits
        /// </summary>
        /// <param name="unAdherents"></param>
        public void CreationRechargerCredits(Adherents unAdherents)
        {
            usrcConsultationAdherent.Dispose();
            ConsUsrcRechargerCredits(unAdherents);
        }
        /// <summary>
        /// Permet de fermer le UserControl usrcConsultationAdherent et de lancer la méthode d'ouverture du UsrcHistorique
        /// </summary>
        /// <param name="unAdherent"></param>
        public void CreationHistorique(Adherents unAdherent)
        {
            usrcConsultationAdherent.Dispose();
            ConsUsrcHistorique(unAdherent);
        }
        /// <summary>
        /// Permet de fermer le UserControl usrcMenu et de lancer la méthode d'ouverture du UsrcMenuAdministrateur
        /// </summary>
        public void CreationMenuAdministrateur()
        {
            usrcMenu.Dispose();
            ConsUsrcMenuAdministrateur();
        }
        /// <summary>
        /// Permet de fermer le UserControl usrcMenuAdministrateur et de lancer la méthode d'ouverture du UsrcConsulterTypesPrestations
        /// </summary>
        public void CreationConsultationTypePrestation()
        {
            usrcMenuAdministrateur.Dispose();
            ConsUsrcConsulterTypesPrestations();
        }
        /// <summary>
        /// Permet de fermer le UserControl UsrcMenuAdministrateur et de lancer la méthode d'ouverture du UsrcAjoutConsommable
        /// </summary>
        public void CreationAjoutModificationConsommable()
        {
            DisposeAll();
            ConsUsrcAjoutModificationConsommable();
        }
        /// <summary>
        /// Permet de fermer le UserControl UsrcMenuAdministrateur et de lancer la méthode d'ouverture du UsrcAjoutConsommable
        /// </summary>
        public void CreationAjoutModificationConsommable(Consommable unConsommable)
        {
            DisposeAll();
            ConsUsrcAjoutModificationConsommable(unConsommable);
        }
        /// <summary>
        /// Permet de fermer le UserControl UsrcMenuAdministrateur et de lancer la méthode d'ouverture du UsrcRechercherConsommable
        /// </summary>
        public void CreationRechercheConsommable()
        {
            usrcMenuAdministrateur.Dispose();
            ConsUsrcRechercherConsommables();
        }
        #endregion
        #region Méthodes de constructions des UserControl

        /// <summary>
        /// Construction du UsrcAuthentification
        /// </summary>
        private void ConsUsrcAuthentification()
        {
            usrcAuthentification = new UsrcAuthentification(this);
            usrcAuthentification.Location = new Point(0, 0);
            this.Controls.Add(usrcAuthentification);
            usrcAuthentification.Show();
        }
        /// <summary>
        /// Construction du UsrcMenu
        /// </summary>
        private void ConsUsrcMenu()
        {
            usrcMenu = new UsrcMenu(this, identifiant);
            usrcMenu.Location = new Point(0, 0);
            this.Controls.Add(usrcMenu);
            usrcMenu.Show();
        }
        /// <summary>
        /// Construction du UsrcAjoutAdherent
        /// </summary>
        private void ConsUsrcAjoutAdherent()
        {
            usrcAjoutAdherent = new UsrcAjoutAdherent(this, identifiant);
            usrcAjoutAdherent.Location = new Point(0, 0);
            this.Controls.Add(usrcAjoutAdherent);
        }
        /// <summary>
        /// Construction du UsrcChargement
        /// </summary>
        private void ConsUsrcChargement()
        {
            usrcChargement = new UsrcChargement();
            usrcChargement.Location = new Point(0, 0);
            this.Controls.Add(usrcChargement);
        }
        /// <summary>
        /// Construction du UsrcRechercheAdherent
        /// </summary>
        private void ConsUsrcRechercheAdherent()
        {
            usrcRechercheAdherent = new UsrcRechercheAdherent(this);
            usrcRechercheAdherent.Location = new Point(0, 0);
            this.Controls.Add(usrcRechercheAdherent);
        }
        /// <summary>
        /// Construction du UsrcConsultationAdherent
        /// </summary>
        /// <param name="unAdherent">l'adherent à consulter</param>
        private void ConsUsrcConsultationAdherent(Adherents unAdherent)
        {
            usrcConsultationAdherent = new UsrcConsultationAdherent(this, unAdherent, identifiant);
            usrcConsultationAdherent.Location = new Point(0, 0);
            this.Controls.Add(usrcConsultationAdherent);
        }
        /// <summary>
        /// Construction du UsrcNouvellePrestation
        /// </summary>
        /// <param name="unAdherent">l'adherent à qui ajouter une prestation</param>
        private void ConsUsrcNouvellePrestation(Adherents unAdherent)
        {
            usrcNouvellePrestation = new UsrcNouvellePrestation(this, unAdherent, identifiant);
            usrcNouvellePrestation.Location = new Point(0, 0);
            this.Controls.Add(usrcNouvellePrestation);
        }
        /// <summary>
        /// Construction du UsrcRechargerCredits
        /// </summary>
        /// <param name="unAdherent">l'adherent à qui recharger les credits</param>
        private void ConsUsrcRechargerCredits(Adherents unAdherent)
        {
            usrcRechargerCredits = new UsrcRechargerCredits(this, unAdherent, identifiant);
            usrcRechargerCredits.Location = new Point(0, 0);
            this.Controls.Add(usrcRechargerCredits);
        }
        /// <summary>
        /// Construction du UsrcHistorique
        /// </summary>
        /// <param name="unAdherent">l'adherent à qui appartient l'historique</param>
        private void ConsUsrcHistorique(Adherents unAdherent)
        {
            usrcHistorique = new UsrcHistorique(this, unAdherent, identifiant);
            usrcHistorique.Location = new Point(0, 0);
            this.Controls.Add(usrcHistorique);
        }
        /// <summary>
        /// Construction du UsrcMenuAdministrateur
        /// </summary>
        private void ConsUsrcMenuAdministrateur()
        {
            usrcMenuAdministrateur = new UsrcMenuAdministrateur(this, identifiant);
            usrcMenuAdministrateur.Location = new Point(0, 0);
            this.Controls.Add(usrcMenuAdministrateur);
        }
        /// <summary>
        /// Construction du UsrcMenuAdministrateur
        /// </summary>
        private void ConsUsrcConsulterTypesPrestations()
        {
            usrcConsulterTypesPrestations = new UsrcConsulterTypesPrestations(this, identifiant);
            usrcConsulterTypesPrestations.Location = new Point(0, 0);
            this.Controls.Add(usrcConsulterTypesPrestations);
        }
        /// <summary>
        /// Construction du UsrcMenuAdministrateur
        /// </summary>
        private void ConsUsrcAjoutModificationConsommable()
        {
            usrcAjoutConsommable = new UsrcAjoutConsommable(this, identifiant);
            usrcAjoutConsommable.Location = new Point(0, 0);
            this.Controls.Add(usrcAjoutConsommable);
        }
        /// <summary>
        /// Construction du UsrcMenuAdministrateur
        /// </summary>
        private void ConsUsrcAjoutModificationConsommable(Consommable unConsommable)
        {
            usrcAjoutConsommable = new UsrcAjoutConsommable(this, identifiant, unConsommable);
            usrcAjoutConsommable.Location = new Point(0, 0);
            this.Controls.Add(usrcAjoutConsommable);
        }
        /// <summary>
        /// Construction du UsrcMenuAdministrateur
        /// </summary>
        private void ConsUsrcRechercherConsommables()
        {
            usrcRechercherConsommable = new UsrcRechercherConsommable(this);
            usrcRechercherConsommable.Location = new Point(0, 0);
            this.Controls.Add(usrcRechercherConsommable);
        }
        /// <summary>
        /// Permet de dispose() tous les UserControl ouvert 
        /// </summary>
        private void DisposeAll()
        {
            UserControl[] ensembeUserControl = {
                usrcAjoutAdherent,
                usrcAjoutConsommable,
                usrcAuthentification,
                usrcConsultationAdherent,
                usrcConsulterTypesPrestations,
                usrcHistorique,
                usrcMenu,
                usrcMenuAdministrateur,
                usrcModifierConsommable,
                usrcNouvellePrestation,
                usrcRechercheAdherent,
                usrcRechercherConsommable,
                usrcRechargerCredits
            };
            foreach (UserControl user in ensembeUserControl)
            {
                if (user != null)
                {
                    user.Dispose();
                }
            }
        }
        #endregion
        #region Fonction de récupération
        /// <summary>
        /// Permet de récupérer et d'envoyer la liste des adhérents
        /// </summary>
        public List<Adherents> GetLesAdherent()
        {
            return controle.GetLesAdherents();
        }
        /// <summary>
        /// Permet de récupérer et d'envoyer la liste des TypePrestation
        /// </summary>
        /// <returns></returns>
        public List<TypePrestation> GetLesTypesPrestations()
        {
            return controle.GetLesTypesPrestations();
        }
        /// <summary>
        /// Permet de récupérer et d'envoyer la liste des TypeConsommables
        /// </summary>
        /// <returns></returns>
        public List<TypeConsommable> GetLesTypesConsommables()
        {
            return controle.GetLesTypesConsommables();
        }
        /// <summary>
        /// Permet de récupérer et d'envoyer la liste des SousTypeConsommables
        /// </summary>
        /// <returns></returns>
        public List<SousTypeConsommable> GetLesSousTypesConsommables()
        {
            return controle.GetLesSousTypesConsommables();
        }
        /// <summary>
        /// Permet de récupérer et d'envoyer la liste des consommables
        /// </summary>
        /// <returns></returns>
        public List<Consommable> GetLesConsommables()
        {
            return controle.GetLesConsommables();
        }
        /// <summary>
        /// Permet de récupérer et d'envoyer les rechargements d'un adherent
        /// </summary>
        /// <param name="idAdherent"></param>
        /// <returns></returns>
        public List<Object> GetLesRechargements(int idAdherent, string dateTrie)
        {
            return controle.GetLesRechargements(idAdherent, dateTrie);
        }
        /// <summary>
        /// Permet de récupérer et d'envoyer les prestations d'un adherent
        /// </summary>
        /// <param name="idAdherent"></param>
        /// <returns></returns>
        public List<Object> GetLesPrestations(int idAdherent, string dateTrie)
        {
            return controle.GetLesPrestations(idAdherent, dateTrie);
        }
        /// <summary>
        /// Permet de récuparer une prestation avec l'idAdherent et la datePrestation reçu en paramètres
        /// </summary>
        /// <param name="idAdherent">id de l'adherent</param>
        /// <param name="datePrestation">date de la prestation</param>
        /// <returns></returns>
        public Prestation RecupUnePrestation(int idAdherent, string datePrestation)
        {
            return controle.RecupUnePrestation(idAdherent, datePrestation);
        }
        /// <summary>
        /// Permet de récupérer et d'envoyer un adherent avec sont id
        /// </summary>
        /// <param name="idAdherent">id de l'adherent recherché</param>
        /// <returns></returns>
        public Adherents RecupUnAdherent(int idAdherent)
        {
            return controle.RecupUnAdherent(idAdherent);
        }
        /// <summary>
        /// Permet de récupérer et d'envoyer les consommables d'une prestation
        /// </summary>
        /// <param name="idPrestation"></param>
        /// <returns></returns>
        public List<ConsommablePrestation> GetLesConsommablePrestation(int idPrestation)
        {
            return controle.GetLesConsommablePrestation(idPrestation);
        }
        /// <summary>
        /// Permet de récupérer un type consommable avec son libelle et son unité
        /// </summary>
        /// <param name="LeTypeConsommable">le libelle du type</param>
        /// <param name="UniteConsommable">l'unite du type</param>
        /// <returns>le type</returns>
        public TypeConsommable RecupUnTypeConsommable(string LeTypeConsommable, string UniteConsommable)
        {
            return controle.RecupUnTypeConsommable(LeTypeConsommable, UniteConsommable);
        }
        /// <summary>
        /// Permet de récupérer un sous type de consommable
        /// </summary>
        /// <param name="IdTypeConsommable">id du type de consomamble</param>
        /// <param name="Libelle">son libelle</param>
        /// <returns>un sous type</returns>
        public SousTypeConsommable RecupUnSousTypeConsommable(int IdTypeConsommable, string Libelle)
        {
            return controle.RecupUnSousTypeConsommable(IdTypeConsommable, Libelle);
        }
        #endregion
        #region Méthode d'ajouts/Modifications
        /// <summary>
        /// Évenement d'ajout Adherent depuis le usrcAjoutAdherent
        /// </summary>
        /// <param name="nom">nom de l'adherent</param>
        /// <param name="prenom">prenom de l'adherent</param>
        /// <param name="telephone">telephone de l'adherent</param>
        /// <param name="email">email de l'adherent</param>
        /// <param name="dateNaissance">deta de naissance de l'adherent</param>
        public void AjoutAdherent(string nom, string prenom, string telephone, string email, DateTime dateNaissance)
        {
            controle.AjoutAdherent(nom, prenom, telephone, email, dateNaissance);
        }
        /// <summary>
        /// Permet d'envoyer une nouvelle prestation reçu en parametres au controle
        /// </summary>
        /// <param name="idTypePrestation">id du typePrestation</param>
        /// <param name="idAdherent">id de l'adherent</param>
        /// <param name="datePrestation">la date de la prestation</param>
        /// <param name="libelle">le libellé</param>
        public void AjoutNouvellePrestation(int idTypePrestation, int idAdherent, DateTime datePrestation, string libelle)
        {
            controle.AjoutNouvellePrestation(idTypePrestation, idAdherent, datePrestation, libelle);
        }
        /// <summary>
        /// Permet d'ajouter une liste de lignes à une prestation 
        /// </summary>
        /// <param name="lesLignes">les lignes qui vont etre ajouter</param>
        public void AjoutLignesPrestation(List<ConsommablePrestation> lesLignes)
        {
            controle.AjoutLignesPrestation(lesLignes);
        }
        /// <summary>
        /// Permet d'ajouter un rechargement 
        /// </summary>
        /// <param name="idAdherent">id de l'adherent rechargé</param>
        /// <param name="dateRechargement">le date du rechargement </param>
        /// <param name="montantCredit">le montant de credit rechargé</param>
        public void AjoutCredits(int idAdherent, DateTime dateRechargement, float montantCredit)
        {
            controle.AjoutCredits(idAdherent, dateRechargement, montantCredit);
        }
        /// <summary>
        /// Permet d'ajouter un type de prestation 
        /// </summary>
        /// <param name="libelle">le nom du nouveau type</param>
        public void AjouterUnTypePrestation(string libelle)
        {
            controle.AjouterUnTypePrestation(libelle);
        }
        /// <summary>
        /// Permet d'ajouter un nouveau type de consommable
        /// </summary>
        /// <param name="unTypeConsommable">le type consommable à ajouter</param>
        public void AjoutNewTypeConsommable(TypeConsommable unTypeConsommable)
        {
            controle.AjoutNewTypeConsommable(unTypeConsommable);
        }
        /// <summary>
        /// Permet d'ajouter un sous type de consommable
        /// </summary>
        /// <param name="unSousTypeConsommable">le sous type à ajouter</param>
        public void AjoutSousTypeConsommable(SousTypeConsommable unSousTypeConsommable)
        {
            controle.AjoutSousTypeConsommable(unSousTypeConsommable); 
        }
        /// <summary>
        /// Permet d'ajouter un consommable
        /// </summary>
        /// <param name="unConsommable">le consommable à ajouter</param>
        public void AjoutConsommable(Consommable unConsommable)
        {
            controle.AjoutConsommable(unConsommable);
        }
        /// <summary>
        /// Permet de d'envoyer un adherent modifié
        /// </summary>
        /// <param name="unAdherent"></param>
        public void ModificationAdherent(Adherents unAdherent)
        {
            controle.ModificationAdherent(unAdherent);
        }
        /// <summary>
        /// Permet de modifier le type prestation passé en paramétre
        /// </summary>
        /// <param name="unTypePrestation">le type de prestation modifié</param>
        public void ModifierUnTypePrestation(TypePrestation unTypePrestation)
        {
            controle.ModifierUnTypePrestation(unTypePrestation);
        }
        /// <summary>
        /// Permet d'ajouter un consommable
        /// </summary>
        /// <param name="unConsommable">le consommable à modifier</param>
        public void ModificationConsommable(Consommable unConsommable)
        {
            controle.ModificationConsommable(unConsommable);
        }
        /// <summary>
        /// Permet de supprimer une prestation avec l'id de la prestation
        /// </summary>
        /// <param name="idPrestationSelectionnee">id de la prestation</param>
        public void SuppressionPrestation(int idPrestationSelectionnee)
        {
            controle.SuppressionPrestation(idPrestationSelectionnee);
        }
        /// <summary>
        /// Permet de supprimer un rechargement avec l'adherent et la date des paramètres
        /// </summary>
        /// <param name="idAdherent">l'adherent de la prestation</param>
        /// <param name="datePrestation">la date de la prestation</param>
        public void SuppressionRechargement(int idAdherent, string dateRechargement)
        {
            controle.SuppressionRechargement(idAdherent, dateRechargement);
        }
        /// <summary>
        /// Permet de supprimer le type prestation passé en paramètre
        /// </summary>
        /// <param name="unTypePrestation">le type prestation à supprimer</param>
        public void SupprimerUnTypePrestation(TypePrestation unTypePrestation)
        {
            controle.SupprimerUnTypePrestation(unTypePrestation);
        }
        /// <summary>
        /// Permet de supprimer un consommable
        /// </summary>
        /// <param name="unConsommable">le consommable à supprimer</param>
        public void SuppressionConsommable(Consommable unConsommable)
        {
            controle.SuppressionConsommable(unConsommable);
        }
        #endregion

    }
}
