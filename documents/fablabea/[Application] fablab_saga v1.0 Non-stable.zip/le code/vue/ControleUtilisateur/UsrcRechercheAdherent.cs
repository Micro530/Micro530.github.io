﻿using fablab_saga.model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace fablab_saga.vue.ControleUtilisateur
{
    public partial class UsrcRechercheAdherent : UserControl
    {
        /// <summary>
        /// Instance du formualre parent
        /// </summary>
        private FrmPrincipal frmPrincipal;
        /// <summary>
        /// Permet de garder en mémoire la liste des adhérents pour les traitements
        /// </summary>
        private List<Adherents> lesAdherents;
        /// <summary>
        /// Constructeur du UserControl
        /// </summary>
        /// <param name="frmPrincipale"></param>
        public UsrcRechercheAdherent(FrmPrincipal frmPrincipale)
        {
            this.frmPrincipal = frmPrincipale;
            InitializeComponent();
        }
        #region Animation bouton
        /// <summary>
        /// Évenement de rentré de la souris sur le bouton annuler
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void pictbAnnuler_MouseEnter(object sender, EventArgs e)
        {
            pictbAnnuler.SizeMode = PictureBoxSizeMode.StretchImage;
        }
        /// <summary>
        /// Évenement de sortie de la souris sur le bouton annuler
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void pictbAnnuler_MouseLeave(object sender, EventArgs e)
        {
            pictbAnnuler.SizeMode = PictureBoxSizeMode.CenterImage;
        }
        /// <summary>
        /// Évenement de rentré de la souris sur le bouton sauvegarder
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void pictbSauvegerder_MouseEnter(object sender, EventArgs e)
        {
            pictbSauvegerder.SizeMode = PictureBoxSizeMode.StretchImage;
        }
        /// <summary>
        /// Évenement de sortie de la souris sur le bouton sauvegarder
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void pictbSauvegerder_MouseLeave(object sender, EventArgs e)
        {
            pictbSauvegerder.SizeMode = PictureBoxSizeMode.CenterImage;
        }
        #endregion
        /// <summary>
        /// Au chargement du formulaire
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void UsrcRechercheAdherent_Load(object sender, EventArgs e)
        {
            lesAdherents = frmPrincipal.GetLesAdherent();
            combPrenom.Enabled = false;
            combDateNaissance.Enabled = false;
            RechargeCombNom();
        }
        /// <summary>
        /// Permet de charger/recharger le comboBox combNom
        /// </summary>
        private void RechargeCombNom()
        {
            foreach (Adherents unAdherent in lesAdherents)
            {
                if (!combNom.Items.Contains(unAdherent.NomAdherent))
                {
                    combNom.Items.Add(unAdherent.NomAdherent);
                }
            }
        }
        /// <summary>
        /// Permet de charger/recharger le comboBox combPrenom
        /// </summary>
        /// <param name="filtreNom"></param>
        private void RechargeCombPrenom(string filtreNom)
        {
            combPrenom.Items.Clear();
            foreach (Adherents unAdherent in lesAdherents)
            {
                if (!combPrenom.Items.Contains(unAdherent.PrenomAdherent) && unAdherent.NomAdherent == filtreNom)
                {
                    combPrenom.Items.Add(unAdherent.PrenomAdherent);
                }
            }
            combPrenom.SelectedIndex = 0;
        }
        /// <summary>
        /// Permet de charger/recharger le comboBox combDateNaissance
        /// </summary>
        /// <param name="filtreNom"></param>
        /// <param name="filtrePrenom"></param>
        private void RechargeCombDateNaissance(string filtreNom, string filtrePrenom)
        {
            combDateNaissance.Items.Clear();
            foreach (Adherents unAdherent in lesAdherents)
            {
                if (!combDateNaissance.Items.Contains(unAdherent.DateNaissanceAdherent) && 
                    unAdherent.NomAdherent == filtreNom && unAdherent.PrenomAdherent == filtrePrenom)
                {
                    combDateNaissance.Items.Add(unAdherent.DateNaissanceAdherent);
                }
            }
            combDateNaissance.SelectedIndex = 0;
        }
        /// <summary>
        /// Évenement lors d'une selection dans le comboBox
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void combNom_SelectedIndexChanged(object sender, EventArgs e)
        {
            RechargeCombPrenom(combNom.SelectedItem.ToString());
            combPrenom.Enabled = true;
        }
        /// <summary>
        /// Évenement lors d'une selection dans le comboBox
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void combPrenom_SelectedIndexChanged(object sender, EventArgs e)
        {

            RechargeCombDateNaissance(combNom.SelectedItem.ToString(), combPrenom.SelectedItem.ToString());
            combDateNaissance.Enabled = true;
        }
        /// <summary>
        /// Évenement du bouton annuler
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void pictbAnnuler_Click(object sender, EventArgs e)
        {
            frmPrincipal.RetourMenu();
        }
        /// <summary>
        /// Évenement du bouton sauvegarder
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void pictbSauvegerder_Click(object sender, EventArgs e)
        {
            if(!combNom.SelectedIndex.Equals(-1) && !combPrenom.SelectedIndex.Equals(-1) && !combDateNaissance.SelectedIndex.Equals(-1))
            {
                foreach (Adherents unAdherents in lesAdherents)
                {
                    if (unAdherents.NomAdherent.Equals(combNom.SelectedItem.ToString()) &&
                        unAdherents.PrenomAdherent.Equals(combPrenom.SelectedItem.ToString()) &&
                        unAdherents.DateNaissanceAdherent.Equals((DateTime)combDateNaissance.SelectedItem))
                    {
                        frmPrincipal.CreationConsultationAdherent(unAdherents);
                        break;
                    }
                }
            }
            else
            {
                MessageBox.Show("Tous les champs doivent être rempli pour continuer", "Champs vide(s)", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            
        }
    }
}
