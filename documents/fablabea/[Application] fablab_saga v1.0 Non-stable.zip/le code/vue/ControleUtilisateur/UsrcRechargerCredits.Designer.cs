﻿
namespace fablab_saga.vue.ControleUtilisateur
{
    partial class UsrcRechargerCredits
    {
        /// <summary> 
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Code généré par le Concepteur de composants

        /// <summary> 
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas 
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.lblText = new System.Windows.Forms.Label();
            this.txtEuro = new System.Windows.Forms.TextBox();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.lblEuro = new System.Windows.Forms.Label();
            this.txtCredits = new System.Windows.Forms.TextBox();
            this.lblCredits = new System.Windows.Forms.Label();
            this.pictSauvegarder = new System.Windows.Forms.PictureBox();
            this.pictAnnuler = new System.Windows.Forms.PictureBox();
            this.lblErreurInt = new System.Windows.Forms.Label();
            this.lblIdentifiant = new System.Windows.Forms.Label();
            this.lblNomIdentifiant = new System.Windows.Forms.Label();
            this.lblAdherent = new System.Windows.Forms.Label();
            this.lblNomPrenomAdherent = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictSauvegarder)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictAnnuler)).BeginInit();
            this.SuspendLayout();
            // 
            // lblText
            // 
            this.lblText.AutoSize = true;
            this.lblText.BackColor = System.Drawing.Color.Transparent;
            this.lblText.Font = new System.Drawing.Font("Lucida Console", 12F, System.Drawing.FontStyle.Bold);
            this.lblText.Location = new System.Drawing.Point(257, 138);
            this.lblText.Name = "lblText";
            this.lblText.Size = new System.Drawing.Size(492, 16);
            this.lblText.TabIndex = 0;
            this.lblText.Text = "Saisissez le montant en euro ou directement ";
            // 
            // txtEuro
            // 
            this.txtEuro.Location = new System.Drawing.Point(270, 319);
            this.txtEuro.Name = "txtEuro";
            this.txtEuro.Size = new System.Drawing.Size(100, 20);
            this.txtEuro.TabIndex = 1;
            this.txtEuro.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtEuro_KeyUp);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(61, 4);
            // 
            // lblEuro
            // 
            this.lblEuro.AutoSize = true;
            this.lblEuro.Font = new System.Drawing.Font("Lucida Console", 12F, System.Drawing.FontStyle.Bold);
            this.lblEuro.Location = new System.Drawing.Point(376, 322);
            this.lblEuro.Name = "lblEuro";
            this.lblEuro.Size = new System.Drawing.Size(19, 16);
            this.lblEuro.TabIndex = 3;
            this.lblEuro.Text = "€";
            // 
            // txtCredits
            // 
            this.txtCredits.Location = new System.Drawing.Point(615, 321);
            this.txtCredits.Name = "txtCredits";
            this.txtCredits.Size = new System.Drawing.Size(100, 20);
            this.txtCredits.TabIndex = 4;
            this.txtCredits.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtCredits_KeyUp);
            // 
            // lblCredits
            // 
            this.lblCredits.AutoSize = true;
            this.lblCredits.Font = new System.Drawing.Font("Lucida Console", 12F, System.Drawing.FontStyle.Bold);
            this.lblCredits.Location = new System.Drawing.Point(721, 323);
            this.lblCredits.Name = "lblCredits";
            this.lblCredits.Size = new System.Drawing.Size(85, 16);
            this.lblCredits.TabIndex = 5;
            this.lblCredits.Text = "Crédits";
            // 
            // pictSauvegarder
            // 
            this.pictSauvegarder.Image = global::fablab_saga.Properties.Resources.save;
            this.pictSauvegarder.Location = new System.Drawing.Point(888, 636);
            this.pictSauvegarder.Name = "pictSauvegarder";
            this.pictSauvegarder.Size = new System.Drawing.Size(110, 110);
            this.pictSauvegarder.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictSauvegarder.TabIndex = 7;
            this.pictSauvegarder.TabStop = false;
            this.pictSauvegarder.Click += new System.EventHandler(this.pictSauvegarder_Click);
            this.pictSauvegarder.MouseEnter += new System.EventHandler(this.pictSauvegarder_MouseEnter);
            this.pictSauvegarder.MouseLeave += new System.EventHandler(this.pictSauvegarder_MouseLeave);
            // 
            // pictAnnuler
            // 
            this.pictAnnuler.Image = global::fablab_saga.Properties.Resources.cancelIcon;
            this.pictAnnuler.Location = new System.Drawing.Point(760, 636);
            this.pictAnnuler.Name = "pictAnnuler";
            this.pictAnnuler.Size = new System.Drawing.Size(110, 110);
            this.pictAnnuler.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictAnnuler.TabIndex = 6;
            this.pictAnnuler.TabStop = false;
            this.pictAnnuler.Click += new System.EventHandler(this.pictAnnuler_Click);
            this.pictAnnuler.MouseEnter += new System.EventHandler(this.pictAnnuler_MouseEnter);
            this.pictAnnuler.MouseLeave += new System.EventHandler(this.pictAnnuler_MouseLeave);
            // 
            // lblErreurInt
            // 
            this.lblErreurInt.AutoSize = true;
            this.lblErreurInt.Font = new System.Drawing.Font("Lucida Console", 12F, System.Drawing.FontStyle.Bold);
            this.lblErreurInt.ForeColor = System.Drawing.Color.Red;
            this.lblErreurInt.Location = new System.Drawing.Point(121, 311);
            this.lblErreurInt.Name = "lblErreurInt";
            this.lblErreurInt.Size = new System.Drawing.Size(0, 16);
            this.lblErreurInt.TabIndex = 8;
            // 
            // lblIdentifiant
            // 
            this.lblIdentifiant.AutoSize = true;
            this.lblIdentifiant.BackColor = System.Drawing.Color.Transparent;
            this.lblIdentifiant.Font = new System.Drawing.Font("Lucida Console", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIdentifiant.Location = new System.Drawing.Point(23, 29);
            this.lblIdentifiant.Name = "lblIdentifiant";
            this.lblIdentifiant.Size = new System.Drawing.Size(238, 16);
            this.lblIdentifiant.TabIndex = 58;
            this.lblIdentifiant.Text = "Connecté en temps que :";
            // 
            // lblNomIdentifiant
            // 
            this.lblNomIdentifiant.AutoSize = true;
            this.lblNomIdentifiant.BackColor = System.Drawing.Color.Transparent;
            this.lblNomIdentifiant.Font = new System.Drawing.Font("Lucida Console", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNomIdentifiant.Location = new System.Drawing.Point(267, 29);
            this.lblNomIdentifiant.Name = "lblNomIdentifiant";
            this.lblNomIdentifiant.Size = new System.Drawing.Size(178, 16);
            this.lblNomIdentifiant.TabIndex = 59;
            this.lblNomIdentifiant.Text = "<nom utilisateur>";
            // 
            // lblAdherent
            // 
            this.lblAdherent.AutoSize = true;
            this.lblAdherent.BackColor = System.Drawing.Color.Transparent;
            this.lblAdherent.Font = new System.Drawing.Font("Lucida Console", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAdherent.Location = new System.Drawing.Point(631, 29);
            this.lblAdherent.Name = "lblAdherent";
            this.lblAdherent.Size = new System.Drawing.Size(108, 16);
            this.lblAdherent.TabIndex = 60;
            this.lblAdherent.Text = "Adhérent :";
            // 
            // lblNomPrenomAdherent
            // 
            this.lblNomPrenomAdherent.AutoSize = true;
            this.lblNomPrenomAdherent.BackColor = System.Drawing.Color.Transparent;
            this.lblNomPrenomAdherent.Font = new System.Drawing.Font("Lucida Console", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNomPrenomAdherent.Location = new System.Drawing.Point(745, 29);
            this.lblNomPrenomAdherent.Name = "lblNomPrenomAdherent";
            this.lblNomPrenomAdherent.Size = new System.Drawing.Size(178, 16);
            this.lblNomPrenomAdherent.TabIndex = 61;
            this.lblNomPrenomAdherent.Text = "<nom utilisateur>";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Lucida Console", 12F, System.Drawing.FontStyle.Bold);
            this.label1.Location = new System.Drawing.Point(245, 170);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(514, 16);
            this.label1.TabIndex = 62;
            this.label1.Text = "la quantité de credit à ajouter à cet adherent";
            // 
            // UsrcRechargerCredits
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Transparent;
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblIdentifiant);
            this.Controls.Add(this.lblNomIdentifiant);
            this.Controls.Add(this.lblAdherent);
            this.Controls.Add(this.lblNomPrenomAdherent);
            this.Controls.Add(this.lblText);
            this.Controls.Add(this.lblEuro);
            this.Controls.Add(this.txtEuro);
            this.Controls.Add(this.lblCredits);
            this.Controls.Add(this.txtCredits);
            this.Controls.Add(this.lblErreurInt);
            this.Controls.Add(this.pictAnnuler);
            this.Controls.Add(this.pictSauvegarder);
            this.Name = "UsrcRechargerCredits";
            this.Size = new System.Drawing.Size(1024, 768);
            this.Load += new System.EventHandler(this.UsrcRechargerCredits_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictSauvegarder)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictAnnuler)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblText;
        private System.Windows.Forms.TextBox txtEuro;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.Label lblEuro;
        private System.Windows.Forms.TextBox txtCredits;
        private System.Windows.Forms.Label lblCredits;
        private System.Windows.Forms.PictureBox pictAnnuler;
        private System.Windows.Forms.PictureBox pictSauvegarder;
        private System.Windows.Forms.Label lblErreurInt;
        private System.Windows.Forms.Label lblIdentifiant;
        private System.Windows.Forms.Label lblNomIdentifiant;
        private System.Windows.Forms.Label lblAdherent;
        private System.Windows.Forms.Label lblNomPrenomAdherent;
        private System.Windows.Forms.Label label1;
    }
}
