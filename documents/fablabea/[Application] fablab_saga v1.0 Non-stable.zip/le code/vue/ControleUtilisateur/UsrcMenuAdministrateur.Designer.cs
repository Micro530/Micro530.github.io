﻿
namespace fablab_saga.vue.ControleUtilisateur
{
    partial class UsrcMenuAdministrateur
    {
        /// <summary> 
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Code généré par le Concepteur de composants

        /// <summary> 
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas 
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnRetourMenu = new System.Windows.Forms.Button();
            this.lblNomIdentifiant = new System.Windows.Forms.Label();
            this.lblIdentifiant = new System.Windows.Forms.Label();
            this.panConsommables = new System.Windows.Forms.Panel();
            this.pictbAjouterConsommable = new System.Windows.Forms.PictureBox();
            this.pictbRechercherConsommable = new System.Windows.Forms.PictureBox();
            this.panTypePrestation = new System.Windows.Forms.Panel();
            this.pictConsulterTypePrestation = new System.Windows.Forms.PictureBox();
            this.panConsommables.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictbAjouterConsommable)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictbRechercherConsommable)).BeginInit();
            this.panTypePrestation.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictConsulterTypePrestation)).BeginInit();
            this.SuspendLayout();
            // 
            // btnRetourMenu
            // 
            this.btnRetourMenu.Font = new System.Drawing.Font("Lucida Console", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRetourMenu.Location = new System.Drawing.Point(799, 17);
            this.btnRetourMenu.Name = "btnRetourMenu";
            this.btnRetourMenu.Size = new System.Drawing.Size(194, 34);
            this.btnRetourMenu.TabIndex = 19;
            this.btnRetourMenu.Text = "Revenir au menu";
            this.btnRetourMenu.UseVisualStyleBackColor = true;
            this.btnRetourMenu.Click += new System.EventHandler(this.btnRetourMenu_Click);
            // 
            // lblNomIdentifiant
            // 
            this.lblNomIdentifiant.AutoSize = true;
            this.lblNomIdentifiant.BackColor = System.Drawing.Color.Transparent;
            this.lblNomIdentifiant.Font = new System.Drawing.Font("Lucida Console", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNomIdentifiant.Location = new System.Drawing.Point(265, 20);
            this.lblNomIdentifiant.Name = "lblNomIdentifiant";
            this.lblNomIdentifiant.Size = new System.Drawing.Size(178, 16);
            this.lblNomIdentifiant.TabIndex = 22;
            this.lblNomIdentifiant.Text = "<nom utilisateur>";
            // 
            // lblIdentifiant
            // 
            this.lblIdentifiant.AutoSize = true;
            this.lblIdentifiant.BackColor = System.Drawing.Color.Transparent;
            this.lblIdentifiant.Font = new System.Drawing.Font("Lucida Console", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIdentifiant.Location = new System.Drawing.Point(21, 20);
            this.lblIdentifiant.Name = "lblIdentifiant";
            this.lblIdentifiant.Size = new System.Drawing.Size(238, 16);
            this.lblIdentifiant.TabIndex = 21;
            this.lblIdentifiant.Text = "Connecté en temps que :";
            // 
            // panConsommables
            // 
            this.panConsommables.BackColor = System.Drawing.Color.Transparent;
            this.panConsommables.BackgroundImage = global::fablab_saga.Properties.Resources.filament;
            this.panConsommables.Controls.Add(this.pictbAjouterConsommable);
            this.panConsommables.Controls.Add(this.pictbRechercherConsommable);
            this.panConsommables.Location = new System.Drawing.Point(120, 214);
            this.panConsommables.Name = "panConsommables";
            this.panConsommables.Size = new System.Drawing.Size(260, 260);
            this.panConsommables.TabIndex = 23;
            // 
            // pictbAjouterConsommable
            // 
            this.pictbAjouterConsommable.BackColor = System.Drawing.Color.Transparent;
            this.pictbAjouterConsommable.Image = global::fablab_saga.Properties.Resources.plus;
            this.pictbAjouterConsommable.Location = new System.Drawing.Point(0, 150);
            this.pictbAjouterConsommable.Name = "pictbAjouterConsommable";
            this.pictbAjouterConsommable.Size = new System.Drawing.Size(110, 110);
            this.pictbAjouterConsommable.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictbAjouterConsommable.TabIndex = 10;
            this.pictbAjouterConsommable.TabStop = false;
            this.pictbAjouterConsommable.Click += new System.EventHandler(this.pictbAjouterConsommable_Click);
            this.pictbAjouterConsommable.MouseEnter += new System.EventHandler(this.PictbAjouterAdherent_MouseEnter);
            this.pictbAjouterConsommable.MouseLeave += new System.EventHandler(this.PictbAjouterAdherent_MouseLeave);
            // 
            // pictbRechercherConsommable
            // 
            this.pictbRechercherConsommable.BackColor = System.Drawing.Color.Transparent;
            this.pictbRechercherConsommable.Image = global::fablab_saga.Properties.Resources.loupe;
            this.pictbRechercherConsommable.Location = new System.Drawing.Point(150, 150);
            this.pictbRechercherConsommable.Name = "pictbRechercherConsommable";
            this.pictbRechercherConsommable.Size = new System.Drawing.Size(110, 110);
            this.pictbRechercherConsommable.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictbRechercherConsommable.TabIndex = 9;
            this.pictbRechercherConsommable.TabStop = false;
            this.pictbRechercherConsommable.Click += new System.EventHandler(this.pictbRechercherConsommable_Click);
            this.pictbRechercherConsommable.MouseEnter += new System.EventHandler(this.PictbRechercher_MouseEnter);
            this.pictbRechercherConsommable.MouseLeave += new System.EventHandler(this.PictbRechercher_MouseLeave);
            // 
            // panTypePrestation
            // 
            this.panTypePrestation.BackColor = System.Drawing.Color.Transparent;
            this.panTypePrestation.BackgroundImage = global::fablab_saga.Properties.Resources._3dPrinter;
            this.panTypePrestation.Controls.Add(this.pictConsulterTypePrestation);
            this.panTypePrestation.Location = new System.Drawing.Point(623, 214);
            this.panTypePrestation.Name = "panTypePrestation";
            this.panTypePrestation.Size = new System.Drawing.Size(260, 260);
            this.panTypePrestation.TabIndex = 20;
            // 
            // pictConsulterTypePrestation
            // 
            this.pictConsulterTypePrestation.BackColor = System.Drawing.Color.Transparent;
            this.pictConsulterTypePrestation.Image = global::fablab_saga.Properties.Resources.loupe;
            this.pictConsulterTypePrestation.Location = new System.Drawing.Point(76, 150);
            this.pictConsulterTypePrestation.Name = "pictConsulterTypePrestation";
            this.pictConsulterTypePrestation.Size = new System.Drawing.Size(110, 110);
            this.pictConsulterTypePrestation.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictConsulterTypePrestation.TabIndex = 9;
            this.pictConsulterTypePrestation.TabStop = false;
            this.pictConsulterTypePrestation.Click += new System.EventHandler(this.pictConsulterTypePrestation_Click);
            this.pictConsulterTypePrestation.MouseEnter += new System.EventHandler(this.PictbRechercherTypePrestation_MouseEnter);
            this.pictConsulterTypePrestation.MouseLeave += new System.EventHandler(this.PictbRechercherTypePrestation_MouseLeave);
            // 
            // UsrcMenuAdministrateur
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Transparent;
            this.Controls.Add(this.lblIdentifiant);
            this.Controls.Add(this.lblNomIdentifiant);
            this.Controls.Add(this.btnRetourMenu);
            this.Controls.Add(this.panConsommables);
            this.Controls.Add(this.panTypePrestation);
            this.Name = "UsrcMenuAdministrateur";
            this.Size = new System.Drawing.Size(1024, 768);
            this.Load += new System.EventHandler(this.UsrcMenuAdministrateur_Load);
            this.panConsommables.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictbAjouterConsommable)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictbRechercherConsommable)).EndInit();
            this.panTypePrestation.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictConsulterTypePrestation)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnRetourMenu;
        private System.Windows.Forms.Panel panTypePrestation;
        private System.Windows.Forms.PictureBox pictConsulterTypePrestation;
        private System.Windows.Forms.Panel panConsommables;
        private System.Windows.Forms.PictureBox pictbAjouterConsommable;
        private System.Windows.Forms.PictureBox pictbRechercherConsommable;
        private System.Windows.Forms.Label lblNomIdentifiant;
        private System.Windows.Forms.Label lblIdentifiant;
    }
}
