﻿
namespace fablab_saga.vue.ControleUtilisateur
{
    partial class UsrcAjoutAdherent
    {
        /// <summary> 
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Code généré par le Concepteur de composants

        /// <summary> 
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas 
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtNomAdherent = new System.Windows.Forms.TextBox();
            this.txtPrenomAdherent = new System.Windows.Forms.TextBox();
            this.lblIdentifiant = new System.Windows.Forms.Label();
            this.lblNomIdentifiant = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.txtTelephoneAdherent = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtEmailAdherent = new System.Windows.Forms.TextBox();
            this.pictbSauvegerder = new System.Windows.Forms.PictureBox();
            this.pictbAnnuler = new System.Windows.Forms.PictureBox();
            this.calendrier = new fablab_saga.vue.ControleUtilisateur.UsrcCalendrier();
            ((System.ComponentModel.ISupportInitialize)(this.pictbSauvegerder)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictbAnnuler)).BeginInit();
            this.SuspendLayout();
            // 
            // txtNomAdherent
            // 
            this.txtNomAdherent.Font = new System.Drawing.Font("Lucida Console", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNomAdherent.Location = new System.Drawing.Point(241, 161);
            this.txtNomAdherent.Name = "txtNomAdherent";
            this.txtNomAdherent.Size = new System.Drawing.Size(314, 23);
            this.txtNomAdherent.TabIndex = 10;
            // 
            // txtPrenomAdherent
            // 
            this.txtPrenomAdherent.Font = new System.Drawing.Font("Lucida Console", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPrenomAdherent.Location = new System.Drawing.Point(241, 213);
            this.txtPrenomAdherent.Name = "txtPrenomAdherent";
            this.txtPrenomAdherent.Size = new System.Drawing.Size(314, 23);
            this.txtPrenomAdherent.TabIndex = 11;
            // 
            // lblIdentifiant
            // 
            this.lblIdentifiant.AutoSize = true;
            this.lblIdentifiant.BackColor = System.Drawing.Color.Transparent;
            this.lblIdentifiant.Font = new System.Drawing.Font("Lucida Console", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIdentifiant.Location = new System.Drawing.Point(21, 20);
            this.lblIdentifiant.Name = "lblIdentifiant";
            this.lblIdentifiant.Size = new System.Drawing.Size(238, 16);
            this.lblIdentifiant.TabIndex = 14;
            this.lblIdentifiant.Text = "Connecté en temps que :";
            // 
            // lblNomIdentifiant
            // 
            this.lblNomIdentifiant.AutoSize = true;
            this.lblNomIdentifiant.BackColor = System.Drawing.Color.Transparent;
            this.lblNomIdentifiant.Font = new System.Drawing.Font("Lucida Console", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNomIdentifiant.Location = new System.Drawing.Point(265, 20);
            this.lblNomIdentifiant.Name = "lblNomIdentifiant";
            this.lblNomIdentifiant.Size = new System.Drawing.Size(178, 16);
            this.lblNomIdentifiant.TabIndex = 15;
            this.lblNomIdentifiant.Text = "<nom utilisateur>";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Lucida Console", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(60, 161);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(58, 16);
            this.label2.TabIndex = 16;
            this.label2.Text = "Nom :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Lucida Console", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(60, 213);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(88, 16);
            this.label3.TabIndex = 17;
            this.label3.Text = "Prénom :";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Lucida Console", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(72, 518);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(858, 16);
            this.label6.TabIndex = 20;
            this.label6.Text = "L\'identifiant et le mot de passe sont générés automatiquement puis envoyés par E-" +
    "mail";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.Transparent;
            this.label9.Font = new System.Drawing.Font("Lucida Console", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(60, 265);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(118, 16);
            this.label9.TabIndex = 26;
            this.label9.Text = "Téléphone :";
            // 
            // txtTelephoneAdherent
            // 
            this.txtTelephoneAdherent.Font = new System.Drawing.Font("Lucida Console", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTelephoneAdherent.Location = new System.Drawing.Point(241, 265);
            this.txtTelephoneAdherent.Name = "txtTelephoneAdherent";
            this.txtTelephoneAdherent.Size = new System.Drawing.Size(314, 23);
            this.txtTelephoneAdherent.TabIndex = 23;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Lucida Console", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(60, 317);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(88, 16);
            this.label4.TabIndex = 29;
            this.label4.Text = "E-mail :";
            // 
            // txtEmailAdherent
            // 
            this.txtEmailAdherent.Font = new System.Drawing.Font("Lucida Console", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEmailAdherent.Location = new System.Drawing.Point(241, 317);
            this.txtEmailAdherent.Name = "txtEmailAdherent";
            this.txtEmailAdherent.Size = new System.Drawing.Size(314, 23);
            this.txtEmailAdherent.TabIndex = 28;
            // 
            // pictbSauvegerder
            // 
            this.pictbSauvegerder.BackColor = System.Drawing.Color.Transparent;
            this.pictbSauvegerder.Image = global::fablab_saga.Properties.Resources.save;
            this.pictbSauvegerder.Location = new System.Drawing.Point(849, 602);
            this.pictbSauvegerder.Name = "pictbSauvegerder";
            this.pictbSauvegerder.Size = new System.Drawing.Size(110, 110);
            this.pictbSauvegerder.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictbSauvegerder.TabIndex = 30;
            this.pictbSauvegerder.TabStop = false;
            this.pictbSauvegerder.Click += new System.EventHandler(this.pictbSauvegerder_Click);
            this.pictbSauvegerder.MouseEnter += new System.EventHandler(this.pictbSauvegerder_MouseEnter);
            this.pictbSauvegerder.MouseLeave += new System.EventHandler(this.pictbSauvegerder_MouseLeave);
            // 
            // pictbAnnuler
            // 
            this.pictbAnnuler.BackColor = System.Drawing.Color.Transparent;
            this.pictbAnnuler.Image = global::fablab_saga.Properties.Resources.cancelIcon;
            this.pictbAnnuler.Location = new System.Drawing.Point(709, 602);
            this.pictbAnnuler.Name = "pictbAnnuler";
            this.pictbAnnuler.Size = new System.Drawing.Size(110, 110);
            this.pictbAnnuler.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictbAnnuler.TabIndex = 7;
            this.pictbAnnuler.TabStop = false;
            this.pictbAnnuler.Click += new System.EventHandler(this.pictbAnnuler_Click);
            this.pictbAnnuler.MouseEnter += new System.EventHandler(this.pictbAnnuler_MouseEnter);
            this.pictbAnnuler.MouseLeave += new System.EventHandler(this.pictbAnnuler_MouseLeave);
            // 
            // calendrier
            // 
            this.calendrier.BackColor = System.Drawing.Color.Transparent;
            this.calendrier.Location = new System.Drawing.Point(600, 161);
            this.calendrier.Name = "calendrier";
            this.calendrier.Size = new System.Drawing.Size(340, 150);
            this.calendrier.TabIndex = 33;
            // 
            // UsrcAjoutAdherent
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Transparent;
            this.Controls.Add(this.calendrier);
            this.Controls.Add(this.pictbSauvegerder);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtEmailAdherent);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.txtTelephoneAdherent);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lblNomIdentifiant);
            this.Controls.Add(this.lblIdentifiant);
            this.Controls.Add(this.txtPrenomAdherent);
            this.Controls.Add(this.txtNomAdherent);
            this.Controls.Add(this.pictbAnnuler);
            this.Name = "UsrcAjoutAdherent";
            this.Size = new System.Drawing.Size(1024, 768);
            this.Load += new System.EventHandler(this.UsrcAjoutAdherent_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictbSauvegerder)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictbAnnuler)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.PictureBox pictbAnnuler;
        private System.Windows.Forms.TextBox txtNomAdherent;
        private System.Windows.Forms.TextBox txtPrenomAdherent;
        private System.Windows.Forms.Label lblIdentifiant;
        private System.Windows.Forms.Label lblNomIdentifiant;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtTelephoneAdherent;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtEmailAdherent;
        private System.Windows.Forms.PictureBox pictbSauvegerder;
        private UsrcCalendrier calendrier;
    }
}
