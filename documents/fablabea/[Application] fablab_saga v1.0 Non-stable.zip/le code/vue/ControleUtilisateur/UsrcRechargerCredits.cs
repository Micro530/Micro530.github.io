﻿using fablab_saga.model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace fablab_saga.vue.ControleUtilisateur
{
    public partial class UsrcRechargerCredits : UserControl
    {
        private FrmPrincipal frmPrincipal;
        private Adherents unAdherent;
        private string identifiant;
        private float ConversionEuroCredits = 2;
        public UsrcRechargerCredits(FrmPrincipal frmPrincipal, Adherents unAdherent, string identifiant)
        {
            this.frmPrincipal = frmPrincipal;
            this.unAdherent = unAdherent;
            this.identifiant = identifiant;
            InitializeComponent();
        }
        /// <summary>
        /// Initialisation du formulaire
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void UsrcRechargerCredits_Load(object sender, EventArgs e)
        {
            lblNomIdentifiant.Text = identifiant;
            lblNomPrenomAdherent.Text = unAdherent.NomAdherent + " " + unAdherent.PrenomAdherent;
        }
        #region Saisie Dynamique
        /// <summary>
        /// Évenement lors d'une saisie dans le textBox txtEuro mettant à jour le nombre de credit dans le textBox txtCredits
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void txtEuro_KeyUp(object sender, KeyEventArgs e)
        {
            if (!(float.TryParse(txtEuro.Text, out float result)))
            {
                lblErreurInt.Text = "Vous devez rentrer que des chiffres";
            }
            else
            {
                lblErreurInt.Text = "";
                txtCredits.Text = (float.Parse(txtEuro.Text) * ConversionEuroCredits).ToString();
            }
        }
        /// <summary>
        /// Évenement lors d'une saisie dans le textBox txtCredits mettant à jour le nombre d'euro dans le textBox txtEuro
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void txtCredits_KeyUp(object sender, KeyEventArgs e)
        {
            if (!(float.TryParse(txtCredits.Text, out float result)))
            {
                lblErreurInt.Text = "Vous devez rentrer que des chiffres";
            }
            else
            {
                lblErreurInt.Text = "";
                txtEuro.Text = (float.Parse(txtCredits.Text) * ConversionEuroCredits).ToString();
            }
        }
        #endregion
        #region Bouton Dynamique
        /// <summary>
        /// Évenement entrer souris sur le pictureBox
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void pictSauvegarder_MouseEnter(object sender, EventArgs e)
        {
            pictSauvegarder.SizeMode = PictureBoxSizeMode.StretchImage;
        }
        /// <summary>
        /// Évenement sortie souris sur le pictureBox
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void pictSauvegarder_MouseLeave(object sender, EventArgs e)
        {
            pictSauvegarder.SizeMode = PictureBoxSizeMode.CenterImage;
        }
        /// <summary>
        /// Évenement entrer souris sur le pictureBox
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void pictAnnuler_MouseEnter(object sender, EventArgs e)
        {
            pictAnnuler.SizeMode = PictureBoxSizeMode.StretchImage;
        }
        /// <summary>
        /// Évenement sortie souris sur le pictureBox
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void pictAnnuler_MouseLeave(object sender, EventArgs e)
        {
            pictAnnuler.SizeMode = PictureBoxSizeMode.CenterImage;
        }
        #endregion
        #region Événement clique sur bouton
        /// <summary>
        /// Évenement lors du clique sur le bouton pictAnnuler
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void pictAnnuler_Click(object sender, EventArgs e)
        {
            frmPrincipal.CreationConsultationAdherent(frmPrincipal.RecupUnAdherent(unAdherent.IdAdherent));
        }
        /// <summary>
        ///venement lors du clique sur le bouton pictSauvegarder 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void pictSauvegarder_Click(object sender, EventArgs e)
        {
            frmPrincipal.AjoutCredits(unAdherent.IdAdherent, DateTime.Now, float.Parse(txtCredits.Text));
            pictAnnuler_Click(null, null);
        }
        #endregion
    }
}
