﻿using fablab_saga.model;
using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace fablab_saga.vue.ControleUtilisateur
{
    public partial class UsrcNouvellePrestation : UserControl
    {
        #region les propiétés
        /// <summary>
        /// Instance du formulaire parent
        /// </summary>
        private FrmPrincipal frmPrincipal;
        /// <summary>
        /// L'adherent à qui on ajoute une prestation
        /// </summary>
        private Adherents unAdherent;
        /// <summary>
        /// L'identifiant de connexion
        /// </summary>
        private string identifiant;
        /// <summary>
        /// une BindingSource contenant l'ensemble des types prestations
        /// </summary>
        private BindingSource lesTypesPrestations = new BindingSource();
        /// <summary>
        /// une BindingSource contenant l'ensemble des types de consommables
        /// </summary>
        private BindingSource lesTypesConsommables = new BindingSource();
        /// <summary>
        /// une BindingSource contenant l'ensemble des sous types consommables
        /// </summary>
        private BindingSource lesSousTypesConsommables = new BindingSource();
        /// <summary>
        /// une BindingSource contenant l'ensemble des consommables
        /// </summary>
        private BindingSource lesConsommables = new BindingSource();
        /// <summary>
        /// une BindingSource contenant l'ensemble des lignes de la prestation
        /// </summary>
        private List<ConsommablePrestation> lesConsommablesPrestations = new List<ConsommablePrestation>();
        /// <summary>
        /// Permet de garder en mémoire la prestation selectionné sur le DataGridView
        /// </summary>
        private int laPrestationSelectionee;
        #endregion
        /// <summary>
        /// Le constructeur 
        /// </summary>
        /// <param name="frmPrincipale">le formualre ayant initié la création de cette instance</param>
        /// <param name="unAdherent">l'adherent au quel est ajouter une prestation</param>
        /// <param name="identifiant">l'identifiant de connexion utilisé</param>
        public UsrcNouvellePrestation(FrmPrincipal frmPrincipale, Adherents unAdherent, string identifiant)
        {
            this.identifiant = identifiant;
            this.unAdherent = unAdherent;
            this.frmPrincipal = frmPrincipale;
            InitializeComponent();
        }
        /// <summary>
        /// Au chargement de cette userControl
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void UsrcNouvellePrestation_Load(object sender, EventArgs e)
        {
            lblNomIdentifiant.Text = identifiant;
            lblNomPrenomAdherent.Text = unAdherent.NomAdherent + " " + unAdherent.PrenomAdherent;
            RecuperationListes();
            RemplissageComboBox(combTypePrestation, lesTypesPrestations, "NomPrestation");
        }
        /// <summary>
        /// Récupération des listes au sein de la base de donnée, et affectation au BingdingSource correspondant
        /// </summary>
        private void RecuperationListes()
        {
            lesTypesPrestations.DataSource = frmPrincipal.GetLesTypesPrestations();
            lesTypesConsommables.DataSource = frmPrincipal.GetLesTypesConsommables();
            lesSousTypesConsommables.DataSource = frmPrincipal.GetLesSousTypesConsommables();
            lesConsommables.DataSource = frmPrincipal.GetLesConsommables();
        }
        #region Remplissage dynamique des ComboBox
        /// <summary>
        /// Permet de remplir un comboBox avec n'importe BingdingSource
        /// </summary>
        /// <param name="unCombo">le comboBox à remplir</param>
        /// <param name="uneBdgs">le BingdingSource ç utiliser pour le remplir</param>
        /// <param name="nomPropriete">la propriété à afficher dans le comboBox</param>
        private void RemplissageComboBox(ComboBox unCombo, BindingSource uneBdgs, string nomPropriete)
        {
            unCombo.DataSource = uneBdgs;
            unCombo.DisplayMember = nomPropriete;
            unCombo.ValueMember = nomPropriete;
            unCombo.SelectedIndex = -1;
        }
        /// <summary>
        /// Évenement lors d'un changement de selection dans le comboBox combTypePrestation, mettant à jour le comboBox
        /// combTypeConsommable
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void combTypePrestation_SelectionChange(object sender, EventArgs e)
        {
            if(combTypePrestation.SelectedIndex != -1)
            {
                grbAjouterLigne.Enabled = true;
                RemplissageComboBox(combTypeConsommable, lesTypesConsommables, "LeTypeConsommable");
            }
        }
        /// <summary>
        /// Évenement lors d'un changement de selection dans le comboBox combTypeConsommable, lancant la méthode
        /// RemplirCombSousTypeConsommable
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void combTypeConsommable_SelectionChange(object sender, EventArgs e)
        {
            if (combTypeConsommable.SelectedIndex != -1)
            {
                lblUnite.Text = (((TypeConsommable)combTypeConsommable.SelectedItem).UniteConsommable).ToString();
                combSousTypeConsommable.Enabled = true;
                RemplirCombSousTypeConsommable((TypeConsommable)combTypeConsommable.SelectedItem);
            }
        }
        /// <summary>
        /// Remplissage du comboBox CombSousTypeConsommable
        /// </summary>
        /// <param name="unType">le type du consommable permettant de récupérer que les sous types correspondant</param>
        private void RemplirCombSousTypeConsommable(TypeConsommable unType)
        {
            BindingSource sousType = new BindingSource();
            foreach (SousTypeConsommable unSousType in lesSousTypesConsommables)
            {
                if (unSousType.IdTypeConsommable.Equals(unType.IdTypeConsommable))
                {
                    sousType.Add(unSousType);
                }
            }
            RemplissageComboBox(combSousTypeConsommable, sousType, "Libelle");
        }
        /// <summary>
        /// Évenement lors d'un changement de selection dans le comboBox combSousTypeConsommable, lancant la méthode
        /// RemplirCombConsommable
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void combSousTypeConsommable_SelectionChange(object sender, EventArgs e)
        {
            if(combTypeConsommable.SelectedIndex != -1 && combSousTypeConsommable.SelectedIndex != -1)
            {
                grbChoisirConsommable.Enabled = true;
                RemplirCombConsommable((TypeConsommable)combTypeConsommable.SelectedItem, (SousTypeConsommable)combSousTypeConsommable.SelectedItem);
            }
        }
        /// <summary>
        /// Méthode pour remplir le comboBox combConsommable 
        /// </summary>
        /// <param name="unTypeConsommable">le type de consommable pour filtrer</param>
        /// <param name="unSousTypeConsommable">le sous type de consommable pour filtrer</param>
        private void RemplirCombConsommable(TypeConsommable unTypeConsommable, SousTypeConsommable unSousTypeConsommable)
        {
            BindingSource lesConsommables = new BindingSource();
            foreach (Consommable unConsommable in this.lesConsommables)
            {
                if(unConsommable.IdTypeConsommable.Equals(unTypeConsommable.IdTypeConsommable) &&
                    unConsommable.IdSousTypeConsommable.Equals(unSousTypeConsommable.IdSousTypeConsommable))
                {
                    lesConsommables.Add(unConsommable);
                }
            }
            RemplissageComboBox(combConsommable, lesConsommables, "LibelleConsommable");
        }
        #endregion
        #region Bouton PictAjouterLigne
        /// <summary>
        /// Évenement lors du clique sur le bouton pictAjouterLigne
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void pictAjouterLigne_Click(object sender, EventArgs e)
        {
            if(combTypePrestation.SelectedIndex != -1 && combTypeConsommable.SelectedIndex != -1 && 
                combSousTypeConsommable.SelectedIndex != -1 && combConsommable.SelectedIndex != -1 && 
                txtQuantite.Text != "" && txtQuantite.Text != "0" && txtLibelle.Text != "")
            {
                //ajout des paramétres dans le bindingSource afin de mémoriser les objets ConsommablePrestation  
                lesConsommablesPrestations.Add(new ConsommablePrestation(1, ((Consommable)combConsommable.SelectedItem).IdConsommable, txtLibelle.Text, 
                    int.Parse(txtQuantite.Text), int.Parse(txtQuantite.Text) * ((Consommable)combConsommable.SelectedItem).PrixConsommable));
                //ajout des paramètres de façon claire et lisible dans le dataGridView
                dgvDetailPrestation.Rows.Add(((Consommable)combConsommable.SelectedItem).LibelleConsommable, txtLibelle.Text,
                    int.Parse(txtQuantite.Text), int.Parse(txtQuantite.Text) * ((Consommable)combConsommable.SelectedItem).PrixConsommable);
                ResetFormulaire();
            }
            else
            {
                MessageBox.Show("Tous les champs doivent être rempli pour pouvoir continuer", "Champs vide(s)", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
        /// <summary>
        /// Méthode pour réinitialiser le formulaire après avoir ajouter une ligne
        /// </summary>
        private void ResetFormulaire()
        {
            combTypePrestation.Enabled = false;
            combTypeConsommable.SelectedIndex = -1;
            combSousTypeConsommable.SelectedIndex = -1;
            combConsommable.SelectedIndex = -1;
            combSousTypeConsommable.Enabled = false;
            grbChoisirConsommable.Enabled = false;
            txtQuantite.Text = "0";
            lblSommeCoutCredits.Text = "0";
            txtLibelle.Text = "";
        }
        #endregion
        #region Bouton PictSauvegarder
        /// <summary>
        /// Évenement lors du clique sur le bouton pictSauvegerder permettant de valider toutes les lignes et d'envoyer les données pour les requetes
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void pictSauvegarder_Click(object sender, EventArgs e)
        {
            //la variable est déja instancié avec ctte chaine, aucas ou l'utilisateur clique sur le bouton annuler
            string libelle = "SansNom";
            libelle = Interaction.InputBox("Voulez vous donner un nom à votre projet ?", "Nom de projet", "SansNom");
            //Permet de mémoriser la date utiliser pour être certain d'utiliser la même à chaque fois
            DateTime datePrestation = DateTime.Now;
            frmPrincipal.AjoutNouvellePrestation(((TypePrestation)combTypePrestation.SelectedItem).IdTypePrestation, unAdherent.IdAdherent, datePrestation, libelle);
            //Une sécurité permettant de laisser le temps à la base de données de créer la requete précédante en cas de lag
            System.Threading.Thread.Sleep(2000);
            //Permet de contrer un défaut d'arrondi au suppérieur des secondes de la date dans la base de données si les milliseconde sout suppérieur ou égale à 500
            if (datePrestation.Millisecond >= 500)
            {
                datePrestation.AddSeconds(1);
            }
            Prestation unePrestation = frmPrincipal.RecupUnePrestation(unAdherent.IdAdherent, ConversionDateBdd(datePrestation));
            MessageBox.Show(ConversionDateBdd(datePrestation));
            ActualisationIdPrestation(unePrestation.IdPrestation);
            frmPrincipal.AjoutLignesPrestation(lesConsommablesPrestations);
            pictAnnuler_Click(null, null);
        }
        /// <summary>
        /// Permet d'actualiser l'idPrestation des lignes prestation avec l'idPrestation définitive 
        /// </summary>
        /// <param name="idPrestation">le nouvel idPrestation remplassant le valeur par défaut</param>
        private void ActualisationIdPrestation(int idPrestation)
        {
            for (int i = 0; i < lesConsommablesPrestations.Count; i++)
            {
                lesConsommablesPrestations[i].IdPrestation = idPrestation;
            }
        }
        /// <summary>
        /// Permet de convertir la date en version française en version anglaise avec la syntaxe exacte de la base de données
        /// </summary>
        /// <param name="datePrestation"></param>
        /// <returns></returns>
        private string ConversionDateBdd(DateTime datePrestation)
        {
            return datePrestation.Year + "-" + datePrestation.Month + "-" + datePrestation.Day + " " + datePrestation.Hour + ":" + datePrestation.Minute
                + ":" + datePrestation.Second;
        }
        #endregion
        #region Bouton PictAnnuler
        /// <summary>
        /// Évenement lors du clique sur le bouton pictAnnuler
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void pictAnnuler_Click(object sender, EventArgs e)
        {
            frmPrincipal.CreationConsultationAdherent(frmPrincipal.RecupUnAdherent(unAdherent.IdAdherent));
        }
        #endregion
        #region Évenement DataGridView
        /// <summary>
        /// Évenement lors d'un ajout d'une ligne dans le dataGridView dgvDetailPrestation pour calculer le montant total de toutes les lignes
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void dgvDetailPrestation_RowsAdded(object sender, DataGridViewRowsAddedEventArgs e)
        {
            //le code est séparé dans 2 variables locale temporaire pour plus de claireté
            float var = float.Parse(dgvDetailPrestation.Rows[dgvDetailPrestation.Rows.Count - 2].Cells["Montants"].Value.ToString());
            float vars = float.Parse(lblSommeTotalCredits.Text);
            lblSommeTotalCredits.Text = (var + vars).ToString();   
        }
        /// <summary>
        /// Évenment lors du changement de la selection d'un ligen dans le DataGridView pour mémoriser l'index de cette ligne en cas de supprssion
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void dgvDetailPrestation_SelectionChanged(object sender, EventArgs e)
        {
            laPrestationSelectionee = dgvDetailPrestation.CurrentRow.Index;
        }
        /// <summary>
        /// Évenement en cas de suppression d'un ligne, suppression de l'index correspondant dans le BindingSource contenant toutes les lignes
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void dgvDetailPrestation_RowsRemoved(object sender, DataGridViewRowsRemovedEventArgs e)
        {
            lesConsommablesPrestations.RemoveAt(laPrestationSelectionee);
        }
        #endregion
        /// <summary>
        /// Le controle sur les caractères saisie dans le textBox txtQuantite afin qu'il n'y ai que des chiffres
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void txtQuantite_KeyUp(object sender, KeyEventArgs e)
        {

            if (!(float.TryParse(txtQuantite.Text, out float result)))
            {
                lblErreurInt.Text = "Vous devez rentrer que des chiffres";
            }
            else
            {
                lblErreurInt.Text = "";
                if (combConsommable.SelectedIndex != -1)
                {
                    lblSommeCoutCredits.Text = (float.Parse(txtQuantite.Text) * ((Consommable)combConsommable.SelectedItem).PrixConsommable).ToString();
                }
            }
        }
        #region bouton dynamique
        /// <summary>
        ///Évenement entrer souris sur le pictureBox 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void pictAjouterLigne_MouseEnter(object sender, EventArgs e)
        {
            pictAjouterLigne.SizeMode = PictureBoxSizeMode.StretchImage;
        }
        /// <summary>
        /// Évenement sortie souris sur le pictureBox
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void pictAjouterLigne_MouseLeave(object sender, EventArgs e)
        {
            pictAjouterLigne.SizeMode = PictureBoxSizeMode.CenterImage;
        }
        /// <summary>
        /// Évenement entrer souris sur le pictureBox
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void pictSauvegarder_MouseEnter(object sender, EventArgs e)
        {
            pictSauvegarder.SizeMode = PictureBoxSizeMode.StretchImage;
        }
        /// <summary>
        /// Évenement sortie souris sur le pictureBox
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void pictSauvegarder_MouseLeave(object sender, EventArgs e)
        {
            pictSauvegarder.SizeMode = PictureBoxSizeMode.CenterImage;
        }
        /// <summary>
        /// Évenement entrer souris sur le pictureBox
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void pictAnnuler_MouseEnter(object sender, EventArgs e)
        {
            pictAnnuler.SizeMode = PictureBoxSizeMode.StretchImage;
        }
        /// <summary>
        /// Évenement sortie souris sur le pictureBox
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void pictAnnuler_MouseLeave(object sender, EventArgs e)
        {
            pictAnnuler.SizeMode = PictureBoxSizeMode.CenterImage;
        }
        #endregion
        
    }
}
