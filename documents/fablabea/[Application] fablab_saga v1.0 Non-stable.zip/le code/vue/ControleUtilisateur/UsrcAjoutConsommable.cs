﻿using fablab_saga.model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace fablab_saga.vue.ControleUtilisateur
{
    public partial class UsrcAjoutConsommable : UserControl
    {
        /// <summary>
        /// L'instance de formulaire parent
        /// </summary>
        private FrmPrincipal frmPrincipale;
        /// <summary>
        /// L'identifiant de connexion
        /// </summary>
        private string identifiant;
        /// <summary>
        /// liste des types de consommable
        /// </summary>
        private BindingSource lesTypesConsommables = new BindingSource();
        /// <summary>
        /// liste des sous types de consommable
        /// </summary>
        private BindingSource lesSousTypesConsommables = new BindingSource();
        /// <summary>
        /// liste des unité
        /// </summary>
        private BindingSource lesUnites = new BindingSource();
        /// <summary>
        /// Le consommable utilisé en cas de modification
        /// </summary>
        private Consommable unConsommable;
        /// <summary>
        /// Constructeur
        /// </summary>
        /// <param name="frmPrincipal">L'instance du formulaire parent</param>
        /// <param name="identifiant">l'identifiant utilisé lors de la connexion</param>
        public UsrcAjoutConsommable(FrmPrincipal frmPrincipal, string identifiant)
        {
            this.frmPrincipale = frmPrincipal;
            this.identifiant = identifiant;
            InitializeComponent();
        }
        /// <summary>
        /// surcharge du Constructeur pour une modififcation
        /// </summary>
        /// <param name="frmPrincipal">L'instance du formulaire parent</param>
        /// <param name="identifiant">l'identifiant utilisé lors de la connexion</param>
        public UsrcAjoutConsommable(FrmPrincipal frmPrincipal, string identifiant, Consommable unConsommable)
        {
            this.unConsommable = unConsommable;
            this.frmPrincipale = frmPrincipal;
            this.identifiant = identifiant;
            InitializeComponent();
        }
        /// <summary>
        /// Initialisation du formualre
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void UsrcAjoutConsommable_Load(object sender, EventArgs e)
        {
            lblNomIdentifiant.Text = identifiant;
            lesTypesConsommables.DataSource = frmPrincipale.GetLesTypesConsommables();
            lesSousTypesConsommables.DataSource = frmPrincipale.GetLesSousTypesConsommables();
            RemplissageAllComboBox();
            List<string> lesUnites = new List<string>();
            foreach (TypeConsommable unTypeConsommable in lesTypesConsommables)
            {
                lesUnites.Add(unTypeConsommable.UniteConsommable);
            }
            this.lesUnites.DataSource = lesUnites;
            combUnite.SelectedIndex = -1;
            //Permet de remplir le UserControl avec un consommable en mode modification
            if(unConsommable != null)
            {
                btnSupprimerConsommable.Visible = true;
                lblTitre.Text = "Mode : Modifier un consommable";
                foreach (TypeConsommable unType in lesTypesConsommables)
                {
                    if (unConsommable.IdTypeConsommable.Equals(unType.IdTypeConsommable))
                    {
                        combTypeConsommable.SelectedItem = unType;
                    }
                }
                foreach (SousTypeConsommable unSousType in lesSousTypesConsommables)
                {
                    if (unConsommable.IdSousTypeConsommable.Equals(unSousType.IdSousTypeConsommable))
                    {
                        combSousType.SelectedItem = unSousType;
                    }
                }
                txtLibelle.Text = unConsommable.LibelleConsommable;
                txtPrix.Text = unConsommable.PrixConsommable.ToString();
            }
        }
        /// <summary>
        /// Permet de réinitialiser le formulaire apres l'ajout d'un nouveau consommable 
        /// </summary>
        private void ResetUserControl()
        {
            rbtnTypeConsommable.Checked = true;
            rbtnSousTypeConsommable.Checked = true;
            rbtnUnite.Checked = true;
            combTypeConsommable.SelectedIndex = -1;
            combSousType.SelectedIndex = -1;
            combUnite.SelectedIndex = -1;
            txtLibelle.Text = "";
            txtPrix.Text = "";
        }
        /// <summary>
        /// Permet de lancer la précédure de remplissage des comnboBox
        /// </summary>
        private void RemplissageAllComboBox()
        {
            RemplissageComboBox(combTypeConsommable, lesTypesConsommables, "LeTypeConsommable");
            RemplissageComboBox(combSousType, lesSousTypesConsommables, "Libelle");
            combUnite.DataSource = lesUnites;
            combUnite.SelectedIndex = -1;
        }
        /// <summary>
        /// Permet de remplir un comboBox avec n'importe BingdingSource
        /// </summary>
        /// <param name="unCombo">le comboBox à remplir</param>
        /// <param name="uneBdgs">le BingdingSource ç utiliser pour le remplir</param>
        /// <param name="nomPropriete">la propriété à afficher dans le comboBox</param>
        private void RemplissageComboBox(ComboBox unCombo, BindingSource uneBdgs, string nomPropriete)
        {
            unCombo.DataSource = null;
            unCombo.DataSource = uneBdgs;
            unCombo.DisplayMember = nomPropriete;
            unCombo.ValueMember = nomPropriete;
            unCombo.SelectedIndex = -1;
        }
        /// <summary>
        /// Évenement si le check de rbtnTypeConsommable change
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void rbtnTypeConsommable_CheckedChanged(object sender, EventArgs e)
        {
            if (rbtnTypeConsommable.Checked)
            {
                combTypeConsommable.Enabled = true;
                txtNewTypeConsommable.Enabled = false;
            }
            else
            {
                combTypeConsommable.Enabled = false;
                txtNewTypeConsommable.Enabled = true;
                grbSelecUnite.Enabled = true;
                combUnite.SelectedIndex = -1;
            }
        }
        /// <summary>
        /// Évenement si le check de rbtnSousTypeConsommable change
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void rbtnSousTypeConsommable_CheckedChanged(object sender, EventArgs e)
        {
            if (rbtnSousTypeConsommable.Checked)
            {
                combSousType.Enabled = true;
                txtNewSousType.Enabled = false;
            }
            else
            {
                combSousType.Enabled = false;
                txtNewSousType.Enabled = true;
            }
        }
        /// <summary>
        ///Évenement si le check de rbtnSousTypeConsommable change
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void rbtnUnite_CheckedChanged(object sender, EventArgs e)
        {
            if (rbtnUnite.Checked)
            {
                combUnite.Enabled = true;
                txtNewUnite.Enabled = false;
            }
            else
            {
                combUnite.Enabled = false;
                txtNewUnite.Enabled = true;
            }
        }
        /// <summary>
        /// Évenement lors d'un changement de selection dans le comboBox combTypeConsommable, lancant la méthode
        /// RemplirCombSousTypeConsommable
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void combTypeConsommable_SelectionChange(object sender, EventArgs e)
        {
            if (combTypeConsommable.SelectedIndex != -1)
            {
                combSousType.Enabled = true;
                RemplirCombSousTypeConsommable((TypeConsommable)combTypeConsommable.SelectedItem);
                combUnite.SelectedItem = ((TypeConsommable)combTypeConsommable.SelectedItem).UniteConsommable;
                grbSelecUnite.Enabled = false;
                
            }
        }
        /// <summary>
        /// Remplissage du comboBox CombSousTypeConsommable
        /// </summary>
        /// <param name="unType">le type du consommable permettant de récupérer que les sous types correspondant</param>
        private void RemplirCombSousTypeConsommable(TypeConsommable unType)
        {
            BindingSource sousType = new BindingSource();
            foreach (SousTypeConsommable unSousType in lesSousTypesConsommables)
            {
                if (unSousType.IdTypeConsommable.Equals(unType.IdTypeConsommable))
                {
                    sousType.Add(unSousType);
                }
            }
            RemplissageComboBox(combSousType, sousType, "Libelle");
        }
        /// <summary>
        /// Évenement lors du clique sur le bouton pictSauvegerder
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void pictSauvegarder_Click(object sender, EventArgs e)
        {
            //Permet d'instancier ou de créer les objets permettant de créer un consommables
            TypeConsommable unTypeConsommable = null;
            bool newType = false;
            SousTypeConsommable unSousTypeConsommable = null;
            bool newSousType = false;
            string unite = null;
            if (rbtnUnite.Checked && combUnite.SelectedIndex != -1)
            {
                unite = combUnite.SelectedItem.ToString();
            }
            else
            {
                if (!txtNewUnite.Text.Equals(""))
                {
                    unite = txtNewUnite.Text;
                }
            }
            if (rbtnTypeConsommable.Checked)
            {
                unTypeConsommable = ((TypeConsommable)combTypeConsommable.SelectedItem);
            }
            else
            {
                if(!txtNewTypeConsommable.Text.Equals(""))
                {
                    unTypeConsommable = new TypeConsommable(1, txtNewTypeConsommable.Text, unite);
                    newType = true;
                }
            }
            if (rbtnSousTypeConsommable.Checked)
            {
                unSousTypeConsommable = (SousTypeConsommable)combSousType.SelectedItem;
            }
            else
            {
                if (!txtNewSousType.Text.Equals(""))
                {
                    unSousTypeConsommable = new SousTypeConsommable(1, unTypeConsommable.IdTypeConsommable, txtNewSousType.Text);
                    newSousType = true;
                }
            }
            //Vérifie que tous les champs soient remplis correctement
            if(unTypeConsommable != null && unSousTypeConsommable != null && unite != null && !txtLibelle.Text.Equals("") && (float.TryParse(txtPrix.Text, out float result)))
            {
                DialogResult dialogResult = MessageBox.Show("Vous êtes sur le point de créer ou modifier le consommable de type :[" + 
                    unTypeConsommable.LeTypeConsommable + "], de sous type :[" + unSousTypeConsommable.Libelle + "], d'une unité :[" + 
                    unite + "], nommé :[" + txtLibelle.Text + "] et de prix :[" + txtPrix.Text + "] \n\n Voulez vous continuer ?", 
                    "Confirmation de création d'un consommable", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (dialogResult.Equals(DialogResult.Yes))
                {
                    if (newType)
                    {
                        frmPrincipale.AjoutNewTypeConsommable(unTypeConsommable);
                        //Une sécurité permettant de laisser le temps à la base de données de créer la requete précédante en cas de lag
                        System.Threading.Thread.Sleep(500);
                        unTypeConsommable = frmPrincipale.RecupUnTypeConsommable(unTypeConsommable.LeTypeConsommable, unTypeConsommable.UniteConsommable);
                    }
                    if (newSousType)
                    {
                        unSousTypeConsommable.IdTypeConsommable = unTypeConsommable.IdTypeConsommable;
                        frmPrincipale.AjoutSousTypeConsommable(unSousTypeConsommable);
                        //Une sécurité permettant de laisser le temps à la base de données de créer la requete précédante en cas de lag
                        System.Threading.Thread.Sleep(2000);
                        unSousTypeConsommable = frmPrincipale.RecupUnSousTypeConsommable(unSousTypeConsommable.IdTypeConsommable, unSousTypeConsommable.Libelle);
                    }
                    Consommable unNewConsommable = new Consommable(1, unTypeConsommable.IdTypeConsommable, unSousTypeConsommable.IdSousTypeConsommable, txtLibelle.Text, float.Parse(txtPrix.Text));
                    //Permet de controler si on est en mode modification ou ajout
                    if(this.unConsommable is null)
                    {
                        frmPrincipale.AjoutConsommable(unNewConsommable);
                        MessageBox.Show("Nouveau consommable ajouter avec succés !", "Confirmation d'ajout d'un nouveau consommable", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        ResetUserControl();
                    }
                    else
                    {
                        
                        if(unNewConsommable.IdTypeConsommable.Equals(unConsommable.IdTypeConsommable) && 
                            unNewConsommable.IdSousTypeConsommable.Equals(unConsommable.IdSousTypeConsommable) && 
                            unNewConsommable.LibelleConsommable.Equals(unConsommable.LibelleConsommable) && unNewConsommable.PrixConsommable.Equals(unConsommable.PrixConsommable))
                        {
                            MessageBox.Show("Tous les champs sont identique à l'objet initiale, faite des modifications afin de sauvegarder", "Champs Identiques", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        else
                        {
                            unNewConsommable.IdConsommable = unConsommable.IdConsommable;
                            frmPrincipale.ModificationConsommable(unNewConsommable);
                            MessageBox.Show("Consommable modifié avec succés !", "Confirmation de modification d'un consommable", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                    }
                    
                }
            }
            else
            {
                MessageBox.Show("Tous les champs selectionnés doivent être rempli dans le bon format pour continuer", "Champs vide(s)", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
        /// <summary>
        /// Le controle sur les caractères saisie dans le textBox txtQuantite afin qu'il n'y ai que des chiffres
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void txtPrix_KeyUp(object sender, KeyEventArgs e)
        {

            if (!(float.TryParse(txtPrix.Text, out float result)))
            {
                lblErreurInt.Text = "Vous devez rentrer que des chiffres";
            }
            else
            {
                lblErreurInt.Text = "";
            }
        }
        /// <summary>
        /// Évenement lors du clique sur le bouton pictAnnuler
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void pictAnnuler_Click(object sender, EventArgs e)
        {
            frmPrincipale.RetourMenuAdmin();
        }
        #region bouton dynamique
        /// <summary>
        /// Évenement entrer souris sur le pictureBox
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void pictSauvegarder_MouseEnter(object sender, EventArgs e)
        {
            pictSauvegarder.SizeMode = PictureBoxSizeMode.StretchImage;
        }
        /// <summary>
        /// Évenement sortie souris sur le pictureBox
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void pictSauvegarder_MouseLeave(object sender, EventArgs e)
        {
            pictSauvegarder.SizeMode = PictureBoxSizeMode.CenterImage;
        }
        /// <summary>
        /// Évenement entrer souris sur le pictureBox
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void pictAnnuler_MouseEnter(object sender, EventArgs e)
        {
            pictAnnuler.SizeMode = PictureBoxSizeMode.StretchImage;
        }
        /// <summary>
        /// Évenement sortie souris sur le pictureBox
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void pictAnnuler_MouseLeave(object sender, EventArgs e)
        {
            pictAnnuler.SizeMode = PictureBoxSizeMode.CenterImage;
        }
        #endregion

        private void btnSupprimerConsommable_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show("Vous êtes sur le point de supprimer le consommable de type :[" +
                    ((TypeConsommable)combTypeConsommable.SelectedItem).LeTypeConsommable + "], de sous type :[" + ((SousTypeConsommable)combSousType.SelectedItem).Libelle + "], d'une unité :[" +
                    combUnite.SelectedItem.ToString() + "], nommé :[" + txtLibelle.Text + "] et de prix :[" + txtPrix.Text + "] \n\n Voulez vous continuer ?",
                    "Confirmation de création d'un consommable", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (dialogResult.Equals(DialogResult.Yes))
            {
                if(!frmPrincipale.RecupIDTableBdd("consommable_prestation", unConsommable.IdConsommable, "IDCONSOMMABLE"))
                {
                    frmPrincipale.SuppressionConsommable(unConsommable);
                    MessageBox.Show("Consommable supprimé avec succés !", "Confirmation de suppression d'un consommable", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    pictAnnuler_Click(null, null);
                }
                else
                {
                    MessageBox.Show("Impossible de supprimer ce consommable.\n\n " +
                            "[Code erreur 3 : Instabilité de l'intégrité réfèrentiel du SGBDR]\n\nImpossible de supprimer ce consommable " +
                            "parcequ'il est déjà utilisé dans une prestation", "Une erreur est survenue", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                    
            }
        }
    }
}
