﻿
namespace fablab_saga.vue.ControleUtilisateur
{
    partial class UsrcHistorique
    {
        /// <summary> 
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Code généré par le Concepteur de composants

        /// <summary> 
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas 
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgvListePrestation = new System.Windows.Forms.DataGridView();
            this.evenement = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.date = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.typePrestation = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.libelle = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.montant = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgvDetailPrestation = new System.Windows.Forms.DataGridView();
            this.btnSupprimer = new System.Windows.Forms.Button();
            this.btnRetourAdherent = new System.Windows.Forms.Button();
            this.lblNomIdentifiant = new System.Windows.Forms.Label();
            this.lblIdentifiant = new System.Windows.Forms.Label();
            this.lblNomPrenomAdherent = new System.Windows.Forms.Label();
            this.lblAdherent = new System.Windows.Forms.Label();
            this.combTrier = new System.Windows.Forms.ComboBox();
            this.lblFiltre = new System.Windows.Forms.Label();
            this.libelleConsommable = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.quantite = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.unite = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.prix = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.montantDetail = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dgvListePrestation)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDetailPrestation)).BeginInit();
            this.SuspendLayout();
            // 
            // dgvListePrestation
            // 
            this.dgvListePrestation.AllowUserToAddRows = false;
            this.dgvListePrestation.AllowUserToDeleteRows = false;
            this.dgvListePrestation.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvListePrestation.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvListePrestation.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.evenement,
            this.date,
            this.typePrestation,
            this.libelle,
            this.montant});
            this.dgvListePrestation.Location = new System.Drawing.Point(44, 57);
            this.dgvListePrestation.Name = "dgvListePrestation";
            this.dgvListePrestation.ReadOnly = true;
            this.dgvListePrestation.Size = new System.Drawing.Size(931, 304);
            this.dgvListePrestation.TabIndex = 0;
            this.dgvListePrestation.SelectionChanged += new System.EventHandler(this.dgvListePrestation_SelectionChanged);
            // 
            // evenement
            // 
            this.evenement.HeaderText = "Événement";
            this.evenement.Name = "evenement";
            this.evenement.ReadOnly = true;
            // 
            // date
            // 
            this.date.HeaderText = "Date";
            this.date.Name = "date";
            this.date.ReadOnly = true;
            // 
            // typePrestation
            // 
            this.typePrestation.HeaderText = "Type de prestation";
            this.typePrestation.Name = "typePrestation";
            this.typePrestation.ReadOnly = true;
            // 
            // libelle
            // 
            this.libelle.HeaderText = "Libellé";
            this.libelle.Name = "libelle";
            this.libelle.ReadOnly = true;
            // 
            // montant
            // 
            this.montant.HeaderText = "Montant";
            this.montant.Name = "montant";
            this.montant.ReadOnly = true;
            // 
            // dgvDetailPrestation
            // 
            this.dgvDetailPrestation.AllowUserToAddRows = false;
            this.dgvDetailPrestation.AllowUserToDeleteRows = false;
            this.dgvDetailPrestation.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvDetailPrestation.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDetailPrestation.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.libelleConsommable,
            this.quantite,
            this.unite,
            this.prix,
            this.montantDetail});
            this.dgvDetailPrestation.Location = new System.Drawing.Point(44, 505);
            this.dgvDetailPrestation.Name = "dgvDetailPrestation";
            this.dgvDetailPrestation.ReadOnly = true;
            this.dgvDetailPrestation.Size = new System.Drawing.Size(931, 180);
            this.dgvDetailPrestation.TabIndex = 1;
            this.dgvDetailPrestation.Visible = false;
            // 
            // btnSupprimer
            // 
            this.btnSupprimer.Font = new System.Drawing.Font("Lucida Console", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSupprimer.Location = new System.Drawing.Point(44, 375);
            this.btnSupprimer.Name = "btnSupprimer";
            this.btnSupprimer.Size = new System.Drawing.Size(148, 51);
            this.btnSupprimer.TabIndex = 49;
            this.btnSupprimer.Text = "Supprimer";
            this.btnSupprimer.UseVisualStyleBackColor = true;
            this.btnSupprimer.Click += new System.EventHandler(this.btnSupprimer_Click);
            // 
            // btnRetourAdherent
            // 
            this.btnRetourAdherent.Font = new System.Drawing.Font("Lucida Console", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRetourAdherent.Location = new System.Drawing.Point(742, 375);
            this.btnRetourAdherent.Name = "btnRetourAdherent";
            this.btnRetourAdherent.Size = new System.Drawing.Size(233, 51);
            this.btnRetourAdherent.TabIndex = 50;
            this.btnRetourAdherent.Text = "Revenir à l\'adhérent";
            this.btnRetourAdherent.UseVisualStyleBackColor = true;
            this.btnRetourAdherent.Click += new System.EventHandler(this.btnRetourAdherent_Click);
            // 
            // lblNomIdentifiant
            // 
            this.lblNomIdentifiant.AutoSize = true;
            this.lblNomIdentifiant.BackColor = System.Drawing.Color.Transparent;
            this.lblNomIdentifiant.Font = new System.Drawing.Font("Lucida Console", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNomIdentifiant.Location = new System.Drawing.Point(265, 20);
            this.lblNomIdentifiant.Name = "lblNomIdentifiant";
            this.lblNomIdentifiant.Size = new System.Drawing.Size(178, 16);
            this.lblNomIdentifiant.TabIndex = 52;
            this.lblNomIdentifiant.Text = "<nom utilisateur>";
            // 
            // lblIdentifiant
            // 
            this.lblIdentifiant.AutoSize = true;
            this.lblIdentifiant.BackColor = System.Drawing.Color.Transparent;
            this.lblIdentifiant.Font = new System.Drawing.Font("Lucida Console", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIdentifiant.Location = new System.Drawing.Point(21, 20);
            this.lblIdentifiant.Name = "lblIdentifiant";
            this.lblIdentifiant.Size = new System.Drawing.Size(238, 16);
            this.lblIdentifiant.TabIndex = 51;
            this.lblIdentifiant.Text = "Connecté en temps que :";
            // 
            // lblNomPrenomAdherent
            // 
            this.lblNomPrenomAdherent.AutoSize = true;
            this.lblNomPrenomAdherent.BackColor = System.Drawing.Color.Transparent;
            this.lblNomPrenomAdherent.Font = new System.Drawing.Font("Lucida Console", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNomPrenomAdherent.Location = new System.Drawing.Point(743, 20);
            this.lblNomPrenomAdherent.Name = "lblNomPrenomAdherent";
            this.lblNomPrenomAdherent.Size = new System.Drawing.Size(178, 16);
            this.lblNomPrenomAdherent.TabIndex = 54;
            this.lblNomPrenomAdherent.Text = "<nom utilisateur>";
            // 
            // lblAdherent
            // 
            this.lblAdherent.AutoSize = true;
            this.lblAdherent.BackColor = System.Drawing.Color.Transparent;
            this.lblAdherent.Font = new System.Drawing.Font("Lucida Console", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAdherent.Location = new System.Drawing.Point(629, 20);
            this.lblAdherent.Name = "lblAdherent";
            this.lblAdherent.Size = new System.Drawing.Size(108, 16);
            this.lblAdherent.TabIndex = 53;
            this.lblAdherent.Text = "Adhérent :";
            // 
            // combTrier
            // 
            this.combTrier.FormattingEnabled = true;
            this.combTrier.Location = new System.Drawing.Point(435, 403);
            this.combTrier.Name = "combTrier";
            this.combTrier.Size = new System.Drawing.Size(121, 21);
            this.combTrier.TabIndex = 55;
            this.combTrier.SelectionChangeCommitted += new System.EventHandler(this.combTrier_SelectionChangeCommitted);
            // 
            // lblFiltre
            // 
            this.lblFiltre.AutoSize = true;
            this.lblFiltre.BackColor = System.Drawing.Color.Transparent;
            this.lblFiltre.Font = new System.Drawing.Font("Lucida Console", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFiltre.Location = new System.Drawing.Point(426, 375);
            this.lblFiltre.Name = "lblFiltre";
            this.lblFiltre.Size = new System.Drawing.Size(148, 16);
            this.lblFiltre.TabIndex = 56;
            this.lblFiltre.Text = "Trier depuis :";
            // 
            // libelleConsommable
            // 
            this.libelleConsommable.HeaderText = "Consommable utilisé";
            this.libelleConsommable.Name = "libelleConsommable";
            this.libelleConsommable.ReadOnly = true;
            // 
            // quantite
            // 
            this.quantite.HeaderText = "Quantité";
            this.quantite.Name = "quantite";
            this.quantite.ReadOnly = true;
            // 
            // unite
            // 
            this.unite.HeaderText = "Unité";
            this.unite.Name = "unite";
            this.unite.ReadOnly = true;
            // 
            // prix
            // 
            this.prix.HeaderText = "Prix unitaire";
            this.prix.Name = "prix";
            this.prix.ReadOnly = true;
            // 
            // montantDetail
            // 
            this.montantDetail.HeaderText = "Montant";
            this.montantDetail.Name = "montantDetail";
            this.montantDetail.ReadOnly = true;
            // 
            // UsrcHistorique
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Transparent;
            this.Controls.Add(this.lblIdentifiant);
            this.Controls.Add(this.lblNomIdentifiant);
            this.Controls.Add(this.lblAdherent);
            this.Controls.Add(this.lblNomPrenomAdherent);
            this.Controls.Add(this.dgvListePrestation);
            this.Controls.Add(this.btnSupprimer);
            this.Controls.Add(this.lblFiltre);
            this.Controls.Add(this.combTrier);
            this.Controls.Add(this.btnRetourAdherent);
            this.Controls.Add(this.dgvDetailPrestation);
            this.Name = "UsrcHistorique";
            this.Size = new System.Drawing.Size(1024, 768);
            this.Load += new System.EventHandler(this.UsrcHistorique_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvListePrestation)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDetailPrestation)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgvListePrestation;
        private System.Windows.Forms.DataGridView dgvDetailPrestation;
        private System.Windows.Forms.Button btnSupprimer;
        private System.Windows.Forms.Button btnRetourAdherent;
        private System.Windows.Forms.Label lblNomIdentifiant;
        private System.Windows.Forms.Label lblIdentifiant;
        private System.Windows.Forms.Label lblNomPrenomAdherent;
        private System.Windows.Forms.Label lblAdherent;
        private System.Windows.Forms.DataGridViewTextBoxColumn evenement;
        private System.Windows.Forms.DataGridViewTextBoxColumn date;
        private System.Windows.Forms.DataGridViewTextBoxColumn typePrestation;
        private System.Windows.Forms.DataGridViewTextBoxColumn libelle;
        private System.Windows.Forms.DataGridViewTextBoxColumn montant;
        private System.Windows.Forms.ComboBox combTrier;
        private System.Windows.Forms.Label lblFiltre;
        private System.Windows.Forms.DataGridViewTextBoxColumn libelleConsommable;
        private System.Windows.Forms.DataGridViewTextBoxColumn quantite;
        private System.Windows.Forms.DataGridViewTextBoxColumn unite;
        private System.Windows.Forms.DataGridViewTextBoxColumn prix;
        private System.Windows.Forms.DataGridViewTextBoxColumn montantDetail;
    }
}
