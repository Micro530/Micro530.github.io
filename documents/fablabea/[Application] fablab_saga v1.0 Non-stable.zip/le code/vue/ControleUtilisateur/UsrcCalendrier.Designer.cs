﻿
namespace fablab_saga.vue.ControleUtilisateur
{
    partial class UsrcCalendrier
    {
        /// <summary> 
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Code généré par le Concepteur de composants

        /// <summary> 
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas 
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent()
        {
            this.combJour = new System.Windows.Forms.ComboBox();
            this.combMois = new System.Windows.Forms.ComboBox();
            this.combAnnee = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.lblDateNaissance = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // combJour
            // 
            this.combJour.FormattingEnabled = true;
            this.combJour.Location = new System.Drawing.Point(12, 69);
            this.combJour.Name = "combJour";
            this.combJour.Size = new System.Drawing.Size(90, 21);
            this.combJour.TabIndex = 0;
            this.combJour.SelectedIndexChanged += new System.EventHandler(this.combJour_SelectedIndexChanged);
            // 
            // combMois
            // 
            this.combMois.FormattingEnabled = true;
            this.combMois.Location = new System.Drawing.Point(125, 69);
            this.combMois.Name = "combMois";
            this.combMois.Size = new System.Drawing.Size(90, 21);
            this.combMois.TabIndex = 1;
            this.combMois.SelectedIndexChanged += new System.EventHandler(this.combJour_SelectedIndexChanged);
            // 
            // combAnnee
            // 
            this.combAnnee.FormattingEnabled = true;
            this.combAnnee.Location = new System.Drawing.Point(236, 69);
            this.combAnnee.Name = "combAnnee";
            this.combAnnee.Size = new System.Drawing.Size(90, 21);
            this.combAnnee.TabIndex = 2;
            this.combAnnee.SelectedIndexChanged += new System.EventHandler(this.combJour_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Lucida Console", 12F);
            this.label1.Location = new System.Drawing.Point(32, 50);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(48, 16);
            this.label1.TabIndex = 3;
            this.label1.Text = "Jour";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Lucida Console", 12F);
            this.label2.Location = new System.Drawing.Point(149, 50);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(48, 16);
            this.label2.TabIndex = 4;
            this.label2.Text = "Mois";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Lucida Console", 12F);
            this.label3.Location = new System.Drawing.Point(257, 50);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(58, 16);
            this.label3.TabIndex = 5;
            this.label3.Text = "Année";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("Lucida Console", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(72, 11);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(198, 16);
            this.label7.TabIndex = 22;
            this.label7.Text = "Date de naissance :";
            // 
            // lblDateNaissance
            // 
            this.lblDateNaissance.Font = new System.Drawing.Font("Lucida Console", 12F);
            this.lblDateNaissance.Location = new System.Drawing.Point(0, 120);
            this.lblDateNaissance.Name = "lblDateNaissance";
            this.lblDateNaissance.Size = new System.Drawing.Size(340, 28);
            this.lblDateNaissance.TabIndex = 23;
            this.lblDateNaissance.Text = "<date>";
            this.lblDateNaissance.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Calendrier
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Transparent;
            this.Controls.Add(this.lblDateNaissance);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.combAnnee);
            this.Controls.Add(this.combMois);
            this.Controls.Add(this.combJour);
            this.Name = "Calendrier";
            this.Size = new System.Drawing.Size(340, 150);
            this.Load += new System.EventHandler(this.Calendrier_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox combJour;
        private System.Windows.Forms.ComboBox combMois;
        private System.Windows.Forms.ComboBox combAnnee;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label lblDateNaissance;
    }
}
