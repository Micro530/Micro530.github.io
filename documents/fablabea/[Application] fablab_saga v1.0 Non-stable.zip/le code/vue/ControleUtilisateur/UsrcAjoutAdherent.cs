﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace fablab_saga.vue.ControleUtilisateur
{
    public partial class UsrcAjoutAdherent : UserControl
    {
        private FrmPrincipal frmPrincipal;
        private string identifiant;

        public UsrcAjoutAdherent(FrmPrincipal frmPrincipal, string identifiant)
        {
            this.identifiant = identifiant;
            this.frmPrincipal = frmPrincipal;
            InitializeComponent();
        }



        //pour envoyer un mail
        /// <summary>
        /// Envoie un mail au destiataire <param name="to">
        /// </summary>
        /// <param name="to">Destiataire recevant le mail</param>
        public static void EnvoieMail(string to)
        {
            //code source //un peu modifier quand meme
            //https://docs.microsoft.com/fr-fr/dotnet/api/system.net.mail.smtpclient.send?view=net-5.0

            string server = "gmail.com";            
            string from = "ben@contoso.com";//quel boite mail ENvoi le mail
            
            MailMessage message = new MailMessage(from, to);
            message.Subject = "FabLab 64.";//Objet du mail
            message.Body = "Confiramation d'inscription.";//le contenu du mail
            
            SmtpClient client = new SmtpClient(server);
            // Credentials are necessary if the server requires the client
            // to authenticate before it will send email on the client's behalf.
            client.UseDefaultCredentials = true;

            try
            {
                client.Send(message);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception caught in CreateTestMessage2(): {0}",
                    ex.ToString());
            }
        }

        private void pictbSauvegerder_MouseEnter(object sender, EventArgs e)
        {
            pictbSauvegerder.SizeMode = PictureBoxSizeMode.StretchImage;
        }

        private void pictbSauvegerder_MouseLeave(object sender, EventArgs e)
        {
            pictbSauvegerder.SizeMode = PictureBoxSizeMode.CenterImage;
        }

        private void pictbAnnuler_MouseEnter(object sender, EventArgs e)
        {
            pictbAnnuler.SizeMode = PictureBoxSizeMode.StretchImage;
        }

        private void pictbAnnuler_MouseLeave(object sender, EventArgs e)
        {
            pictbAnnuler.SizeMode = PictureBoxSizeMode.CenterImage;
        }

        private void UsrcAjoutAdherent_Load(object sender, EventArgs e)
        {
            lblNomIdentifiant.Text = identifiant;
        }

        private void pictbAnnuler_Click(object sender, EventArgs e)
        {
            frmPrincipal.RetourMenu();
        }
        private void ViderChamps()
        {
            txtNomAdherent.Text = "";
            txtPrenomAdherent.Text = "";
            txtTelephoneAdherent.Text = "";
            txtEmailAdherent.Text = "";
            calendrier.ResetComboBox();
        }
        /// <summary>
        /// Évenement clique sur le bouton btnSauvegarder, vérifie les champs puis envoie les info du nouvel adherent
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void pictbSauvegerder_Click(object sender, EventArgs e)
        {
            if(!(txtNomAdherent.Text.Equals("") || txtPrenomAdherent.Text.Equals("") || txtTelephoneAdherent.Text.Equals("") ||
                txtEmailAdherent.Text.Equals("") || !calendrier.SelectionDateNaissance()))
            {
                frmPrincipal.AjoutAdherent(txtNomAdherent.Text, txtPrenomAdherent.Text, 
                    txtTelephoneAdherent.Text, txtEmailAdherent.Text, calendrier.GetDateNaissance());
                MessageBox.Show("Adhérent ajouter avec succès", "Confirmation d'ajouter d'un adherent", MessageBoxButtons.OK, MessageBoxIcon.Information);
                ViderChamps();
            }
            else
            {
                MessageBox.Show("Tous les champs doivent être remplis pour continuer", "Champ(s) vide(s)", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
