﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace fablab_saga.vue.ControleUtilisateur
{
    public partial class UsrcMenuAdministrateur : UserControl
    {
        /// <summary>
        /// L'instance de formulaire parent
        /// </summary>
        private FrmPrincipal frmPrincipal;
        /// <summary>
        /// L'identifiant de connexion
        /// </summary>
        private string identifiant;
        /// <summary>
        /// Constructeur
        /// </summary>
        /// <param name="frmPrincipal">L'instance du formulaire parent</param>
        /// <param name="identifiant">l'identifiant utilisé lors de la connexion</param>
        public UsrcMenuAdministrateur(FrmPrincipal frmPrincipal, string identifiant)
        {
            this.frmPrincipal = frmPrincipal;
            this.identifiant = identifiant;
            InitializeComponent();
        }
        /// <summary>
        /// Au chargement du UserControl
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void UsrcMenuAdministrateur_Load(object sender, EventArgs e)
        {
            lblNomIdentifiant.Text = identifiant;
        }
        #region Bouton Dynamique
        /// <summary>
        /// Évenement lors de l'entrer de la souris sur le PictbAjouterAdherent
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void PictbAjouterAdherent_MouseEnter(object sender, EventArgs e)
        {
            pictbAjouterConsommable.SizeMode = PictureBoxSizeMode.StretchImage;
        }
        /// <summary>
        /// Évenement lors de la sortie de la souris sur le PictbAjouterAdherent
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void PictbAjouterAdherent_MouseLeave(object sender, EventArgs e)
        {
            pictbAjouterConsommable.SizeMode = PictureBoxSizeMode.CenterImage;
        }
        /// <summary>
        /// Évenement lors de l'entrer de la souris sur le PictbRechercher
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void PictbRechercher_MouseEnter(object sender, EventArgs e)
        {
            pictbRechercherConsommable.SizeMode = PictureBoxSizeMode.StretchImage;
        }
        /// <summary>
        /// Évenement lors de la sortie de la souris sur le PictbRechercher
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void PictbRechercher_MouseLeave(object sender, EventArgs e)
        {
            pictbRechercherConsommable.SizeMode = PictureBoxSizeMode.CenterImage;
        }
        /// <summary>
        /// Évenement lors de l'entrer de la souris sur le PictbRechercher
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void PictbRechercherTypePrestation_MouseEnter(object sender, EventArgs e)
        {
            pictConsulterTypePrestation.SizeMode = PictureBoxSizeMode.StretchImage;
        }
        /// <summary>
        /// Évenement lors de la sortie de la souris sur le PictbRechercher
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void PictbRechercherTypePrestation_MouseLeave(object sender, EventArgs e)
        {
            pictConsulterTypePrestation.SizeMode = PictureBoxSizeMode.CenterImage;
        }
        #endregion
        private void pictConsulterTypePrestation_Click(object sender, EventArgs e)
        {
            frmPrincipal.CreationConsultationTypePrestation();
        }
        /// <summary>
        /// Évenement clique sur le btnRetourMenu
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnRetourMenu_Click(object sender, EventArgs e)
        {
            frmPrincipal.RetourMenu();
        }
        /// <summary>
        /// Évenement clique ajout consommable
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void pictbAjouterConsommable_Click(object sender, EventArgs e)
        {
            frmPrincipal.CreationAjoutModificationConsommable();
        }
        /// <summary>
        ///Évenement recherche consommable 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void pictbRechercherConsommable_Click(object sender, EventArgs e)
        {
            frmPrincipal.CreationRechercheConsommable();
        }
    }
}
