﻿
namespace fablab_saga.vue.ControleUtilisateur
{
    partial class UsrcRechercherConsommable
    {
        /// <summary> 
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Code généré par le Concepteur de composants

        /// <summary> 
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas 
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent()
        {
            this.combSousTypeConsommable = new System.Windows.Forms.ComboBox();
            this.lblSousType = new System.Windows.Forms.Label();
            this.combLibelle = new System.Windows.Forms.ComboBox();
            this.combTypeConsommable = new System.Windows.Forms.ComboBox();
            this.lblPrix = new System.Windows.Forms.Label();
            this.lblLibelle = new System.Windows.Forms.Label();
            this.lblTypeConsommable = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtPrix = new System.Windows.Forms.TextBox();
            this.pictAnnuler = new System.Windows.Forms.PictureBox();
            this.pictSauvegarder = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictAnnuler)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictSauvegarder)).BeginInit();
            this.SuspendLayout();
            // 
            // combSousTypeConsommable
            // 
            this.combSousTypeConsommable.Enabled = false;
            this.combSousTypeConsommable.Font = new System.Drawing.Font("Lucida Console", 9F);
            this.combSousTypeConsommable.FormattingEnabled = true;
            this.combSousTypeConsommable.Location = new System.Drawing.Point(310, 329);
            this.combSousTypeConsommable.Name = "combSousTypeConsommable";
            this.combSousTypeConsommable.Size = new System.Drawing.Size(257, 20);
            this.combSousTypeConsommable.TabIndex = 45;
            this.combSousTypeConsommable.SelectionChangeCommitted += new System.EventHandler(this.combSousTypeConsommable_SelectionChangeCommitted);
            // 
            // lblSousType
            // 
            this.lblSousType.AutoSize = true;
            this.lblSousType.BackColor = System.Drawing.Color.Transparent;
            this.lblSousType.Font = new System.Drawing.Font("Lucida Console", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSousType.Location = new System.Drawing.Point(390, 310);
            this.lblSousType.Name = "lblSousType";
            this.lblSousType.Size = new System.Drawing.Size(98, 16);
            this.lblSousType.TabIndex = 44;
            this.lblSousType.Text = "Sous type";
            // 
            // combLibelle
            // 
            this.combLibelle.Enabled = false;
            this.combLibelle.Font = new System.Drawing.Font("Lucida Console", 9F);
            this.combLibelle.FormattingEnabled = true;
            this.combLibelle.Location = new System.Drawing.Point(599, 329);
            this.combLibelle.Name = "combLibelle";
            this.combLibelle.Size = new System.Drawing.Size(257, 20);
            this.combLibelle.TabIndex = 40;
            this.combLibelle.SelectionChangeCommitted += new System.EventHandler(this.combLibelle_SelectionChangeCommitted);
            // 
            // combTypeConsommable
            // 
            this.combTypeConsommable.Font = new System.Drawing.Font("Lucida Console", 9F);
            this.combTypeConsommable.FormattingEnabled = true;
            this.combTypeConsommable.Location = new System.Drawing.Point(20, 329);
            this.combTypeConsommable.Name = "combTypeConsommable";
            this.combTypeConsommable.Size = new System.Drawing.Size(257, 20);
            this.combTypeConsommable.TabIndex = 39;
            this.combTypeConsommable.SelectionChangeCommitted += new System.EventHandler(this.combTypeConsommable_SelectionChangeCommitted);
            // 
            // lblPrix
            // 
            this.lblPrix.AutoSize = true;
            this.lblPrix.BackColor = System.Drawing.Color.Transparent;
            this.lblPrix.Font = new System.Drawing.Font("Lucida Console", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPrix.Location = new System.Drawing.Point(925, 306);
            this.lblPrix.Name = "lblPrix";
            this.lblPrix.Size = new System.Drawing.Size(48, 16);
            this.lblPrix.TabIndex = 38;
            this.lblPrix.Text = "Prix";
            // 
            // lblLibelle
            // 
            this.lblLibelle.AutoSize = true;
            this.lblLibelle.BackColor = System.Drawing.Color.Transparent;
            this.lblLibelle.Font = new System.Drawing.Font("Lucida Console", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLibelle.Location = new System.Drawing.Point(689, 310);
            this.lblLibelle.Name = "lblLibelle";
            this.lblLibelle.Size = new System.Drawing.Size(78, 16);
            this.lblLibelle.TabIndex = 37;
            this.lblLibelle.Text = "Libellé";
            // 
            // lblTypeConsommable
            // 
            this.lblTypeConsommable.AutoSize = true;
            this.lblTypeConsommable.BackColor = System.Drawing.Color.Transparent;
            this.lblTypeConsommable.Font = new System.Drawing.Font("Lucida Console", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTypeConsommable.Location = new System.Drawing.Point(63, 310);
            this.lblTypeConsommable.Name = "lblTypeConsommable";
            this.lblTypeConsommable.Size = new System.Drawing.Size(168, 16);
            this.lblTypeConsommable.TabIndex = 36;
            this.lblTypeConsommable.Text = "Type consommable";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Lucida Console", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(322, 34);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(378, 16);
            this.label1.TabIndex = 46;
            this.label1.Text = "Selectionnez le consommable recherché";
            // 
            // txtPrix
            // 
            this.txtPrix.Enabled = false;
            this.txtPrix.Location = new System.Drawing.Point(888, 329);
            this.txtPrix.Name = "txtPrix";
            this.txtPrix.Size = new System.Drawing.Size(119, 20);
            this.txtPrix.TabIndex = 47;
            // 
            // pictAnnuler
            // 
            this.pictAnnuler.Image = global::fablab_saga.Properties.Resources.cancelIcon;
            this.pictAnnuler.Location = new System.Drawing.Point(719, 635);
            this.pictAnnuler.Name = "pictAnnuler";
            this.pictAnnuler.Size = new System.Drawing.Size(110, 110);
            this.pictAnnuler.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictAnnuler.TabIndex = 41;
            this.pictAnnuler.TabStop = false;
            this.pictAnnuler.Click += new System.EventHandler(this.pictAnnuler_Click);
            this.pictAnnuler.MouseEnter += new System.EventHandler(this.pictAnnuler_MouseEnter);
            this.pictAnnuler.MouseLeave += new System.EventHandler(this.pictAnnuler_MouseLeave);
            // 
            // pictSauvegarder
            // 
            this.pictSauvegarder.Image = global::fablab_saga.Properties.Resources.fleche;
            this.pictSauvegarder.Location = new System.Drawing.Point(888, 635);
            this.pictSauvegarder.Name = "pictSauvegarder";
            this.pictSauvegarder.Size = new System.Drawing.Size(110, 110);
            this.pictSauvegarder.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictSauvegarder.TabIndex = 42;
            this.pictSauvegarder.TabStop = false;
            this.pictSauvegarder.Click += new System.EventHandler(this.pictSauvegarder_Click);
            this.pictSauvegarder.MouseEnter += new System.EventHandler(this.pictSauvegarder_MouseEnter);
            this.pictSauvegarder.MouseLeave += new System.EventHandler(this.pictSauvegarder_MouseLeave);
            // 
            // UsrcRechercherConsommable
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Transparent;
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblTypeConsommable);
            this.Controls.Add(this.lblSousType);
            this.Controls.Add(this.lblLibelle);
            this.Controls.Add(this.lblPrix);
            this.Controls.Add(this.combTypeConsommable);
            this.Controls.Add(this.combSousTypeConsommable);
            this.Controls.Add(this.combLibelle);
            this.Controls.Add(this.txtPrix);
            this.Controls.Add(this.pictAnnuler);
            this.Controls.Add(this.pictSauvegarder);
            this.Name = "UsrcRechercherConsommable";
            this.Size = new System.Drawing.Size(1024, 768);
            this.Load += new System.EventHandler(this.UsrcRechercherConsommable_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictAnnuler)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictSauvegarder)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox combSousTypeConsommable;
        private System.Windows.Forms.Label lblSousType;
        private System.Windows.Forms.PictureBox pictSauvegarder;
        private System.Windows.Forms.PictureBox pictAnnuler;
        private System.Windows.Forms.ComboBox combLibelle;
        private System.Windows.Forms.ComboBox combTypeConsommable;
        private System.Windows.Forms.Label lblPrix;
        private System.Windows.Forms.Label lblLibelle;
        private System.Windows.Forms.Label lblTypeConsommable;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtPrix;
    }
}
