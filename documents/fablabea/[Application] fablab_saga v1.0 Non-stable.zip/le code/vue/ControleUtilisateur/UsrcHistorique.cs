﻿using fablab_saga.model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace fablab_saga.vue.ControleUtilisateur
{
    public partial class UsrcHistorique : UserControl
    {
        /// <summary>
        /// Instance du formulaire parent
        /// </summary>
        private FrmPrincipal frmPrincipal;
        /// <summary>
        /// L'adherent à qui appartient l'historique
        /// </summary>
        private Adherents unAdherent;
        /// <summary>
        /// L'identifiant utiliser lors de la connexion
        /// </summary>
        private string identifiant;
        /// <summary>
        /// liste des consommablePrestation d'une prestation
        /// </summary>
        private List<ConsommablePrestation> lesConsommablesPrestation = new List<ConsommablePrestation>();
        /// <summary>
        /// liste des consommables
        /// </summary>
        private BindingSource lesConsommables = new BindingSource();
        /// <summary>
        /// liste des prestations de l'adherent (prestations et rechargemnts)
        /// </summary>
        private List<object> toutesLesPrestations = new List<object>();
        /// <summary>
        /// Liste des types de prestation
        /// </summary>
        private List<TypePrestation> lesTypesPrestations = new List<TypePrestation>();
        /// <summary>
        /// l'id de la prestation selectionnée dans le DataGridView
        /// </summary>
        private int idPrestationSelectionnee = 0;
        /// <summary>
        /// Liste des différents modes de tries
        /// </summary>
        private List<string> listeCombTrie = new List<string> { "Dernière semaine", "Dernier mois", "3 derniers mois", "6 derniers mois", "Toujours"};
        /// <summary>
        /// Le constructeur
        /// </summary>
        /// <param name="frmPrincipale">l'instance du formulaire parent</param>
        /// <param name="unAdherent">l'adherent à qui appartient l'historique</param>
        /// <param name="identifiant">l'identifiant de la connexion</param>
        public UsrcHistorique(FrmPrincipal frmPrincipale, Adherents unAdherent, string identifiant )
        {
            this.frmPrincipal = frmPrincipale;
            this.unAdherent = unAdherent;
            this.identifiant = identifiant;
            InitializeComponent();
        }
        /// <summary>
        /// Au chargement du UserControl
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void UsrcHistorique_Load(object sender, EventArgs e)
        {
            combTrier.DataSource = listeCombTrie;
            lblNomIdentifiant.Text = identifiant;
            lblNomPrenomAdherent.Text = unAdherent.NomAdherent + " " + unAdherent.PrenomAdherent;
            RecupLesListesEtRemplissageDgvListesPrestation(combTrier.SelectedItem.ToString());
            
        }
        /// <summary>
        /// Permet de récuperer les listes avec le filtre sur la date
        /// </summary>
        /// <param name="modeTrie">filtre sur le date</param>
        private void RecupLesListesEtRemplissageDgvListesPrestation(string modeTrie)
        {
            string dateTrie = null;
            switch (modeTrie)
            {
                case "Dernière semaine":
                    dateTrie = ConversionDateBdd(DateTime.Now.AddDays(-7));
                    break;
                case "Dernier mois":
                    dateTrie = ConversionDateBdd(DateTime.Now.AddMonths(-1));
                    break;
                case "3 derniers mois":
                    dateTrie = ConversionDateBdd(DateTime.Now.AddMonths(-3));
                    break;
                case "6 derniers mois":
                    dateTrie = ConversionDateBdd(DateTime.Now.AddMonths(-6));
                    break;
                case "Toujours":
                    dateTrie = "2021-01-01 00:00:00";
                    break;
            }
            //Concat(<UneListe>) permet d'assembler deux listes
            toutesLesPrestations = (List<object>)frmPrincipal.GetLesRechargements(unAdherent.IdAdherent, dateTrie).Concat(
                (List<object>)frmPrincipal.GetLesPrestations(unAdherent.IdAdherent, dateTrie)).ToList();
            lesTypesPrestations = frmPrincipal.GetLesTypesPrestations();
            lesConsommables.DataSource = frmPrincipal.GetLesConsommables();
            RemplirDgvListePrestation();
        }
        /// <summary>
        /// Permet de convertir la date en version française en version anglaise avec la syntaxe exacte de la base de données
        /// </summary>
        /// <param name="datePrestation"></param>
        /// <returns></returns>
        private string ConversionDateBdd(DateTime datePrestation)
        {
            return datePrestation.Year + "-" + datePrestation.Month + "-" + datePrestation.Day + " " + datePrestation.Hour + ":" + datePrestation.Minute
                + ":" + datePrestation.Second;
        }
        /// <summary>
        /// Permet de remplir le dgvListePrestation
        /// </summary>
        private void RemplirDgvListePrestation()
        {
            dgvListePrestation.Rows.Clear();
            foreach(Object unObject in toutesLesPrestations)
            {
                if(unObject is Rechargement)
                {
                    dgvListePrestation.Rows.Add("Rechargement", ((Rechargement)unObject).DateRechargement, " - ", " - ", "+" + ((Rechargement)unObject).NbCredits);
                }
                else
                {
                    string typePrestation = null; 
                    foreach(TypePrestation unType in lesTypesPrestations)
                    {
                        if (((Prestation)unObject).IdTypePrestation.Equals(unType.IdTypePrestation))
                        {
                            typePrestation = unType.NomPrestation;
                        }
                    }
                    dgvListePrestation.Rows.Add("Prestation", ((Prestation)unObject).DatePrestation, typePrestation, 
                        ((Prestation)unObject).Libelle, "-" + ((Prestation)unObject).MontantTotalPrestation);
                }
                
            }
            dgvListePrestation.Sort(dgvListePrestation.Columns["date"], ListSortDirection.Descending);
        }
        /// <summary>
        /// Évenement lors du changement de selection dans le dgvListePrestation pour generer l'affichage du gdvDetailPrestation
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void dgvListePrestation_SelectionChanged(object sender, EventArgs e)
        {
            dgvDetailPrestation.Rows.Clear();
            foreach(object unObject in toutesLesPrestations)
            {
                if(unObject is Prestation)
                {
                    if (((Prestation)unObject).DatePrestation.Equals(dgvListePrestation.CurrentRow.Cells["date"].Value))
                    {
                        idPrestationSelectionnee = ((Prestation)unObject).IdPrestation;
                        lesConsommablesPrestation = frmPrincipal.GetLesConsommablePrestation(((Prestation)unObject).IdPrestation);
                        for (int i = 0; i < lesConsommablesPrestation.Count; i ++)
                        {
                            foreach(Consommable unConsommable in lesConsommables)
                            {
                                if (lesConsommablesPrestation[i].IdConsommable.Equals(unConsommable.IdConsommable))
                                {
                                    List<TypeConsommable> lesTypesConsommables = new List<TypeConsommable>(frmPrincipal.GetLesTypesConsommables());
                                    foreach(TypeConsommable unTypeConsommable in lesTypesConsommables)
                                    {
                                        if (unConsommable.IdTypeConsommable.Equals(unTypeConsommable.IdTypeConsommable))
                                        {
                                            dgvDetailPrestation.Rows.Add(unConsommable.LibelleConsommable, lesConsommablesPrestation[i].QuantiteConsommable,
                                                unTypeConsommable.UniteConsommable, unConsommable.PrixConsommable, lesConsommablesPrestation[i].MontantConsommable);
                                            break;
                                        }
                                        
                                    }
                                    break;
                                }
                            }
                        }
                        dgvDetailPrestation.Visible = true;
                        break;
                    }
                }
                else
                {
                    dgvDetailPrestation.Visible = false;
                }
            }   
        }
        /// <summary>
        /// Évenement du clique sur le bouton btnRetourAdherent
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnRetourAdherent_Click(object sender, EventArgs e)
        {
            frmPrincipal.CreationConsultationAdherent(frmPrincipal.RecupUnAdherent(unAdherent.IdAdherent));
        }
        /// <summary>
        /// Évenement du clique sur le bouton btnSupprimer
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnSupprimer_Click(object sender, EventArgs e)
        {
            if(dgvListePrestation.CurrentRow.Index != -1)
            {
                DialogResult dialogResult = MessageBox.Show("Vous êtes sur le point de supprimer cet événement de " + dgvListePrestation.CurrentRow.Cells["evenement"].Value +
                    " de manière définitive, êtes vous sur de vouloir continuer ?", "Attention action irréversible", MessageBoxButtons.YesNo, 
                    MessageBoxIcon.Warning);
                if (dialogResult.Equals(DialogResult.Yes))
                {
                    if (dgvListePrestation.CurrentRow.Cells["evenement"].Value.Equals("Prestation"))
                    {
                        frmPrincipal.SuppressionPrestation(idPrestationSelectionnee);
                    }
                    else
                    {
                        DateTime dateRechargement = (DateTime)dgvListePrestation.CurrentRow.Cells["date"].Value;
                        frmPrincipal.SuppressionRechargement(unAdherent.IdAdherent, ConversionDateBdd(dateRechargement));
                    }
                    dgvListePrestation.Rows.Remove(dgvListePrestation.CurrentRow);
                }
            }
        }

        private void combTrier_SelectionChangeCommitted(object sender, EventArgs e)
        {
            RecupLesListesEtRemplissageDgvListesPrestation(combTrier.SelectedItem.ToString());
        }
    }
}
