﻿
namespace fablab_saga.vue.ControleUtilisateur
{
    partial class UsrcMenu
    {
        /// <summary> 
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Code généré par le Concepteur de composants

        /// <summary> 
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas 
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.tooltpAdherent = new System.Windows.Forms.ToolTip(this.components);
            this.lblIdentifiant = new System.Windows.Forms.Label();
            this.lblNomIdentifiant = new System.Windows.Forms.Label();
            this.pictbDeconnexion = new System.Windows.Forms.PictureBox();
            this.pictbAdministrateur = new System.Windows.Forms.PictureBox();
            this.panAdherent = new System.Windows.Forms.Panel();
            this.pictbAjouterAdherent = new System.Windows.Forms.PictureBox();
            this.pictbRechercher = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictbDeconnexion)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictbAdministrateur)).BeginInit();
            this.panAdherent.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictbAjouterAdherent)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictbRechercher)).BeginInit();
            this.SuspendLayout();
            // 
            // lblIdentifiant
            // 
            this.lblIdentifiant.AutoSize = true;
            this.lblIdentifiant.BackColor = System.Drawing.Color.Transparent;
            this.lblIdentifiant.Font = new System.Drawing.Font("Lucida Console", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIdentifiant.Location = new System.Drawing.Point(21, 20);
            this.lblIdentifiant.Name = "lblIdentifiant";
            this.lblIdentifiant.Size = new System.Drawing.Size(238, 16);
            this.lblIdentifiant.TabIndex = 12;
            this.lblIdentifiant.Text = "Connecté en temps que :";
            // 
            // lblNomIdentifiant
            // 
            this.lblNomIdentifiant.AutoSize = true;
            this.lblNomIdentifiant.BackColor = System.Drawing.Color.Transparent;
            this.lblNomIdentifiant.Font = new System.Drawing.Font("Lucida Console", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNomIdentifiant.Location = new System.Drawing.Point(259, 21);
            this.lblNomIdentifiant.Name = "lblNomIdentifiant";
            this.lblNomIdentifiant.Size = new System.Drawing.Size(0, 16);
            this.lblNomIdentifiant.TabIndex = 15;
            // 
            // pictbDeconnexion
            // 
            this.pictbDeconnexion.BackColor = System.Drawing.Color.Transparent;
            this.pictbDeconnexion.Image = global::fablab_saga.Properties.Resources.deconnexion;
            this.pictbDeconnexion.Location = new System.Drawing.Point(865, 21);
            this.pictbDeconnexion.Name = "pictbDeconnexion";
            this.pictbDeconnexion.Size = new System.Drawing.Size(110, 110);
            this.pictbDeconnexion.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictbDeconnexion.TabIndex = 16;
            this.pictbDeconnexion.TabStop = false;
            this.pictbDeconnexion.Click += new System.EventHandler(this.pictbDeconnexion_Click);
            this.pictbDeconnexion.MouseEnter += new System.EventHandler(this.PictbDeconnexion_MouseEnter);
            this.pictbDeconnexion.MouseLeave += new System.EventHandler(this.PictbDeconnexion_MouseLeave);
            // 
            // pictbAdministrateur
            // 
            this.pictbAdministrateur.BackColor = System.Drawing.Color.Transparent;
            this.pictbAdministrateur.Image = global::fablab_saga.Properties.Resources.administration;
            this.pictbAdministrateur.Location = new System.Drawing.Point(865, 613);
            this.pictbAdministrateur.Name = "pictbAdministrateur";
            this.pictbAdministrateur.Size = new System.Drawing.Size(110, 131);
            this.pictbAdministrateur.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictbAdministrateur.TabIndex = 14;
            this.pictbAdministrateur.TabStop = false;
            this.pictbAdministrateur.Click += new System.EventHandler(this.pictbAdministrateur_Click);
            this.pictbAdministrateur.MouseEnter += new System.EventHandler(this.PictbAdministrateur_MouseEnter);
            this.pictbAdministrateur.MouseLeave += new System.EventHandler(this.PictbAdministrateur_MouseLeave);
            // 
            // panAdherent
            // 
            this.panAdherent.BackColor = System.Drawing.Color.Transparent;
            this.panAdherent.BackgroundImage = global::fablab_saga.Properties.Resources.iconeAdherent;
            this.panAdherent.Controls.Add(this.pictbAjouterAdherent);
            this.panAdherent.Controls.Add(this.pictbRechercher);
            this.panAdherent.Location = new System.Drawing.Point(382, 254);
            this.panAdherent.Name = "panAdherent";
            this.panAdherent.Size = new System.Drawing.Size(260, 260);
            this.panAdherent.TabIndex = 11;
            // 
            // pictbAjouterAdherent
            // 
            this.pictbAjouterAdherent.BackColor = System.Drawing.Color.Transparent;
            this.pictbAjouterAdherent.Image = global::fablab_saga.Properties.Resources.plus;
            this.pictbAjouterAdherent.Location = new System.Drawing.Point(0, 150);
            this.pictbAjouterAdherent.Name = "pictbAjouterAdherent";
            this.pictbAjouterAdherent.Size = new System.Drawing.Size(110, 110);
            this.pictbAjouterAdherent.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictbAjouterAdherent.TabIndex = 10;
            this.pictbAjouterAdherent.TabStop = false;
            this.pictbAjouterAdherent.Click += new System.EventHandler(this.pictbAjouterAdherent_Click);
            this.pictbAjouterAdherent.MouseEnter += new System.EventHandler(this.PictbAjouterAdherent_MouseEnter);
            this.pictbAjouterAdherent.MouseLeave += new System.EventHandler(this.PictbAjouterAdherent_MouseLeave);
            // 
            // pictbRechercher
            // 
            this.pictbRechercher.BackColor = System.Drawing.Color.Transparent;
            this.pictbRechercher.Image = global::fablab_saga.Properties.Resources.loupe;
            this.pictbRechercher.Location = new System.Drawing.Point(150, 150);
            this.pictbRechercher.Name = "pictbRechercher";
            this.pictbRechercher.Size = new System.Drawing.Size(110, 110);
            this.pictbRechercher.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictbRechercher.TabIndex = 9;
            this.pictbRechercher.TabStop = false;
            this.pictbRechercher.Click += new System.EventHandler(this.pictbRechercher_Click);
            this.pictbRechercher.MouseEnter += new System.EventHandler(this.PictbRechercher_MouseEnter);
            this.pictbRechercher.MouseLeave += new System.EventHandler(this.PictbRechercher_MouseLeave);
            // 
            // UsrcMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Transparent;
            this.Controls.Add(this.lblIdentifiant);
            this.Controls.Add(this.lblNomIdentifiant);
            this.Controls.Add(this.pictbDeconnexion);
            this.Controls.Add(this.panAdherent);
            this.Controls.Add(this.pictbAdministrateur);
            this.Name = "UsrcMenu";
            this.Size = new System.Drawing.Size(1024, 768);
            this.Load += new System.EventHandler(this.UsrcMenu_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictbDeconnexion)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictbAdministrateur)).EndInit();
            this.panAdherent.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictbAjouterAdherent)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictbRechercher)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }
        #endregion
        private System.Windows.Forms.PictureBox pictbRechercher;
        private System.Windows.Forms.PictureBox pictbAjouterAdherent;
        private System.Windows.Forms.Panel panAdherent;
        private System.Windows.Forms.ToolTip tooltpAdherent;
        private System.Windows.Forms.Label lblIdentifiant;
        private System.Windows.Forms.PictureBox pictbAdministrateur;
        private System.Windows.Forms.Label lblNomIdentifiant;
        private System.Windows.Forms.PictureBox pictbDeconnexion;
    }
}
