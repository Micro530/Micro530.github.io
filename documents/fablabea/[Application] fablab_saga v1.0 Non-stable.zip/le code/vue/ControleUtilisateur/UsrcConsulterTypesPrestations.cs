﻿using fablab_saga.model;
using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace fablab_saga.vue.ControleUtilisateur
{
    public partial class UsrcConsulterTypesPrestations : UserControl
    {
        /// <summary>
        /// L'instance de formulaire parent
        /// </summary>
        private FrmPrincipal frmPrincipale;
        /// <summary>
        /// L'identifiant de connexion
        /// </summary>
        private string identifiant;
        private List<TypePrestation> lesTypePrestation = new List<TypePrestation>();
        public UsrcConsulterTypesPrestations(FrmPrincipal frmPrincipal, string identifiant)
        {
            this.frmPrincipale = frmPrincipal;
            this.identifiant = identifiant;
            InitializeComponent();
        }

        private void UsrcConsulterTypesPrestations_Load(object sender, EventArgs e)
        {
            lblNomIdentifiant.Text = identifiant;
            lesTypePrestation = frmPrincipale.GetLesTypesPrestations();
            RemplirLstbTypePrestation();
            
        }
        private void RemplirLstbTypePrestation()
        {
            lstbTypePrestation.DataSource = null;
            lstbTypePrestation.DataSource = lesTypePrestation;
            lstbTypePrestation.DisplayMember = "nomPrestation";
            lstbTypePrestation.ValueMember = "nomPrestation";
        }
        private void btnAjouter_Click(object sender, EventArgs e)
        {
            string libelle;
            libelle = Interaction.InputBox("Entrez le nom du nouveau type de prestation", "Ajouter un nouveau type de prestation");
            if(libelle != null)
            {
                frmPrincipale.AjouterUnTypePrestation(libelle);
                lesTypePrestation.Add(new TypePrestation(lesTypePrestation.Count + 1, libelle));
                RemplirLstbTypePrestation();
            }
        }

        private void btnModifier_Click(object sender, EventArgs e)
        {
            if (lstbTypePrestation.SelectedIndex != -1)
            {
                string libelle;
                libelle = Interaction.InputBox("Entrez le nouveau nom du type de prestation : " + ((TypePrestation)lstbTypePrestation.SelectedItem).NomPrestation, "Modifier un type de prestation", ((TypePrestation)lstbTypePrestation.SelectedItem).NomPrestation);
                if (libelle != null && libelle != "")
                {
                    TypePrestation unTypePrestation = (TypePrestation)lstbTypePrestation.SelectedItem;
                    unTypePrestation.NomPrestation = libelle;
                    frmPrincipale.ModifierUnTypePrestation(unTypePrestation);
                    lesTypePrestation[lstbTypePrestation.SelectedIndex].NomPrestation = libelle;
                    RemplirLstbTypePrestation();
                }
            }
        }

        private void btnSupprimer_Click(object sender, EventArgs e)
        {
            if (lstbTypePrestation.SelectedIndex != -1)
            {
                DialogResult dialogResult = MessageBox.Show("Vous êtes sur le point de supprimer le type de Prestation " + ((TypePrestation)lstbTypePrestation.SelectedItem).NomPrestation + ".\nL'action est irréversible, êtes vous sûr de vouloir continuer ?", "Confirmation de suppression", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (dialogResult.Equals(DialogResult.Yes))
                {
                    if (frmPrincipale.RecupIDTableBdd("prestation", ((TypePrestation)lstbTypePrestation.SelectedItem).IdTypePrestation, "IDTYPEPRESTATION"))
                    {
                        MessageBox.Show("Impossible de supprimer le type de prestation " + ((TypePrestation)lstbTypePrestation.SelectedItem).NomPrestation + ".\n\n " +
                            "[Code erreur 3 : Instabilité de l'intégrité réfèrentiel du SGBDR]\n\nImpossible de supprimer ce type de prestation " +
                            "parcequ'il est déjà présent dans une prestation", "Une erreur est survenue", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    else
                    {
                        frmPrincipale.SupprimerUnTypePrestation((TypePrestation)lstbTypePrestation.SelectedItem);
                        lesTypePrestation.RemoveAt(lstbTypePrestation.SelectedIndex);
                        RemplirLstbTypePrestation();
                    }
                }
            }
        }

        private void btnRetourMenuAdmin_Click(object sender, EventArgs e)
        {
            frmPrincipale.RetourMenuAdmin();
        }
    }
}
