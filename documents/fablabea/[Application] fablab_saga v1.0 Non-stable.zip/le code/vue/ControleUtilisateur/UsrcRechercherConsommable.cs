﻿using fablab_saga.model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace fablab_saga.vue.ControleUtilisateur
{
    public partial class UsrcRechercherConsommable : UserControl
    {
        /// <summary>
        /// L'instance de formulaire parent
        /// </summary>
        private FrmPrincipal frmPrincipal;
        /// <summary>
        /// liste des types de consommable
        /// </summary>
        private BindingSource lesTypesConsommables = new BindingSource();
        /// <summary>
        /// une BindingSource contenant l'ensemble des sous types de consommable
        /// </summary>
        private BindingSource lesSousTypesConsommables = new BindingSource();
        /// <summary>
        /// liste contenant la selection des sous types de consommable
        /// </summary>
        private List<SousTypeConsommable> listeLesSousTypesConsommables;
        /// <summary>
        /// une BindingSource contenant l'ensemble des consommables
        /// </summary>
        private BindingSource lesConsommables = new BindingSource();
        /// <summary>
        /// une liste contenant la selection des consommables
        /// </summary>
        private List<Consommable> listeLesConsommables;
        public UsrcRechercherConsommable(FrmPrincipal frmPrincipal)
        {
            this.frmPrincipal = frmPrincipal;
            InitializeComponent();
        }

        private void UsrcRechercherConsommable_Load(object sender, EventArgs e)
        {
            RecuperationListes();
            RemplissageComboBox(combTypeConsommable, lesTypesConsommables, "LeTypeConsommable");
            combTypeConsommable.SelectedIndex = -1;
        }
        /// <summary>
        /// Récupération des listes au sein de la base de donnée, et affectation au BingdingSource correspondant
        /// </summary>
        private void RecuperationListes()
        {
            lesTypesConsommables.DataSource = frmPrincipal.GetLesTypesConsommables();
            listeLesSousTypesConsommables = frmPrincipal.GetLesSousTypesConsommables();
            listeLesConsommables = frmPrincipal.GetLesConsommables();
        }
        /// <summary>
        /// Permet de remplir un comboBox avec n'importe BingdingSource
        /// </summary>
        /// <param name="unCombo">le comboBox à remplir</param>
        /// <param name="uneBdgs">le BingdingSource ç utiliser pour le remplir</param>
        /// <param name="nomPropriete">la propriété à afficher dans le comboBox</param>
        private void RemplissageComboBox(ComboBox unCombo, BindingSource uneBdgs, string nomPropriete)
        {
            unCombo.DataSource = null;
            unCombo.DataSource = uneBdgs;
            unCombo.DisplayMember = nomPropriete;
            unCombo.ValueMember = nomPropriete;
            unCombo.SelectedIndex = -1;
        }

        private void combTypeConsommable_SelectionChangeCommitted(object sender, EventArgs e)
        {
            lesSousTypesConsommables.Clear();
            foreach(SousTypeConsommable unSousTypeConsommable in listeLesSousTypesConsommables)
            {
                if (unSousTypeConsommable.IdTypeConsommable.Equals(((TypeConsommable)combTypeConsommable.SelectedItem).IdTypeConsommable))
                {
                    lesSousTypesConsommables.Add(unSousTypeConsommable);
                }
            }
            RemplissageComboBox(combSousTypeConsommable, lesSousTypesConsommables, "Libelle");
            combSousTypeConsommable.Enabled = true;
        }

        private void combSousTypeConsommable_SelectionChangeCommitted(object sender, EventArgs e)
        {
            lesConsommables.Clear();
            foreach (Consommable unConsommable in listeLesConsommables)
            {
                if (unConsommable.IdSousTypeConsommable.Equals(((SousTypeConsommable)combSousTypeConsommable.SelectedItem).IdSousTypeConsommable))
                {
                    lesConsommables.Add(unConsommable);
                }
            }
            RemplissageComboBox(combLibelle, lesConsommables, "LibelleConsommable");
            combLibelle.Enabled = true;
        }

        private void combLibelle_SelectionChangeCommitted(object sender, EventArgs e)
        {
            txtPrix.Enabled = true;
            txtPrix.Text = ((Consommable)combLibelle.SelectedItem).PrixConsommable.ToString();
        }

        #region bouton dynamique
        /// <summary>
        /// Évenement entrer souris sur le pictureBox
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void pictSauvegarder_MouseEnter(object sender, EventArgs e)
        {
            pictSauvegarder.SizeMode = PictureBoxSizeMode.StretchImage;
        }
        /// <summary>
        /// Évenement sortie souris sur le pictureBox
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void pictSauvegarder_MouseLeave(object sender, EventArgs e)
        {
            pictSauvegarder.SizeMode = PictureBoxSizeMode.CenterImage;
        }
        /// <summary>
        /// Évenement entrer souris sur le pictureBox
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void pictAnnuler_MouseEnter(object sender, EventArgs e)
        {
            pictAnnuler.SizeMode = PictureBoxSizeMode.StretchImage;
        }
        /// <summary>
        /// Évenement sortie souris sur le pictureBox
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void pictAnnuler_MouseLeave(object sender, EventArgs e)
        {
            pictAnnuler.SizeMode = PictureBoxSizeMode.CenterImage;
        }
        #endregion

        private void pictAnnuler_Click(object sender, EventArgs e)
        {
            frmPrincipal.RetourMenuAdmin();
        }

        private void pictSauvegarder_Click(object sender, EventArgs e)
        {
            if(!combTypeConsommable.SelectedIndex.Equals(-1) && !combSousTypeConsommable.SelectedIndex.Equals(-1) && !combLibelle.SelectedIndex.Equals(-1))
            {
                frmPrincipal.CreationAjoutModificationConsommable((Consommable)combLibelle.SelectedItem);
            }
            else
            {
                MessageBox.Show("Tous les champs doivent être rempli pour continuer", "Champs vide(s)", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            
        }
    }
}
