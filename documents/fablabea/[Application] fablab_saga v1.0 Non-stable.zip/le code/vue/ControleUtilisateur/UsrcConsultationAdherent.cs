﻿using fablab_saga.model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace fablab_saga.vue.ControleUtilisateur
{
    public partial class UsrcConsultationAdherent : UserControl
    {
        /// <summary>
        /// Instance du formulaire parent
        /// </summary>
        private FrmPrincipal frmPrincipal;
        /// <summary>
        /// L'adherent qui est consulté
        /// </summary>
        private Adherents unAdherents;
        /// <summary>
        /// Permet de garder en mémoire l'ientitifiant de connexion
        /// </summary>
        private string identifiant;
        /// <summary>
        /// Le constructeur
        /// </summary>
        /// <param name="frmPrincipale">Instance du formulaire parent</param>
        /// <param name="unAdherent">l'adherent consulté</param>
        /// <param name="identifiant">identifiant de connexion</param>
        public UsrcConsultationAdherent(FrmPrincipal frmPrincipale, Adherents unAdherent, string identifiant)
        {
            InitializeComponent();
            this.identifiant = identifiant;
            this.unAdherents = unAdherent;
            this.frmPrincipal = frmPrincipale;
        }
        /// <summary>
        /// Évenement d'initialisation du UserControl au chargment 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void UsrcConsultationAdherent_Load(object sender, EventArgs e)
        {
            InitialisationChamps();
        }
        /// <summary>
        /// Initialisation des champs
        /// </summary>
        private void InitialisationChamps()
        {
            lblNomIdentifiant.Text = identifiant;
            txtNom.Text = unAdherents.NomAdherent;
            txtPrenom.Text = unAdherents.PrenomAdherent;
            txtTelephone.Text = unAdherents.TelAdherent;
            txtEmail.Text = unAdherents.EmailAdherent;
            calendrier.SetDateNaissance(unAdherents.DateNaissanceAdherent);
            lblCredits.Text = unAdherents.MontantCreditsAdherent.ToString();
        }
        #region Évenement modifier
        /// <summary>
        /// Permet de comparer les données écrites dans les champs avec celle de l'adhérent pour détecter une modification
        /// </summary>
        /// <returns>vrai ou faux (modifié ou non)</returns>
        private bool VerifModification()
        {
            if((txtNom.Text + txtPrenom.Text + txtTelephone.Text + txtEmail.Text + calendrier.GetDateNaissance().ToString()).Equals
                (unAdherents.NomAdherent + unAdherents.PrenomAdherent + unAdherents.TelAdherent + unAdherents.EmailAdherent + 
                unAdherents.DateNaissanceAdherent.ToString()))
            {
                return false;
            }
            else
            {
                return true;
            }
        }
        /// <summary>
        /// Évenement du clique sur le bouton btnModifier
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnModifier_Click(object sender, EventArgs e)
        {
            if (VerifModification())
            {
                DialogResult dialogResult = MessageBox.Show("Vous êtes sur le point de modifier les informations de cet adhérent," +
                    " êtes vous sûr de vouloir continuer ? ", "Confirmation de modification", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if(dialogResult == DialogResult.Yes)
                {
                    unAdherents.NomAdherent = txtNom.Text;
                    unAdherents.PrenomAdherent = txtPrenom.Text;
                    unAdherents.TelAdherent = txtTelephone.Text;
                    unAdherents.EmailAdherent = txtEmail.Text;
                    unAdherents.DateNaissanceAdherent = calendrier.GetDateNaissance();
                    //Envoie de l'adhérent modifié
                    frmPrincipal.ModificationAdherent(unAdherents);
                    MessageBox.Show("Modifications enregistrées avec succès !", "Modifications enregistrées", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            else
            {
                MessageBox.Show("Vous devez apporter des modifications pour continuer", "Aucunes modifications", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
        #endregion
        /// <summary>
        /// Évenement clique sur le bouton btnRetourMenu
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnRetourMenu_Click(object sender, EventArgs e)
        {
            frmPrincipal.RetourMenu();
        }
        /// <summary>
        /// Lance la procédure pour recherche un autre adherent
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnRechercherAdherent_Click(object sender, EventArgs e)
        {
            frmPrincipal.CreationRechercheAdherent();
        }
        /// <summary>
        /// Lance la procédure d'une nouvelle presation
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnNewPrestation_Click(object sender, EventArgs e)
        {
            frmPrincipal.CreationNouvellePrestation(unAdherents);
        }
        /// <summary>
        /// Lance la procédure d'une recharge de crédits
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnRechargerCredits_Click(object sender, EventArgs e)
        {
            frmPrincipal.CreationRechargerCredits(unAdherents);
        }
        /// <summary>
        /// Lance la procédure d'une consultation de l'historique
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btsConsulterHistorique_Click(object sender, EventArgs e)
        {
            frmPrincipal.CreationHistorique(unAdherents);
        }
    }
}
