﻿
namespace fablab_saga.vue.ControleUtilisateur
{
    partial class UsrcConsultationAdherent
    {
        /// <summary> 
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Code généré par le Concepteur de composants

        /// <summary> 
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas 
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblEmail = new System.Windows.Forms.Label();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.lblTelephone = new System.Windows.Forms.Label();
            this.txtTelephone = new System.Windows.Forms.TextBox();
            this.lblTextCredits = new System.Windows.Forms.Label();
            this.lblPrenom = new System.Windows.Forms.Label();
            this.lblNom = new System.Windows.Forms.Label();
            this.lblNomIdentifiant = new System.Windows.Forms.Label();
            this.lblIdentifiant = new System.Windows.Forms.Label();
            this.txtPrenom = new System.Windows.Forms.TextBox();
            this.txtNom = new System.Windows.Forms.TextBox();
            this.lblCredits = new System.Windows.Forms.Label();
            this.btnModifier = new System.Windows.Forms.Button();
            this.btnNewPrestation = new System.Windows.Forms.Button();
            this.btnRechargerCredits = new System.Windows.Forms.Button();
            this.btsConsulterHistorique = new System.Windows.Forms.Button();
            this.btnRechercherAdherent = new System.Windows.Forms.Button();
            this.btnRetourMenu = new System.Windows.Forms.Button();
            this.calendrier = new fablab_saga.vue.ControleUtilisateur.UsrcCalendrier();
            this.SuspendLayout();
            // 
            // lblEmail
            // 
            this.lblEmail.AutoSize = true;
            this.lblEmail.BackColor = System.Drawing.Color.Transparent;
            this.lblEmail.Font = new System.Drawing.Font("Lucida Console", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEmail.Location = new System.Drawing.Point(60, 317);
            this.lblEmail.Name = "lblEmail";
            this.lblEmail.Size = new System.Drawing.Size(88, 16);
            this.lblEmail.TabIndex = 44;
            this.lblEmail.Text = "E-mail :";
            // 
            // txtEmail
            // 
            this.txtEmail.Font = new System.Drawing.Font("Lucida Console", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEmail.Location = new System.Drawing.Point(241, 317);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(314, 23);
            this.txtEmail.TabIndex = 43;
            // 
            // lblTelephone
            // 
            this.lblTelephone.AutoSize = true;
            this.lblTelephone.BackColor = System.Drawing.Color.Transparent;
            this.lblTelephone.Font = new System.Drawing.Font("Lucida Console", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTelephone.Location = new System.Drawing.Point(60, 265);
            this.lblTelephone.Name = "lblTelephone";
            this.lblTelephone.Size = new System.Drawing.Size(118, 16);
            this.lblTelephone.TabIndex = 42;
            this.lblTelephone.Text = "Téléphone :";
            // 
            // txtTelephone
            // 
            this.txtTelephone.Font = new System.Drawing.Font("Lucida Console", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTelephone.Location = new System.Drawing.Point(241, 265);
            this.txtTelephone.Name = "txtTelephone";
            this.txtTelephone.Size = new System.Drawing.Size(314, 23);
            this.txtTelephone.TabIndex = 41;
            // 
            // lblTextCredits
            // 
            this.lblTextCredits.AutoSize = true;
            this.lblTextCredits.BackColor = System.Drawing.Color.Transparent;
            this.lblTextCredits.Font = new System.Drawing.Font("Lucida Console", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTextCredits.Location = new System.Drawing.Point(80, 480);
            this.lblTextCredits.Name = "lblTextCredits";
            this.lblTextCredits.Size = new System.Drawing.Size(217, 16);
            this.lblTextCredits.TabIndex = 39;
            this.lblTextCredits.Text = "Nombre de crédits :";
            // 
            // lblPrenom
            // 
            this.lblPrenom.AutoSize = true;
            this.lblPrenom.BackColor = System.Drawing.Color.Transparent;
            this.lblPrenom.Font = new System.Drawing.Font("Lucida Console", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPrenom.Location = new System.Drawing.Point(60, 213);
            this.lblPrenom.Name = "lblPrenom";
            this.lblPrenom.Size = new System.Drawing.Size(88, 16);
            this.lblPrenom.TabIndex = 38;
            this.lblPrenom.Text = "Prénom :";
            // 
            // lblNom
            // 
            this.lblNom.AutoSize = true;
            this.lblNom.BackColor = System.Drawing.Color.Transparent;
            this.lblNom.Font = new System.Drawing.Font("Lucida Console", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNom.Location = new System.Drawing.Point(60, 161);
            this.lblNom.Name = "lblNom";
            this.lblNom.Size = new System.Drawing.Size(58, 16);
            this.lblNom.TabIndex = 37;
            this.lblNom.Text = "Nom :";
            // 
            // lblNomIdentifiant
            // 
            this.lblNomIdentifiant.AutoSize = true;
            this.lblNomIdentifiant.BackColor = System.Drawing.Color.Transparent;
            this.lblNomIdentifiant.Font = new System.Drawing.Font("Lucida Console", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNomIdentifiant.Location = new System.Drawing.Point(265, 20);
            this.lblNomIdentifiant.Name = "lblNomIdentifiant";
            this.lblNomIdentifiant.Size = new System.Drawing.Size(178, 16);
            this.lblNomIdentifiant.TabIndex = 36;
            this.lblNomIdentifiant.Text = "<nom utilisateur>";
            // 
            // lblIdentifiant
            // 
            this.lblIdentifiant.AutoSize = true;
            this.lblIdentifiant.BackColor = System.Drawing.Color.Transparent;
            this.lblIdentifiant.Font = new System.Drawing.Font("Lucida Console", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIdentifiant.Location = new System.Drawing.Point(21, 20);
            this.lblIdentifiant.Name = "lblIdentifiant";
            this.lblIdentifiant.Size = new System.Drawing.Size(238, 16);
            this.lblIdentifiant.TabIndex = 35;
            this.lblIdentifiant.Text = "Connecté en temps que :";
            // 
            // txtPrenom
            // 
            this.txtPrenom.Font = new System.Drawing.Font("Lucida Console", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPrenom.Location = new System.Drawing.Point(241, 213);
            this.txtPrenom.Name = "txtPrenom";
            this.txtPrenom.Size = new System.Drawing.Size(314, 23);
            this.txtPrenom.TabIndex = 34;
            // 
            // txtNom
            // 
            this.txtNom.Font = new System.Drawing.Font("Lucida Console", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNom.Location = new System.Drawing.Point(241, 161);
            this.txtNom.Name = "txtNom";
            this.txtNom.Size = new System.Drawing.Size(314, 23);
            this.txtNom.TabIndex = 33;
            // 
            // lblCredits
            // 
            this.lblCredits.AutoSize = true;
            this.lblCredits.BackColor = System.Drawing.Color.Transparent;
            this.lblCredits.Font = new System.Drawing.Font("Lucida Console", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCredits.Location = new System.Drawing.Point(303, 480);
            this.lblCredits.Name = "lblCredits";
            this.lblCredits.Size = new System.Drawing.Size(128, 16);
            this.lblCredits.TabIndex = 46;
            this.lblCredits.Text = "<nom crédit>";
            // 
            // btnModifier
            // 
            this.btnModifier.Font = new System.Drawing.Font("Lucida Console", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnModifier.Location = new System.Drawing.Point(24, 609);
            this.btnModifier.Name = "btnModifier";
            this.btnModifier.Size = new System.Drawing.Size(297, 51);
            this.btnModifier.TabIndex = 47;
            this.btnModifier.Text = "Appliquer les Modifications";
            this.btnModifier.UseVisualStyleBackColor = true;
            this.btnModifier.Click += new System.EventHandler(this.btnModifier_Click);
            // 
            // btnNewPrestation
            // 
            this.btnNewPrestation.Font = new System.Drawing.Font("Lucida Console", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNewPrestation.Location = new System.Drawing.Point(373, 609);
            this.btnNewPrestation.Name = "btnNewPrestation";
            this.btnNewPrestation.Size = new System.Drawing.Size(212, 51);
            this.btnNewPrestation.TabIndex = 48;
            this.btnNewPrestation.Text = "Nouvelle Prestation";
            this.btnNewPrestation.UseVisualStyleBackColor = true;
            this.btnNewPrestation.Click += new System.EventHandler(this.btnNewPrestation_Click);
            // 
            // btnRechargerCredits
            // 
            this.btnRechargerCredits.Font = new System.Drawing.Font("Lucida Console", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRechargerCredits.Location = new System.Drawing.Point(664, 463);
            this.btnRechargerCredits.Name = "btnRechargerCredits";
            this.btnRechargerCredits.Size = new System.Drawing.Size(303, 51);
            this.btnRechargerCredits.TabIndex = 49;
            this.btnRechargerCredits.Text = "Recharger des crédits";
            this.btnRechargerCredits.UseVisualStyleBackColor = true;
            this.btnRechargerCredits.Click += new System.EventHandler(this.btnRechargerCredits_Click);
            // 
            // btsConsulterHistorique
            // 
            this.btsConsulterHistorique.Font = new System.Drawing.Font("Lucida Console", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btsConsulterHistorique.Location = new System.Drawing.Point(664, 536);
            this.btsConsulterHistorique.Name = "btsConsulterHistorique";
            this.btsConsulterHistorique.Size = new System.Drawing.Size(303, 51);
            this.btsConsulterHistorique.TabIndex = 50;
            this.btsConsulterHistorique.Text = "Consulter l\'historique";
            this.btsConsulterHistorique.UseVisualStyleBackColor = true;
            this.btsConsulterHistorique.Click += new System.EventHandler(this.btsConsulterHistorique_Click);
            // 
            // btnRechercherAdherent
            // 
            this.btnRechercherAdherent.Font = new System.Drawing.Font("Lucida Console", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRechercherAdherent.Location = new System.Drawing.Point(664, 609);
            this.btnRechercherAdherent.Name = "btnRechercherAdherent";
            this.btnRechercherAdherent.Size = new System.Drawing.Size(303, 51);
            this.btnRechercherAdherent.TabIndex = 51;
            this.btnRechercherAdherent.Text = "Rechercher un adhérent";
            this.btnRechercherAdherent.UseVisualStyleBackColor = true;
            this.btnRechercherAdherent.Click += new System.EventHandler(this.btnRechercherAdherent_Click);
            // 
            // btnRetourMenu
            // 
            this.btnRetourMenu.Font = new System.Drawing.Font("Lucida Console", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRetourMenu.Location = new System.Drawing.Point(759, 20);
            this.btnRetourMenu.Name = "btnRetourMenu";
            this.btnRetourMenu.Size = new System.Drawing.Size(241, 37);
            this.btnRetourMenu.TabIndex = 52;
            this.btnRetourMenu.Text = "Revenir au menu";
            this.btnRetourMenu.UseVisualStyleBackColor = true;
            this.btnRetourMenu.Click += new System.EventHandler(this.btnRetourMenu_Click);
            // 
            // calendrier
            // 
            this.calendrier.BackColor = System.Drawing.Color.Transparent;
            this.calendrier.Location = new System.Drawing.Point(627, 161);
            this.calendrier.Name = "calendrier";
            this.calendrier.Size = new System.Drawing.Size(340, 150);
            this.calendrier.TabIndex = 53;
            // 
            // UsrcConsultationAdherent
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Transparent;
            this.Controls.Add(this.lblIdentifiant);
            this.Controls.Add(this.lblNomIdentifiant);
            this.Controls.Add(this.btnRetourMenu);
            this.Controls.Add(this.lblNom);
            this.Controls.Add(this.txtNom);
            this.Controls.Add(this.lblPrenom);
            this.Controls.Add(this.txtPrenom);
            this.Controls.Add(this.calendrier);
            this.Controls.Add(this.lblTelephone);
            this.Controls.Add(this.txtTelephone);
            this.Controls.Add(this.lblEmail);
            this.Controls.Add(this.txtEmail);
            this.Controls.Add(this.lblTextCredits);
            this.Controls.Add(this.lblCredits);
            this.Controls.Add(this.btnRechargerCredits);
            this.Controls.Add(this.btsConsulterHistorique);
            this.Controls.Add(this.btnModifier);
            this.Controls.Add(this.btnNewPrestation);
            this.Controls.Add(this.btnRechercherAdherent);
            this.Name = "UsrcConsultationAdherent";
            this.Size = new System.Drawing.Size(1024, 768);
            this.Load += new System.EventHandler(this.UsrcConsultationAdherent_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label lblEmail;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.Label lblTelephone;
        private System.Windows.Forms.TextBox txtTelephone;
        private System.Windows.Forms.Label lblTextCredits;
        private System.Windows.Forms.Label lblPrenom;
        private System.Windows.Forms.Label lblNom;
        private System.Windows.Forms.Label lblNomIdentifiant;
        private System.Windows.Forms.Label lblIdentifiant;
        private System.Windows.Forms.TextBox txtPrenom;
        private System.Windows.Forms.TextBox txtNom;
        private System.Windows.Forms.Label lblCredits;
        private System.Windows.Forms.Button btnModifier;
        private System.Windows.Forms.Button btnNewPrestation;
        private System.Windows.Forms.Button btnRechargerCredits;
        private System.Windows.Forms.Button btsConsulterHistorique;
        private System.Windows.Forms.Button btnRechercherAdherent;
        private System.Windows.Forms.Button btnRetourMenu;
        private UsrcCalendrier calendrier;
    }
}
