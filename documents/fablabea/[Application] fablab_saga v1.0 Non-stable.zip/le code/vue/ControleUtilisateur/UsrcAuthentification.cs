﻿using fablab_saga.controleur;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace fablab_saga.vue.ControleUtilisateur
{
    public partial class UsrcAuthentification : UserControl
    {
        /// <summary>
        /// Instance du formulaire parent
        /// </summary>
        private FrmPrincipal frmPrincipal;
        /// <summary>
        /// le contructeur qui à besoin de l'instance de controle pour intancient la variable locale
        /// </summary>
        /// <param name="controle">possède l'instance du controleur ayant créé le formulaire</param>
        public UsrcAuthentification(FrmPrincipal frmPrincipale)
        {
            this.frmPrincipal = frmPrincipale;
            InitializeComponent();
        }
        /// <summary>
        /// évenement du clique sur le bouton de connexion, le txtIdentifiant envoi l'identifiant et txtPwd envoi le mot de passe
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnConnexion_Click(object sender, EventArgs e)
        {
            frmPrincipal.Authentification(txtIdentifiant.Text, txtPwd.Text);
        }
        /// <summary>
        /// Initialisation diverse du UserControl 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void UsrcAuthentification_Load(object sender, EventArgs e)
        {
            lblIdentifiant.BackColor = Color.Transparent;
            lblPwd.BackColor = Color.Transparent;
            txtIdentifiant.Text = "AdminQuentinS";
            txtPwd.Text = "azerty123";
        }
    }
}
