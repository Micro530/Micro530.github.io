﻿using fablab_saga.controleur;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace fablab_saga.vue.ControleUtilisateur
{
    public partial class UsrcMenu : UserControl
    {
        /// <summary>
        /// Instance du formulaire parent
        /// </summary>
        private FrmPrincipal frmPrincipal;
        /// <summary>
        /// Itentifiant utilisé lors de la connexion 
        /// </summary>
        private string identifiant;
        /// <summary>
        /// Constructeur du UserControl UsrcMenu
        /// </summary>
        /// <param name="frmPrincipale">Permet d'avoir l'instance de du formulaire qui l'a initialisé</param>
        /// <param name="identifiant">Permet d'avoir l'identifiant de l'utilisateur connecté</param>
        public UsrcMenu(FrmPrincipal frmPrincipale, string identifiant)
        {
            this.identifiant = identifiant;
            this.frmPrincipal = frmPrincipale;
            InitializeComponent();
        }
        /// <summary>
        /// Instructions diverses au chargement du UserControl
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void UsrcMenu_Load(object sender, EventArgs e)
        {
            tooltpAdherent.SetToolTip(panAdherent, "Ajouter ou rechercher un adhérent");
            tooltpAdherent.SetToolTip(pictbAjouterAdherent, "Ajouter un adhérent");
            tooltpAdherent.SetToolTip(pictbAdministrateur, "Accéder aux fonctionnalités avancées");
            tooltpAdherent.SetToolTip(pictbDeconnexion, "Se déconnecter");
            tooltpAdherent.SetToolTip(pictbRechercher, "Rechercher un adhérent");
            lblNomIdentifiant.Text = identifiant;
        }
        #region Bouton dynamique
        /// <summary>
        /// Évenement lors de l'entrer de la souris sur le PictbAjouterAdherent
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void PictbAjouterAdherent_MouseEnter(object sender, EventArgs e)
        {
            pictbAjouterAdherent.SizeMode = PictureBoxSizeMode.StretchImage;
        }
        /// <summary>
        /// Évenement lors de la sortie de la souris sur le PictbAjouterAdherent
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void PictbAjouterAdherent_MouseLeave(object sender, EventArgs e)
        {
            pictbAjouterAdherent.SizeMode = PictureBoxSizeMode.CenterImage;
        }
        /// <summary>
        /// Évenement lors de l'entrer de la souris sur le PictbRechercher
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void PictbRechercher_MouseEnter(object sender, EventArgs e)
        {
            pictbRechercher.SizeMode = PictureBoxSizeMode.StretchImage;
        }
        /// <summary>
        /// Évenement lors de la sortie de la souris sur le PictbRechercher
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void PictbRechercher_MouseLeave(object sender, EventArgs e)
        {
            pictbRechercher.SizeMode = PictureBoxSizeMode.CenterImage;
        }
        /// <summary>
        /// Évenement lors de l'entrer de la souris sur le PictbAdministrateur
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void PictbAdministrateur_MouseEnter(object sender, EventArgs e)
        {
            pictbAdministrateur.SizeMode = PictureBoxSizeMode.StretchImage;
        }
        /// <summary>
        /// Évenement lors de la sortie de la souris sur le PictbAdministrateur
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void PictbAdministrateur_MouseLeave(object sender, EventArgs e)
        {
            pictbAdministrateur.SizeMode = PictureBoxSizeMode.CenterImage;
        }
        /// <summary>
        /// Évenement lors de l'entrer de la souris sur le pictbDeconnexion
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void PictbDeconnexion_MouseEnter(object sender, EventArgs e)
        {
            pictbDeconnexion.SizeMode = PictureBoxSizeMode.StretchImage;
        }
        /// <summary>
        /// Évenement lors de la sortie de la souris sur le PictbDeconnexion
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void PictbDeconnexion_MouseLeave(object sender, EventArgs e)
        {
            pictbDeconnexion.SizeMode = PictureBoxSizeMode.CenterImage;
        }
        #endregion
        /// <summary>
        /// Évenement de déconnexion
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void pictbDeconnexion_Click(object sender, EventArgs e)
        {
            frmPrincipal.Deconnexion();
        }

        private void pictbAjouterAdherent_Click(object sender, EventArgs e)
        {
            frmPrincipal.CreationAjoutAdherent();
        }

        private void pictbRechercher_Click(object sender, EventArgs e)
        {
            frmPrincipal.CreationRechercheAdherent();
        }

        private void pictbAdministrateur_Click(object sender, EventArgs e)
        {
            if (identifiant.Substring(0, 5).Equals("Admin"))
            {
                frmPrincipal.CreationMenuAdministrateur();
            }
            else
            {
                MessageBox.Show("Vous de disposez pas des droits requis pour accèder à cette zone, connectez vous avec un profil administrateur pour continuer", "Privilèges insuffisants", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            
        }
    }
}
