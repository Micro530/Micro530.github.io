﻿
namespace fablab_saga.vue.ControleUtilisateur
{
    partial class UsrcNouvellePrestation
    {
        /// <summary> 
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Code généré par le Concepteur de composants

        /// <summary> 
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas 
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent()
        {
            this.grbAjouterLigne = new System.Windows.Forms.GroupBox();
            this.grbChoisirTypeConsommable = new System.Windows.Forms.GroupBox();
            this.lblTypeConsommable = new System.Windows.Forms.Label();
            this.combTypeConsommable = new System.Windows.Forms.ComboBox();
            this.lblSousTypeConsommable = new System.Windows.Forms.Label();
            this.combSousTypeConsommable = new System.Windows.Forms.ComboBox();
            this.grbChoisirConsommable = new System.Windows.Forms.GroupBox();
            this.lblConsommable = new System.Windows.Forms.Label();
            this.combConsommable = new System.Windows.Forms.ComboBox();
            this.lblQuantite = new System.Windows.Forms.Label();
            this.txtQuantite = new System.Windows.Forms.TextBox();
            this.lblUnite = new System.Windows.Forms.Label();
            this.lblErreurInt = new System.Windows.Forms.Label();
            this.lblLibelle = new System.Windows.Forms.Label();
            this.txtLibelle = new System.Windows.Forms.TextBox();
            this.lblCoutCredits = new System.Windows.Forms.Label();
            this.lblSommeCoutCredits = new System.Windows.Forms.Label();
            this.pictAjouterLigne = new System.Windows.Forms.PictureBox();
            this.combTypePrestation = new System.Windows.Forms.ComboBox();
            this.dgvDetailPrestation = new System.Windows.Forms.DataGridView();
            this.Consommables = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Libelles = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Quantites = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Montants = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lblIdentifiant = new System.Windows.Forms.Label();
            this.lblNomPrenomAdherent = new System.Windows.Forms.Label();
            this.lblAdherent = new System.Windows.Forms.Label();
            this.lblNomIdentifiant = new System.Windows.Forms.Label();
            this.lblTypePrestation = new System.Windows.Forms.Label();
            this.lblCoutTotalCredits = new System.Windows.Forms.Label();
            this.lblSommeTotalCredits = new System.Windows.Forms.Label();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.pictSauvegarder = new System.Windows.Forms.PictureBox();
            this.pictAnnuler = new System.Windows.Forms.PictureBox();
            this.grbAjouterLigne.SuspendLayout();
            this.grbChoisirTypeConsommable.SuspendLayout();
            this.grbChoisirConsommable.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictAjouterLigne)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDetailPrestation)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictSauvegarder)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictAnnuler)).BeginInit();
            this.SuspendLayout();
            // 
            // grbAjouterLigne
            // 
            this.grbAjouterLigne.Controls.Add(this.grbChoisirTypeConsommable);
            this.grbAjouterLigne.Controls.Add(this.grbChoisirConsommable);
            this.grbAjouterLigne.Enabled = false;
            this.grbAjouterLigne.Font = new System.Drawing.Font("Lucida Console", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grbAjouterLigne.Location = new System.Drawing.Point(17, 89);
            this.grbAjouterLigne.Name = "grbAjouterLigne";
            this.grbAjouterLigne.Size = new System.Drawing.Size(975, 386);
            this.grbAjouterLigne.TabIndex = 0;
            this.grbAjouterLigne.TabStop = false;
            this.grbAjouterLigne.Text = "Ajouter une ligne";
            // 
            // grbChoisirTypeConsommable
            // 
            this.grbChoisirTypeConsommable.Controls.Add(this.lblTypeConsommable);
            this.grbChoisirTypeConsommable.Controls.Add(this.combTypeConsommable);
            this.grbChoisirTypeConsommable.Controls.Add(this.lblSousTypeConsommable);
            this.grbChoisirTypeConsommable.Controls.Add(this.combSousTypeConsommable);
            this.grbChoisirTypeConsommable.Font = new System.Drawing.Font("Lucida Console", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grbChoisirTypeConsommable.Location = new System.Drawing.Point(13, 33);
            this.grbChoisirTypeConsommable.Name = "grbChoisirTypeConsommable";
            this.grbChoisirTypeConsommable.Size = new System.Drawing.Size(941, 82);
            this.grbChoisirTypeConsommable.TabIndex = 1;
            this.grbChoisirTypeConsommable.TabStop = false;
            this.grbChoisirTypeConsommable.Text = "Choisir un type de consommable";
            // 
            // lblTypeConsommable
            // 
            this.lblTypeConsommable.AutoSize = true;
            this.lblTypeConsommable.BackColor = System.Drawing.Color.Transparent;
            this.lblTypeConsommable.Font = new System.Drawing.Font("Lucida Console", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTypeConsommable.Location = new System.Drawing.Point(3, 38);
            this.lblTypeConsommable.Name = "lblTypeConsommable";
            this.lblTypeConsommable.Size = new System.Drawing.Size(188, 16);
            this.lblTypeConsommable.TabIndex = 59;
            this.lblTypeConsommable.Text = "Type consommable :";
            // 
            // combTypeConsommable
            // 
            this.combTypeConsommable.Font = new System.Drawing.Font("Lucida Console", 9F);
            this.combTypeConsommable.FormattingEnabled = true;
            this.combTypeConsommable.Location = new System.Drawing.Point(197, 35);
            this.combTypeConsommable.Name = "combTypeConsommable";
            this.combTypeConsommable.Size = new System.Drawing.Size(241, 20);
            this.combTypeConsommable.TabIndex = 31;
            this.combTypeConsommable.SelectionChangeCommitted += new System.EventHandler(this.combTypeConsommable_SelectionChange);
            // 
            // lblSousTypeConsommable
            // 
            this.lblSousTypeConsommable.AutoSize = true;
            this.lblSousTypeConsommable.BackColor = System.Drawing.Color.Transparent;
            this.lblSousTypeConsommable.Font = new System.Drawing.Font("Lucida Console", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSousTypeConsommable.Location = new System.Drawing.Point(463, 38);
            this.lblSousTypeConsommable.Name = "lblSousTypeConsommable";
            this.lblSousTypeConsommable.Size = new System.Drawing.Size(238, 16);
            this.lblSousTypeConsommable.TabIndex = 58;
            this.lblSousTypeConsommable.Text = "Sous type consommable :";
            // 
            // combSousTypeConsommable
            // 
            this.combSousTypeConsommable.Enabled = false;
            this.combSousTypeConsommable.Font = new System.Drawing.Font("Lucida Console", 9F);
            this.combSousTypeConsommable.FormattingEnabled = true;
            this.combSousTypeConsommable.Location = new System.Drawing.Point(707, 35);
            this.combSousTypeConsommable.Name = "combSousTypeConsommable";
            this.combSousTypeConsommable.Size = new System.Drawing.Size(228, 20);
            this.combSousTypeConsommable.TabIndex = 32;
            this.combSousTypeConsommable.SelectionChangeCommitted += new System.EventHandler(this.combSousTypeConsommable_SelectionChange);
            // 
            // grbChoisirConsommable
            // 
            this.grbChoisirConsommable.Controls.Add(this.lblConsommable);
            this.grbChoisirConsommable.Controls.Add(this.combConsommable);
            this.grbChoisirConsommable.Controls.Add(this.lblQuantite);
            this.grbChoisirConsommable.Controls.Add(this.txtQuantite);
            this.grbChoisirConsommable.Controls.Add(this.lblUnite);
            this.grbChoisirConsommable.Controls.Add(this.lblErreurInt);
            this.grbChoisirConsommable.Controls.Add(this.lblLibelle);
            this.grbChoisirConsommable.Controls.Add(this.txtLibelle);
            this.grbChoisirConsommable.Controls.Add(this.lblCoutCredits);
            this.grbChoisirConsommable.Controls.Add(this.lblSommeCoutCredits);
            this.grbChoisirConsommable.Controls.Add(this.pictAjouterLigne);
            this.grbChoisirConsommable.Enabled = false;
            this.grbChoisirConsommable.Location = new System.Drawing.Point(13, 141);
            this.grbChoisirConsommable.Name = "grbChoisirConsommable";
            this.grbChoisirConsommable.Size = new System.Drawing.Size(941, 239);
            this.grbChoisirConsommable.TabIndex = 74;
            this.grbChoisirConsommable.TabStop = false;
            this.grbChoisirConsommable.Text = "Choisir consommable";
            // 
            // lblConsommable
            // 
            this.lblConsommable.AutoSize = true;
            this.lblConsommable.BackColor = System.Drawing.Color.Transparent;
            this.lblConsommable.Font = new System.Drawing.Font("Lucida Console", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblConsommable.Location = new System.Drawing.Point(39, 39);
            this.lblConsommable.Name = "lblConsommable";
            this.lblConsommable.Size = new System.Drawing.Size(138, 16);
            this.lblConsommable.TabIndex = 62;
            this.lblConsommable.Text = "Consommable :";
            // 
            // combConsommable
            // 
            this.combConsommable.Font = new System.Drawing.Font("Lucida Console", 9F);
            this.combConsommable.FormattingEnabled = true;
            this.combConsommable.Location = new System.Drawing.Point(197, 35);
            this.combConsommable.Name = "combConsommable";
            this.combConsommable.Size = new System.Drawing.Size(241, 20);
            this.combConsommable.TabIndex = 33;
            // 
            // lblQuantite
            // 
            this.lblQuantite.AutoSize = true;
            this.lblQuantite.BackColor = System.Drawing.Color.Transparent;
            this.lblQuantite.Font = new System.Drawing.Font("Lucida Console", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQuantite.Location = new System.Drawing.Point(593, 39);
            this.lblQuantite.Name = "lblQuantite";
            this.lblQuantite.Size = new System.Drawing.Size(108, 16);
            this.lblQuantite.TabIndex = 63;
            this.lblQuantite.Text = "Quantité :";
            // 
            // txtQuantite
            // 
            this.txtQuantite.Font = new System.Drawing.Font("Lucida Console", 10F);
            this.txtQuantite.Location = new System.Drawing.Point(707, 37);
            this.txtQuantite.Name = "txtQuantite";
            this.txtQuantite.Size = new System.Drawing.Size(130, 21);
            this.txtQuantite.TabIndex = 34;
            this.txtQuantite.Text = "0";
            this.txtQuantite.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtQuantite_KeyUp);
            // 
            // lblUnite
            // 
            this.lblUnite.AutoSize = true;
            this.lblUnite.BackColor = System.Drawing.Color.Transparent;
            this.lblUnite.Font = new System.Drawing.Font("Lucida Console", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUnite.Location = new System.Drawing.Point(850, 39);
            this.lblUnite.Name = "lblUnite";
            this.lblUnite.Size = new System.Drawing.Size(85, 16);
            this.lblUnite.TabIndex = 64;
            this.lblUnite.Text = "Grammes";
            // 
            // lblErreurInt
            // 
            this.lblErreurInt.AutoSize = true;
            this.lblErreurInt.BackColor = System.Drawing.Color.Transparent;
            this.lblErreurInt.Font = new System.Drawing.Font("Lucida Console", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblErreurInt.ForeColor = System.Drawing.Color.Red;
            this.lblErreurInt.Location = new System.Drawing.Point(569, 67);
            this.lblErreurInt.Name = "lblErreurInt";
            this.lblErreurInt.Size = new System.Drawing.Size(0, 16);
            this.lblErreurInt.TabIndex = 74;
            // 
            // lblLibelle
            // 
            this.lblLibelle.AutoSize = true;
            this.lblLibelle.BackColor = System.Drawing.Color.Transparent;
            this.lblLibelle.Font = new System.Drawing.Font("Lucida Console", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLibelle.Location = new System.Drawing.Point(79, 167);
            this.lblLibelle.Name = "lblLibelle";
            this.lblLibelle.Size = new System.Drawing.Size(98, 16);
            this.lblLibelle.TabIndex = 61;
            this.lblLibelle.Text = "Libellé :";
            // 
            // txtLibelle
            // 
            this.txtLibelle.Font = new System.Drawing.Font("Lucida Console", 10F);
            this.txtLibelle.Location = new System.Drawing.Point(197, 162);
            this.txtLibelle.Name = "txtLibelle";
            this.txtLibelle.Size = new System.Drawing.Size(241, 21);
            this.txtLibelle.TabIndex = 67;
            // 
            // lblCoutCredits
            // 
            this.lblCoutCredits.AutoSize = true;
            this.lblCoutCredits.BackColor = System.Drawing.Color.Transparent;
            this.lblCoutCredits.Font = new System.Drawing.Font("Lucida Console", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCoutCredits.Location = new System.Drawing.Point(523, 162);
            this.lblCoutCredits.Name = "lblCoutCredits";
            this.lblCoutCredits.Size = new System.Drawing.Size(178, 16);
            this.lblCoutCredits.TabIndex = 65;
            this.lblCoutCredits.Text = "Coût en crédits :";
            // 
            // lblSommeCoutCredits
            // 
            this.lblSommeCoutCredits.AutoSize = true;
            this.lblSommeCoutCredits.BackColor = System.Drawing.Color.Transparent;
            this.lblSommeCoutCredits.Font = new System.Drawing.Font("Lucida Console", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSommeCoutCredits.Location = new System.Drawing.Point(707, 162);
            this.lblSommeCoutCredits.Name = "lblSommeCoutCredits";
            this.lblSommeCoutCredits.Size = new System.Drawing.Size(18, 16);
            this.lblSommeCoutCredits.TabIndex = 66;
            this.lblSommeCoutCredits.Text = "0";
            // 
            // pictAjouterLigne
            // 
            this.pictAjouterLigne.Image = global::fablab_saga.Properties.Resources.plus;
            this.pictAjouterLigne.Location = new System.Drawing.Point(825, 123);
            this.pictAjouterLigne.Name = "pictAjouterLigne";
            this.pictAjouterLigne.Size = new System.Drawing.Size(110, 110);
            this.pictAjouterLigne.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictAjouterLigne.TabIndex = 73;
            this.pictAjouterLigne.TabStop = false;
            this.pictAjouterLigne.Click += new System.EventHandler(this.pictAjouterLigne_Click);
            this.pictAjouterLigne.MouseEnter += new System.EventHandler(this.pictAjouterLigne_MouseEnter);
            this.pictAjouterLigne.MouseLeave += new System.EventHandler(this.pictAjouterLigne_MouseLeave);
            // 
            // combTypePrestation
            // 
            this.combTypePrestation.Font = new System.Drawing.Font("Lucida Console", 9F);
            this.combTypePrestation.FormattingEnabled = true;
            this.combTypePrestation.Location = new System.Drawing.Point(495, 58);
            this.combTypePrestation.Name = "combTypePrestation";
            this.combTypePrestation.Size = new System.Drawing.Size(236, 20);
            this.combTypePrestation.TabIndex = 30;
            this.combTypePrestation.SelectionChangeCommitted += new System.EventHandler(this.combTypePrestation_SelectionChange);
            // 
            // dgvDetailPrestation
            // 
            this.dgvDetailPrestation.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvDetailPrestation.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDetailPrestation.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Consommables,
            this.Libelles,
            this.Quantites,
            this.Montants});
            this.dgvDetailPrestation.Location = new System.Drawing.Point(17, 481);
            this.dgvDetailPrestation.Name = "dgvDetailPrestation";
            this.dgvDetailPrestation.Size = new System.Drawing.Size(975, 165);
            this.dgvDetailPrestation.TabIndex = 68;
            this.dgvDetailPrestation.RowsAdded += new System.Windows.Forms.DataGridViewRowsAddedEventHandler(this.dgvDetailPrestation_RowsAdded);
            this.dgvDetailPrestation.RowsRemoved += new System.Windows.Forms.DataGridViewRowsRemovedEventHandler(this.dgvDetailPrestation_RowsRemoved);
            this.dgvDetailPrestation.SelectionChanged += new System.EventHandler(this.dgvDetailPrestation_SelectionChanged);
            // 
            // Consommables
            // 
            this.Consommables.HeaderText = "Consommable";
            this.Consommables.Name = "Consommables";
            // 
            // Libelles
            // 
            this.Libelles.HeaderText = "Libellé";
            this.Libelles.Name = "Libelles";
            // 
            // Quantites
            // 
            this.Quantites.HeaderText = "Quantité";
            this.Quantites.Name = "Quantites";
            // 
            // Montants
            // 
            this.Montants.HeaderText = "Montant";
            this.Montants.Name = "Montants";
            // 
            // lblIdentifiant
            // 
            this.lblIdentifiant.AutoSize = true;
            this.lblIdentifiant.BackColor = System.Drawing.Color.Transparent;
            this.lblIdentifiant.Font = new System.Drawing.Font("Lucida Console", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIdentifiant.Location = new System.Drawing.Point(21, 20);
            this.lblIdentifiant.Name = "lblIdentifiant";
            this.lblIdentifiant.Size = new System.Drawing.Size(238, 16);
            this.lblIdentifiant.TabIndex = 37;
            this.lblIdentifiant.Text = "Connecté en temps que :";
            // 
            // lblNomPrenomAdherent
            // 
            this.lblNomPrenomAdherent.AutoSize = true;
            this.lblNomPrenomAdherent.BackColor = System.Drawing.Color.Transparent;
            this.lblNomPrenomAdherent.Font = new System.Drawing.Font("Lucida Console", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNomPrenomAdherent.Location = new System.Drawing.Point(743, 20);
            this.lblNomPrenomAdherent.Name = "lblNomPrenomAdherent";
            this.lblNomPrenomAdherent.Size = new System.Drawing.Size(178, 16);
            this.lblNomPrenomAdherent.TabIndex = 57;
            this.lblNomPrenomAdherent.Text = "<nom utilisateur>";
            // 
            // lblAdherent
            // 
            this.lblAdherent.AutoSize = true;
            this.lblAdherent.BackColor = System.Drawing.Color.Transparent;
            this.lblAdherent.Font = new System.Drawing.Font("Lucida Console", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAdherent.Location = new System.Drawing.Point(629, 20);
            this.lblAdherent.Name = "lblAdherent";
            this.lblAdherent.Size = new System.Drawing.Size(108, 16);
            this.lblAdherent.TabIndex = 56;
            this.lblAdherent.Text = "Adhérent :";
            // 
            // lblNomIdentifiant
            // 
            this.lblNomIdentifiant.AutoSize = true;
            this.lblNomIdentifiant.BackColor = System.Drawing.Color.Transparent;
            this.lblNomIdentifiant.Font = new System.Drawing.Font("Lucida Console", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNomIdentifiant.Location = new System.Drawing.Point(265, 20);
            this.lblNomIdentifiant.Name = "lblNomIdentifiant";
            this.lblNomIdentifiant.Size = new System.Drawing.Size(178, 16);
            this.lblNomIdentifiant.TabIndex = 55;
            this.lblNomIdentifiant.Text = "<nom utilisateur>";
            // 
            // lblTypePrestation
            // 
            this.lblTypePrestation.AutoSize = true;
            this.lblTypePrestation.BackColor = System.Drawing.Color.Transparent;
            this.lblTypePrestation.Font = new System.Drawing.Font("Lucida Console", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTypePrestation.Location = new System.Drawing.Point(311, 59);
            this.lblTypePrestation.Name = "lblTypePrestation";
            this.lblTypePrestation.Size = new System.Drawing.Size(178, 16);
            this.lblTypePrestation.TabIndex = 60;
            this.lblTypePrestation.Text = "Type prestation :";
            // 
            // lblCoutTotalCredits
            // 
            this.lblCoutTotalCredits.AutoSize = true;
            this.lblCoutTotalCredits.BackColor = System.Drawing.Color.Transparent;
            this.lblCoutTotalCredits.Font = new System.Drawing.Font("Lucida Console", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCoutTotalCredits.Location = new System.Drawing.Point(27, 721);
            this.lblCoutTotalCredits.Name = "lblCoutTotalCredits";
            this.lblCoutTotalCredits.Size = new System.Drawing.Size(238, 16);
            this.lblCoutTotalCredits.TabIndex = 69;
            this.lblCoutTotalCredits.Text = "Coût total en crédits :";
            // 
            // lblSommeTotalCredits
            // 
            this.lblSommeTotalCredits.AutoSize = true;
            this.lblSommeTotalCredits.BackColor = System.Drawing.Color.Transparent;
            this.lblSommeTotalCredits.Font = new System.Drawing.Font("Lucida Console", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSommeTotalCredits.Location = new System.Drawing.Point(271, 721);
            this.lblSommeTotalCredits.Name = "lblSommeTotalCredits";
            this.lblSommeTotalCredits.Size = new System.Drawing.Size(18, 16);
            this.lblSommeTotalCredits.TabIndex = 70;
            this.lblSommeTotalCredits.Text = "0";
            // 
            // pictSauvegarder
            // 
            this.pictSauvegarder.Image = global::fablab_saga.Properties.Resources.save;
            this.pictSauvegarder.Location = new System.Drawing.Point(882, 652);
            this.pictSauvegarder.Name = "pictSauvegarder";
            this.pictSauvegarder.Size = new System.Drawing.Size(110, 110);
            this.pictSauvegarder.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictSauvegarder.TabIndex = 75;
            this.pictSauvegarder.TabStop = false;
            this.pictSauvegarder.Click += new System.EventHandler(this.pictSauvegarder_Click);
            this.pictSauvegarder.MouseEnter += new System.EventHandler(this.pictSauvegarder_MouseEnter);
            this.pictSauvegarder.MouseLeave += new System.EventHandler(this.pictSauvegarder_MouseLeave);
            // 
            // pictAnnuler
            // 
            this.pictAnnuler.Image = global::fablab_saga.Properties.Resources.cancelIcon;
            this.pictAnnuler.Location = new System.Drawing.Point(737, 652);
            this.pictAnnuler.Name = "pictAnnuler";
            this.pictAnnuler.Size = new System.Drawing.Size(110, 110);
            this.pictAnnuler.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictAnnuler.TabIndex = 76;
            this.pictAnnuler.TabStop = false;
            this.pictAnnuler.Click += new System.EventHandler(this.pictAnnuler_Click);
            this.pictAnnuler.MouseEnter += new System.EventHandler(this.pictAnnuler_MouseEnter);
            this.pictAnnuler.MouseLeave += new System.EventHandler(this.pictAnnuler_MouseLeave);
            // 
            // UsrcNouvellePrestation
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Transparent;
            this.Controls.Add(this.lblIdentifiant);
            this.Controls.Add(this.lblNomIdentifiant);
            this.Controls.Add(this.lblAdherent);
            this.Controls.Add(this.lblNomPrenomAdherent);
            this.Controls.Add(this.lblTypePrestation);
            this.Controls.Add(this.combTypePrestation);
            this.Controls.Add(this.grbAjouterLigne);
            this.Controls.Add(this.dgvDetailPrestation);
            this.Controls.Add(this.lblCoutTotalCredits);
            this.Controls.Add(this.lblSommeTotalCredits);
            this.Controls.Add(this.pictAnnuler);
            this.Controls.Add(this.pictSauvegarder);
            this.Name = "UsrcNouvellePrestation";
            this.Size = new System.Drawing.Size(1024, 768);
            this.Load += new System.EventHandler(this.UsrcNouvellePrestation_Load);
            this.grbAjouterLigne.ResumeLayout(false);
            this.grbChoisirTypeConsommable.ResumeLayout(false);
            this.grbChoisirTypeConsommable.PerformLayout();
            this.grbChoisirConsommable.ResumeLayout(false);
            this.grbChoisirConsommable.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictAjouterLigne)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDetailPrestation)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictSauvegarder)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictAnnuler)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox grbAjouterLigne;
        private System.Windows.Forms.GroupBox grbChoisirTypeConsommable;
        private System.Windows.Forms.ComboBox combConsommable;
        private System.Windows.Forms.ComboBox combSousTypeConsommable;
        private System.Windows.Forms.ComboBox combTypeConsommable;
        private System.Windows.Forms.ComboBox combTypePrestation;
        private System.Windows.Forms.DataGridView dgvDetailPrestation;
        private System.Windows.Forms.TextBox txtLibelle;
        private System.Windows.Forms.Label lblIdentifiant;
        private System.Windows.Forms.TextBox txtQuantite;
        private System.Windows.Forms.Label lblLibelle;
        private System.Windows.Forms.Label lblConsommable;
        private System.Windows.Forms.Label lblQuantite;
        private System.Windows.Forms.Label lblUnite;
        private System.Windows.Forms.Label lblCoutCredits;
        private System.Windows.Forms.Label lblSommeCoutCredits;
        private System.Windows.Forms.Label lblTypeConsommable;
        private System.Windows.Forms.Label lblSousTypeConsommable;
        private System.Windows.Forms.Label lblNomPrenomAdherent;
        private System.Windows.Forms.Label lblAdherent;
        private System.Windows.Forms.Label lblNomIdentifiant;
        private System.Windows.Forms.Label lblTypePrestation;
        private System.Windows.Forms.Label lblCoutTotalCredits;
        private System.Windows.Forms.Label lblSommeTotalCredits;
        private System.Windows.Forms.PictureBox pictAjouterLigne;
        private System.Windows.Forms.GroupBox grbChoisirConsommable;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Consommables;
        private System.Windows.Forms.DataGridViewTextBoxColumn Libelles;
        private System.Windows.Forms.DataGridViewTextBoxColumn Quantites;
        private System.Windows.Forms.DataGridViewTextBoxColumn Montants;
        private System.Windows.Forms.Label lblErreurInt;
        private System.Windows.Forms.PictureBox pictSauvegarder;
        private System.Windows.Forms.PictureBox pictAnnuler;
    }
}
