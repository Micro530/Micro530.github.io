﻿
namespace fablab_saga.vue.ControleUtilisateur
{
    partial class UsrcRechercheAdherent
    {
        /// <summary> 
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Code généré par le Concepteur de composants

        /// <summary> 
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas 
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblNom = new System.Windows.Forms.Label();
            this.lblPrenom = new System.Windows.Forms.Label();
            this.lblDateNaissance = new System.Windows.Forms.Label();
            this.combNom = new System.Windows.Forms.ComboBox();
            this.combPrenom = new System.Windows.Forms.ComboBox();
            this.combDateNaissance = new System.Windows.Forms.ComboBox();
            this.pictbSauvegerder = new System.Windows.Forms.PictureBox();
            this.pictbAnnuler = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictbSauvegerder)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictbAnnuler)).BeginInit();
            this.SuspendLayout();
            // 
            // lblNom
            // 
            this.lblNom.AutoSize = true;
            this.lblNom.BackColor = System.Drawing.Color.Transparent;
            this.lblNom.Font = new System.Drawing.Font("Lucida Console", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNom.Location = new System.Drawing.Point(125, 284);
            this.lblNom.Name = "lblNom";
            this.lblNom.Size = new System.Drawing.Size(38, 16);
            this.lblNom.TabIndex = 25;
            this.lblNom.Text = "Nom";
            // 
            // lblPrenom
            // 
            this.lblPrenom.AutoSize = true;
            this.lblPrenom.BackColor = System.Drawing.Color.Transparent;
            this.lblPrenom.Font = new System.Drawing.Font("Lucida Console", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPrenom.Location = new System.Drawing.Point(423, 284);
            this.lblPrenom.Name = "lblPrenom";
            this.lblPrenom.Size = new System.Drawing.Size(68, 16);
            this.lblPrenom.TabIndex = 26;
            this.lblPrenom.Text = "Prénom";
            // 
            // lblDateNaissance
            // 
            this.lblDateNaissance.AutoSize = true;
            this.lblDateNaissance.BackColor = System.Drawing.Color.Transparent;
            this.lblDateNaissance.Font = new System.Drawing.Font("Lucida Console", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDateNaissance.Location = new System.Drawing.Point(719, 284);
            this.lblDateNaissance.Name = "lblDateNaissance";
            this.lblDateNaissance.Size = new System.Drawing.Size(178, 16);
            this.lblDateNaissance.TabIndex = 27;
            this.lblDateNaissance.Text = "Date de naissance";
            // 
            // combNom
            // 
            this.combNom.Font = new System.Drawing.Font("Lucida Console", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.combNom.FormattingEnabled = true;
            this.combNom.Location = new System.Drawing.Point(128, 303);
            this.combNom.Name = "combNom";
            this.combNom.Size = new System.Drawing.Size(170, 24);
            this.combNom.TabIndex = 29;
            this.combNom.SelectedIndexChanged += new System.EventHandler(this.combNom_SelectedIndexChanged);
            // 
            // combPrenom
            // 
            this.combPrenom.Font = new System.Drawing.Font("Lucida Console", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.combPrenom.FormattingEnabled = true;
            this.combPrenom.Location = new System.Drawing.Point(426, 303);
            this.combPrenom.Name = "combPrenom";
            this.combPrenom.Size = new System.Drawing.Size(170, 24);
            this.combPrenom.TabIndex = 30;
            this.combPrenom.SelectedIndexChanged += new System.EventHandler(this.combPrenom_SelectedIndexChanged);
            // 
            // combDateNaissance
            // 
            this.combDateNaissance.Font = new System.Drawing.Font("Lucida Console", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.combDateNaissance.FormattingEnabled = true;
            this.combDateNaissance.Location = new System.Drawing.Point(724, 303);
            this.combDateNaissance.Name = "combDateNaissance";
            this.combDateNaissance.Size = new System.Drawing.Size(170, 24);
            this.combDateNaissance.TabIndex = 33;
            // 
            // pictbSauvegerder
            // 
            this.pictbSauvegerder.BackColor = System.Drawing.Color.Transparent;
            this.pictbSauvegerder.Image = global::fablab_saga.Properties.Resources.fleche;
            this.pictbSauvegerder.Location = new System.Drawing.Point(865, 389);
            this.pictbSauvegerder.Name = "pictbSauvegerder";
            this.pictbSauvegerder.Size = new System.Drawing.Size(110, 110);
            this.pictbSauvegerder.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictbSauvegerder.TabIndex = 35;
            this.pictbSauvegerder.TabStop = false;
            this.pictbSauvegerder.Click += new System.EventHandler(this.pictbSauvegerder_Click);
            this.pictbSauvegerder.MouseEnter += new System.EventHandler(this.pictbSauvegerder_MouseEnter);
            this.pictbSauvegerder.MouseLeave += new System.EventHandler(this.pictbSauvegerder_MouseLeave);
            // 
            // pictbAnnuler
            // 
            this.pictbAnnuler.BackColor = System.Drawing.Color.Transparent;
            this.pictbAnnuler.Image = global::fablab_saga.Properties.Resources.cancelIcon;
            this.pictbAnnuler.Location = new System.Drawing.Point(725, 389);
            this.pictbAnnuler.Name = "pictbAnnuler";
            this.pictbAnnuler.Size = new System.Drawing.Size(110, 110);
            this.pictbAnnuler.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictbAnnuler.TabIndex = 34;
            this.pictbAnnuler.TabStop = false;
            this.pictbAnnuler.Click += new System.EventHandler(this.pictbAnnuler_Click);
            this.pictbAnnuler.MouseEnter += new System.EventHandler(this.pictbAnnuler_MouseEnter);
            this.pictbAnnuler.MouseLeave += new System.EventHandler(this.pictbAnnuler_MouseLeave);
            // 
            // UsrcRechercheAdherent
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Transparent;
            this.Controls.Add(this.lblNom);
            this.Controls.Add(this.combNom);
            this.Controls.Add(this.lblPrenom);
            this.Controls.Add(this.combPrenom);
            this.Controls.Add(this.lblDateNaissance);
            this.Controls.Add(this.combDateNaissance);
            this.Controls.Add(this.pictbAnnuler);
            this.Controls.Add(this.pictbSauvegerder);
            this.Name = "UsrcRechercheAdherent";
            this.Size = new System.Drawing.Size(1024, 768);
            this.Load += new System.EventHandler(this.UsrcRechercheAdherent_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictbSauvegerder)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictbAnnuler)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblDateNaissance;
        private System.Windows.Forms.Label lblPrenom;
        private System.Windows.Forms.Label lblNom;
        private System.Windows.Forms.ComboBox combNom;
        private System.Windows.Forms.ComboBox combPrenom;
        private System.Windows.Forms.ComboBox combDateNaissance;
        private System.Windows.Forms.PictureBox pictbSauvegerder;
        private System.Windows.Forms.PictureBox pictbAnnuler;
    }
}
