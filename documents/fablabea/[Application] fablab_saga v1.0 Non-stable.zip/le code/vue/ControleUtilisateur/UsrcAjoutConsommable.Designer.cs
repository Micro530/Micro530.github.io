﻿
namespace fablab_saga.vue.ControleUtilisateur
{
    partial class UsrcAjoutConsommable
    {
        /// <summary> 
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Code généré par le Concepteur de composants

        /// <summary> 
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas 
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent()
        {
            this.grbSelecType = new System.Windows.Forms.GroupBox();
            this.rbtnTypeConsommable = new System.Windows.Forms.RadioButton();
            this.combTypeConsommable = new System.Windows.Forms.ComboBox();
            this.rbtnNewTypeConsommable = new System.Windows.Forms.RadioButton();
            this.txtNewTypeConsommable = new System.Windows.Forms.TextBox();
            this.grbSelecSousType = new System.Windows.Forms.GroupBox();
            this.rbtnSousTypeConsommable = new System.Windows.Forms.RadioButton();
            this.combSousType = new System.Windows.Forms.ComboBox();
            this.rbtnNewSousTypeConsommable = new System.Windows.Forms.RadioButton();
            this.txtNewSousType = new System.Windows.Forms.TextBox();
            this.grbSelecUnite = new System.Windows.Forms.GroupBox();
            this.rbtnUnite = new System.Windows.Forms.RadioButton();
            this.combUnite = new System.Windows.Forms.ComboBox();
            this.rbtnNewUnite = new System.Windows.Forms.RadioButton();
            this.txtNewUnite = new System.Windows.Forms.TextBox();
            this.grbLibellePrix = new System.Windows.Forms.GroupBox();
            this.lblLibelle = new System.Windows.Forms.Label();
            this.txtLibelle = new System.Windows.Forms.TextBox();
            this.lblPrix = new System.Windows.Forms.Label();
            this.txtPrix = new System.Windows.Forms.TextBox();
            this.lblCredits = new System.Windows.Forms.Label();
            this.lblErreurInt = new System.Windows.Forms.Label();
            this.lblNomIdentifiant = new System.Windows.Forms.Label();
            this.lblIdentifiant = new System.Windows.Forms.Label();
            this.pictSauvegarder = new System.Windows.Forms.PictureBox();
            this.pictAnnuler = new System.Windows.Forms.PictureBox();
            this.btnSupprimerConsommable = new System.Windows.Forms.Button();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.lblTitre = new System.Windows.Forms.Label();
            this.grbSelecType.SuspendLayout();
            this.grbSelecSousType.SuspendLayout();
            this.grbSelecUnite.SuspendLayout();
            this.grbLibellePrix.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictSauvegarder)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictAnnuler)).BeginInit();
            this.SuspendLayout();
            // 
            // grbSelecType
            // 
            this.grbSelecType.Controls.Add(this.rbtnTypeConsommable);
            this.grbSelecType.Controls.Add(this.combTypeConsommable);
            this.grbSelecType.Controls.Add(this.rbtnNewTypeConsommable);
            this.grbSelecType.Controls.Add(this.txtNewTypeConsommable);
            this.grbSelecType.Font = new System.Drawing.Font("Lucida Console", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grbSelecType.Location = new System.Drawing.Point(24, 98);
            this.grbSelecType.Name = "grbSelecType";
            this.grbSelecType.Size = new System.Drawing.Size(969, 80);
            this.grbSelecType.TabIndex = 0;
            this.grbSelecType.TabStop = false;
            this.grbSelecType.Text = "Selectionnez son type ou créez-en nouveau";
            // 
            // rbtnTypeConsommable
            // 
            this.rbtnTypeConsommable.Checked = true;
            this.rbtnTypeConsommable.Location = new System.Drawing.Point(31, 34);
            this.rbtnTypeConsommable.Name = "rbtnTypeConsommable";
            this.rbtnTypeConsommable.Size = new System.Drawing.Size(214, 24);
            this.rbtnTypeConsommable.TabIndex = 32;
            this.rbtnTypeConsommable.TabStop = true;
            this.rbtnTypeConsommable.Text = "Type Consommable :";
            this.rbtnTypeConsommable.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.rbtnTypeConsommable.UseVisualStyleBackColor = true;
            this.rbtnTypeConsommable.CheckedChanged += new System.EventHandler(this.rbtnTypeConsommable_CheckedChanged);
            // 
            // combTypeConsommable
            // 
            this.combTypeConsommable.Font = new System.Drawing.Font("Lucida Console", 10F);
            this.combTypeConsommable.FormattingEnabled = true;
            this.combTypeConsommable.Location = new System.Drawing.Point(251, 34);
            this.combTypeConsommable.Name = "combTypeConsommable";
            this.combTypeConsommable.Size = new System.Drawing.Size(307, 21);
            this.combTypeConsommable.TabIndex = 31;
            this.combTypeConsommable.SelectedIndexChanged += new System.EventHandler(this.combTypeConsommable_SelectionChange);
            this.combTypeConsommable.SelectionChangeCommitted += new System.EventHandler(this.combTypeConsommable_SelectionChange);
            // 
            // rbtnNewTypeConsommable
            // 
            this.rbtnNewTypeConsommable.AutoSize = true;
            this.rbtnNewTypeConsommable.Location = new System.Drawing.Point(592, 39);
            this.rbtnNewTypeConsommable.Name = "rbtnNewTypeConsommable";
            this.rbtnNewTypeConsommable.Size = new System.Drawing.Size(14, 13);
            this.rbtnNewTypeConsommable.TabIndex = 33;
            this.rbtnNewTypeConsommable.UseVisualStyleBackColor = true;
            // 
            // txtNewTypeConsommable
            // 
            this.txtNewTypeConsommable.Enabled = false;
            this.txtNewTypeConsommable.Font = new System.Drawing.Font("Lucida Console", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNewTypeConsommable.Location = new System.Drawing.Point(612, 35);
            this.txtNewTypeConsommable.Name = "txtNewTypeConsommable";
            this.txtNewTypeConsommable.Size = new System.Drawing.Size(307, 23);
            this.txtNewTypeConsommable.TabIndex = 11;
            // 
            // grbSelecSousType
            // 
            this.grbSelecSousType.Controls.Add(this.rbtnSousTypeConsommable);
            this.grbSelecSousType.Controls.Add(this.combSousType);
            this.grbSelecSousType.Controls.Add(this.rbtnNewSousTypeConsommable);
            this.grbSelecSousType.Controls.Add(this.txtNewSousType);
            this.grbSelecSousType.Font = new System.Drawing.Font("Lucida Console", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grbSelecSousType.Location = new System.Drawing.Point(24, 228);
            this.grbSelecSousType.Name = "grbSelecSousType";
            this.grbSelecSousType.Size = new System.Drawing.Size(969, 80);
            this.grbSelecSousType.TabIndex = 1;
            this.grbSelecSousType.TabStop = false;
            this.grbSelecSousType.Text = "Selectionnez son sous type ou créez-en nouveau";
            // 
            // rbtnSousTypeConsommable
            // 
            this.rbtnSousTypeConsommable.Checked = true;
            this.rbtnSousTypeConsommable.Location = new System.Drawing.Point(31, 33);
            this.rbtnSousTypeConsommable.Name = "rbtnSousTypeConsommable";
            this.rbtnSousTypeConsommable.Size = new System.Drawing.Size(214, 24);
            this.rbtnSousTypeConsommable.TabIndex = 36;
            this.rbtnSousTypeConsommable.TabStop = true;
            this.rbtnSousTypeConsommable.Text = "Sous type :";
            this.rbtnSousTypeConsommable.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.rbtnSousTypeConsommable.UseVisualStyleBackColor = true;
            this.rbtnSousTypeConsommable.CheckedChanged += new System.EventHandler(this.rbtnSousTypeConsommable_CheckedChanged);
            // 
            // combSousType
            // 
            this.combSousType.Font = new System.Drawing.Font("Lucida Console", 10F);
            this.combSousType.FormattingEnabled = true;
            this.combSousType.Location = new System.Drawing.Point(251, 33);
            this.combSousType.Name = "combSousType";
            this.combSousType.Size = new System.Drawing.Size(307, 21);
            this.combSousType.TabIndex = 35;
            // 
            // rbtnNewSousTypeConsommable
            // 
            this.rbtnNewSousTypeConsommable.AutoSize = true;
            this.rbtnNewSousTypeConsommable.Location = new System.Drawing.Point(592, 38);
            this.rbtnNewSousTypeConsommable.Name = "rbtnNewSousTypeConsommable";
            this.rbtnNewSousTypeConsommable.Size = new System.Drawing.Size(14, 13);
            this.rbtnNewSousTypeConsommable.TabIndex = 37;
            this.rbtnNewSousTypeConsommable.UseVisualStyleBackColor = true;
            // 
            // txtNewSousType
            // 
            this.txtNewSousType.Enabled = false;
            this.txtNewSousType.Font = new System.Drawing.Font("Lucida Console", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNewSousType.Location = new System.Drawing.Point(612, 33);
            this.txtNewSousType.Name = "txtNewSousType";
            this.txtNewSousType.Size = new System.Drawing.Size(307, 23);
            this.txtNewSousType.TabIndex = 34;
            // 
            // grbSelecUnite
            // 
            this.grbSelecUnite.Controls.Add(this.rbtnUnite);
            this.grbSelecUnite.Controls.Add(this.combUnite);
            this.grbSelecUnite.Controls.Add(this.rbtnNewUnite);
            this.grbSelecUnite.Controls.Add(this.txtNewUnite);
            this.grbSelecUnite.Font = new System.Drawing.Font("Lucida Console", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grbSelecUnite.Location = new System.Drawing.Point(24, 357);
            this.grbSelecUnite.Name = "grbSelecUnite";
            this.grbSelecUnite.Size = new System.Drawing.Size(969, 80);
            this.grbSelecUnite.TabIndex = 1;
            this.grbSelecUnite.TabStop = false;
            this.grbSelecUnite.Text = "Selectionnez son unité ou créez-en nouveau";
            // 
            // rbtnUnite
            // 
            this.rbtnUnite.Checked = true;
            this.rbtnUnite.Location = new System.Drawing.Point(31, 34);
            this.rbtnUnite.Name = "rbtnUnite";
            this.rbtnUnite.Size = new System.Drawing.Size(204, 24);
            this.rbtnUnite.TabIndex = 40;
            this.rbtnUnite.TabStop = true;
            this.rbtnUnite.Text = "Unité :";
            this.rbtnUnite.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.rbtnUnite.UseVisualStyleBackColor = true;
            this.rbtnUnite.CheckedChanged += new System.EventHandler(this.rbtnUnite_CheckedChanged);
            // 
            // combUnite
            // 
            this.combUnite.Font = new System.Drawing.Font("Lucida Console", 10F);
            this.combUnite.FormattingEnabled = true;
            this.combUnite.Location = new System.Drawing.Point(251, 35);
            this.combUnite.Name = "combUnite";
            this.combUnite.Size = new System.Drawing.Size(307, 21);
            this.combUnite.TabIndex = 39;
            // 
            // rbtnNewUnite
            // 
            this.rbtnNewUnite.AutoSize = true;
            this.rbtnNewUnite.Location = new System.Drawing.Point(592, 39);
            this.rbtnNewUnite.Name = "rbtnNewUnite";
            this.rbtnNewUnite.Size = new System.Drawing.Size(14, 13);
            this.rbtnNewUnite.TabIndex = 41;
            this.rbtnNewUnite.UseVisualStyleBackColor = true;
            // 
            // txtNewUnite
            // 
            this.txtNewUnite.Enabled = false;
            this.txtNewUnite.Font = new System.Drawing.Font("Lucida Console", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNewUnite.Location = new System.Drawing.Point(612, 36);
            this.txtNewUnite.Name = "txtNewUnite";
            this.txtNewUnite.Size = new System.Drawing.Size(307, 23);
            this.txtNewUnite.TabIndex = 38;
            // 
            // grbLibellePrix
            // 
            this.grbLibellePrix.Controls.Add(this.lblLibelle);
            this.grbLibellePrix.Controls.Add(this.txtLibelle);
            this.grbLibellePrix.Controls.Add(this.lblPrix);
            this.grbLibellePrix.Controls.Add(this.txtPrix);
            this.grbLibellePrix.Controls.Add(this.lblCredits);
            this.grbLibellePrix.Controls.Add(this.lblErreurInt);
            this.grbLibellePrix.Font = new System.Drawing.Font("Lucida Console", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grbLibellePrix.Location = new System.Drawing.Point(24, 485);
            this.grbLibellePrix.Name = "grbLibellePrix";
            this.grbLibellePrix.Size = new System.Drawing.Size(969, 98);
            this.grbLibellePrix.TabIndex = 1;
            this.grbLibellePrix.TabStop = false;
            this.grbLibellePrix.Text = "Renseignez son libellé ainsi que son prix unitaire";
            // 
            // lblLibelle
            // 
            this.lblLibelle.AutoSize = true;
            this.lblLibelle.BackColor = System.Drawing.Color.Transparent;
            this.lblLibelle.Font = new System.Drawing.Font("Lucida Console", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLibelle.Location = new System.Drawing.Point(137, 37);
            this.lblLibelle.Name = "lblLibelle";
            this.lblLibelle.Size = new System.Drawing.Size(98, 16);
            this.lblLibelle.TabIndex = 69;
            this.lblLibelle.Text = "Libellé :";
            // 
            // txtLibelle
            // 
            this.txtLibelle.Font = new System.Drawing.Font("Lucida Console", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLibelle.Location = new System.Drawing.Point(251, 34);
            this.txtLibelle.Name = "txtLibelle";
            this.txtLibelle.Size = new System.Drawing.Size(261, 23);
            this.txtLibelle.TabIndex = 73;
            // 
            // lblPrix
            // 
            this.lblPrix.AutoSize = true;
            this.lblPrix.BackColor = System.Drawing.Color.Transparent;
            this.lblPrix.Font = new System.Drawing.Font("Lucida Console", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPrix.Location = new System.Drawing.Point(569, 37);
            this.lblPrix.Name = "lblPrix";
            this.lblPrix.Size = new System.Drawing.Size(158, 16);
            this.lblPrix.TabIndex = 70;
            this.lblPrix.Text = "Prix unitaire :";
            // 
            // txtPrix
            // 
            this.txtPrix.Font = new System.Drawing.Font("Lucida Console", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPrix.Location = new System.Drawing.Point(733, 34);
            this.txtPrix.Name = "txtPrix";
            this.txtPrix.Size = new System.Drawing.Size(130, 23);
            this.txtPrix.TabIndex = 72;
            this.txtPrix.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtPrix_KeyUp);
            // 
            // lblCredits
            // 
            this.lblCredits.AutoSize = true;
            this.lblCredits.BackColor = System.Drawing.Color.Transparent;
            this.lblCredits.Font = new System.Drawing.Font("Lucida Console", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCredits.Location = new System.Drawing.Point(866, 37);
            this.lblCredits.Name = "lblCredits";
            this.lblCredits.Size = new System.Drawing.Size(78, 16);
            this.lblCredits.TabIndex = 71;
            this.lblCredits.Text = "Crédits";
            // 
            // lblErreurInt
            // 
            this.lblErreurInt.AutoSize = true;
            this.lblErreurInt.BackColor = System.Drawing.Color.Transparent;
            this.lblErreurInt.Font = new System.Drawing.Font("Lucida Console", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblErreurInt.ForeColor = System.Drawing.Color.Red;
            this.lblErreurInt.Location = new System.Drawing.Point(569, 69);
            this.lblErreurInt.Name = "lblErreurInt";
            this.lblErreurInt.Size = new System.Drawing.Size(0, 16);
            this.lblErreurInt.TabIndex = 74;
            // 
            // lblNomIdentifiant
            // 
            this.lblNomIdentifiant.AutoSize = true;
            this.lblNomIdentifiant.BackColor = System.Drawing.Color.Transparent;
            this.lblNomIdentifiant.Font = new System.Drawing.Font("Lucida Console", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNomIdentifiant.Location = new System.Drawing.Point(265, 20);
            this.lblNomIdentifiant.Name = "lblNomIdentifiant";
            this.lblNomIdentifiant.Size = new System.Drawing.Size(178, 16);
            this.lblNomIdentifiant.TabIndex = 25;
            this.lblNomIdentifiant.Text = "<nom utilisateur>";
            // 
            // lblIdentifiant
            // 
            this.lblIdentifiant.AutoSize = true;
            this.lblIdentifiant.BackColor = System.Drawing.Color.Transparent;
            this.lblIdentifiant.Font = new System.Drawing.Font("Lucida Console", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIdentifiant.Location = new System.Drawing.Point(21, 20);
            this.lblIdentifiant.Name = "lblIdentifiant";
            this.lblIdentifiant.Size = new System.Drawing.Size(238, 16);
            this.lblIdentifiant.TabIndex = 24;
            this.lblIdentifiant.Text = "Connecté en temps que :";
            // 
            // pictSauvegarder
            // 
            this.pictSauvegarder.Image = global::fablab_saga.Properties.Resources.save;
            this.pictSauvegarder.Location = new System.Drawing.Point(872, 635);
            this.pictSauvegarder.Name = "pictSauvegarder";
            this.pictSauvegarder.Size = new System.Drawing.Size(110, 110);
            this.pictSauvegarder.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictSauvegarder.TabIndex = 32;
            this.pictSauvegarder.TabStop = false;
            this.pictSauvegarder.Click += new System.EventHandler(this.pictSauvegarder_Click);
            this.pictSauvegarder.MouseEnter += new System.EventHandler(this.pictSauvegarder_MouseEnter);
            this.pictSauvegarder.MouseLeave += new System.EventHandler(this.pictSauvegarder_MouseLeave);
            // 
            // pictAnnuler
            // 
            this.pictAnnuler.Image = global::fablab_saga.Properties.Resources.cancelIcon;
            this.pictAnnuler.Location = new System.Drawing.Point(707, 635);
            this.pictAnnuler.Name = "pictAnnuler";
            this.pictAnnuler.Size = new System.Drawing.Size(110, 110);
            this.pictAnnuler.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictAnnuler.TabIndex = 31;
            this.pictAnnuler.TabStop = false;
            this.pictAnnuler.Click += new System.EventHandler(this.pictAnnuler_Click);
            this.pictAnnuler.MouseEnter += new System.EventHandler(this.pictAnnuler_MouseEnter);
            this.pictAnnuler.MouseLeave += new System.EventHandler(this.pictAnnuler_MouseLeave);
            // 
            // btnSupprimerConsommable
            // 
            this.btnSupprimerConsommable.Font = new System.Drawing.Font("Lucida Console", 12F);
            this.btnSupprimerConsommable.ForeColor = System.Drawing.Color.Red;
            this.btnSupprimerConsommable.Location = new System.Drawing.Point(24, 676);
            this.btnSupprimerConsommable.Name = "btnSupprimerConsommable";
            this.btnSupprimerConsommable.Size = new System.Drawing.Size(381, 69);
            this.btnSupprimerConsommable.TabIndex = 33;
            this.btnSupprimerConsommable.Text = "Supprimer ce consommable";
            this.btnSupprimerConsommable.UseVisualStyleBackColor = true;
            this.btnSupprimerConsommable.Visible = false;
            this.btnSupprimerConsommable.Click += new System.EventHandler(this.btnSupprimerConsommable_Click);
            // 
            // lblTitre
            // 
            this.lblTitre.AutoSize = true;
            this.lblTitre.BackColor = System.Drawing.Color.Transparent;
            this.lblTitre.Font = new System.Drawing.Font("Lucida Console", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitre.Location = new System.Drawing.Point(612, 17);
            this.lblTitre.Name = "lblTitre";
            this.lblTitre.Size = new System.Drawing.Size(328, 19);
            this.lblTitre.TabIndex = 34;
            this.lblTitre.Text = "Mode : Ajouter un consommable";
            // 
            // UsrcAjoutConsommable
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Transparent;
            this.Controls.Add(this.lblTitre);
            this.Controls.Add(this.btnSupprimerConsommable);
            this.Controls.Add(this.lblIdentifiant);
            this.Controls.Add(this.lblNomIdentifiant);
            this.Controls.Add(this.grbSelecType);
            this.Controls.Add(this.grbSelecSousType);
            this.Controls.Add(this.grbSelecUnite);
            this.Controls.Add(this.grbLibellePrix);
            this.Controls.Add(this.pictAnnuler);
            this.Controls.Add(this.pictSauvegarder);
            this.Name = "UsrcAjoutConsommable";
            this.Size = new System.Drawing.Size(1024, 768);
            this.Load += new System.EventHandler(this.UsrcAjoutConsommable_Load);
            this.grbSelecType.ResumeLayout(false);
            this.grbSelecType.PerformLayout();
            this.grbSelecSousType.ResumeLayout(false);
            this.grbSelecSousType.PerformLayout();
            this.grbSelecUnite.ResumeLayout(false);
            this.grbSelecUnite.PerformLayout();
            this.grbLibellePrix.ResumeLayout(false);
            this.grbLibellePrix.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictSauvegarder)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictAnnuler)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox grbSelecType;
        private System.Windows.Forms.GroupBox grbSelecSousType;
        private System.Windows.Forms.GroupBox grbSelecUnite;
        private System.Windows.Forms.GroupBox grbLibellePrix;
        private System.Windows.Forms.Label lblNomIdentifiant;
        private System.Windows.Forms.Label lblIdentifiant;
        private System.Windows.Forms.TextBox txtNewTypeConsommable;
        private System.Windows.Forms.RadioButton rbtnNewTypeConsommable;
        private System.Windows.Forms.RadioButton rbtnTypeConsommable;
        private System.Windows.Forms.ComboBox combTypeConsommable;
        private System.Windows.Forms.RadioButton rbtnNewSousTypeConsommable;
        private System.Windows.Forms.RadioButton rbtnSousTypeConsommable;
        private System.Windows.Forms.TextBox txtNewSousType;
        private System.Windows.Forms.ComboBox combSousType;
        private System.Windows.Forms.RadioButton rbtnNewUnite;
        private System.Windows.Forms.RadioButton rbtnUnite;
        private System.Windows.Forms.TextBox txtNewUnite;
        private System.Windows.Forms.ComboBox combUnite;
        private System.Windows.Forms.TextBox txtPrix;
        private System.Windows.Forms.Label lblCredits;
        private System.Windows.Forms.Label lblLibelle;
        private System.Windows.Forms.Label lblPrix;
        private System.Windows.Forms.PictureBox pictSauvegarder;
        private System.Windows.Forms.PictureBox pictAnnuler;
        private System.Windows.Forms.TextBox txtLibelle;
        private System.Windows.Forms.Label lblErreurInt;
        private System.Windows.Forms.Button btnSupprimerConsommable;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.Label lblTitre;
    }
}
