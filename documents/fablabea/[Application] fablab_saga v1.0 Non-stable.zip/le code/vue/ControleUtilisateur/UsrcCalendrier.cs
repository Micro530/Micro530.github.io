﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace fablab_saga.vue.ControleUtilisateur
{
    public partial class UsrcCalendrier : UserControl
    {
        public UsrcCalendrier()
        {
            InitializeComponent();
        }

        private void Calendrier_Load(object sender, EventArgs e)
        {
            RemplissageCombo();
            MajLblDataNaissance();
        }
        /// <summary>
        /// Permet de remplir les comboBox 
        /// </summary>
        private void RemplissageCombo()
        {
            List<int> jour = new List<int> { };
            List<string> mois = new List<string> {"Janvier", "Fevrier", "Mars", "Avril", "Mai", "Juin",
                "Juillet", "Août", "Septembre", "Octobre", "Novembre", "Décembre"};
            List<int> annee = new List<int> { };
            for (int i = 1; i < 32; i++)
            {
                jour.Add(i);
            }
            for (int i = DateTime.Now.Year; i > 1899; i--)
            {
                annee.Add(i);
            }
            combJour.DataSource = jour;
            combMois.DataSource = mois;
            combAnnee.DataSource = annee;
        }
        private void MajLblDataNaissance()
        {
            lblDateNaissance.Text = $"Le {combJour.Text} {combMois.Text} {combAnnee.Text}";
        }
        private void combJour_SelectedIndexChanged(object sender, EventArgs e)
        {
            MajLblDataNaissance();
        }
        /// <summary>
        /// Retourne la date choisie
        /// </summary>
        /// <returns>le dateTime contenant la date selectionné</returns>
        public DateTime GetDateNaissance()
        {
            DateTime date = new DateTime(int.Parse(combAnnee.SelectedItem.ToString()),combMois.SelectedIndex + 1,int.Parse(combJour.SelectedItem.ToString()));
            return date;
        }
        public void SetDateNaissance(DateTime dateNaissance)
        {
            combJour.SelectedItem = dateNaissance.Day;
            combMois.SelectedIndex = dateNaissance.Month - 1;
            combAnnee.SelectedItem = dateNaissance.Year;
        }
        public void ResetComboBox()
        {
            combAnnee.SelectedIndex = 0;
            combMois.SelectedIndex = 0;
            combJour.SelectedIndex = 0;
        }
        public bool SelectionDateNaissance()
        {
            if(combAnnee.SelectedIndex.Equals(-1) || combMois.SelectedIndex.Equals(-1) || combJour.SelectedIndex.Equals(-1))
            {
                return false;
            }
            else
            {
                return true;
            }
        }
    }
}
