﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace fablab_saga.model
{
    public class Rechargement
    {
        private int idAdherent;
        private DateTime dateRechargement;
        private float nbCredits;

        public Rechargement(int idAdherent, DateTime dateRechargement, float nbCredits)
        {
            this.IdAdherent = idAdherent;
            this.DateRechargement = dateRechargement;
            this.NbCredits = nbCredits;
        }

        public int IdAdherent { get => idAdherent; set => idAdherent = value; }
        public DateTime DateRechargement { get => dateRechargement; set => dateRechargement = value; }
        public float NbCredits { get => nbCredits; set => nbCredits = value; }
    }
}
