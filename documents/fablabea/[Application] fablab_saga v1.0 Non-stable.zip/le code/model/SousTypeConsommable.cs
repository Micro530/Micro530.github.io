﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace fablab_saga.model
{
    public class SousTypeConsommable
    {
        private int idSousTypeConsommable;
        private int idTypeConsommable;
        private string libelle;

        public SousTypeConsommable(int idSousTypeConsommable, int idTypeConsommable, string libelle)
        {
            this.IdSousTypeConsommable = idSousTypeConsommable;
            this.IdTypeConsommable = idTypeConsommable;
            this.Libelle = libelle;
        }

        public int IdSousTypeConsommable { get => idSousTypeConsommable; set => idSousTypeConsommable = value; }
        public string Libelle { get => libelle; set => libelle = value; }
        public int IdTypeConsommable { get => idTypeConsommable; set => idTypeConsommable = value; }
    }
}
