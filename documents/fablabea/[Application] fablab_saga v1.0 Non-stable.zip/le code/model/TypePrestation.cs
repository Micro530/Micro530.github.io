﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace fablab_saga.model
{
    public class TypePrestation
    {
        private int idTypePrestation;
        private string nomPrestation;

        public TypePrestation(int idTypePrestation, string nomPrestation)
        {
            this.IdTypePrestation = idTypePrestation;
            this.NomPrestation = nomPrestation;
        }

        public int IdTypePrestation { get => idTypePrestation; set => idTypePrestation = value; }
        public string NomPrestation { get => nomPrestation; set => nomPrestation = value; }
    }
}
