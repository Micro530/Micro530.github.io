﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace fablab_saga.model
{
    public class Prestation
    {
        private int idPrestation;
        private int idTypePrestation;
        private int idAdherent;
        private DateTime datePrestation;
        private float montantTotalPrestation;
        private string libelle;

        public Prestation(int idPrestation, int idTypePrestation, int idAdherent, DateTime datePrestation, float montantTotalPrestation, string libelle)
        {
            this.IdPrestation = idPrestation;
            this.IdTypePrestation = idTypePrestation;
            this.IdAdherent = idAdherent;
            this.DatePrestation = datePrestation;
            this.MontantTotalPrestation = montantTotalPrestation;
            this.Libelle = libelle;
        }

        public int IdPrestation { get => idPrestation; set => idPrestation = value; }
        public int IdTypePrestation { get => idTypePrestation; set => idTypePrestation = value; }
        public int IdAdherent { get => idAdherent; set => idAdherent = value; }
        public DateTime DatePrestation { get => datePrestation; set => datePrestation = value; }
        public float MontantTotalPrestation { get => montantTotalPrestation; set => montantTotalPrestation = value; }
        public string Libelle { get => libelle; set => libelle = value; }
    }
}
