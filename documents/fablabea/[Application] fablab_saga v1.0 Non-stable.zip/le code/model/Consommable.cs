﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace fablab_saga.model
{
    public class Consommable
    {
        private int idConsommable;
        private int idTypeConsommable;
        private int idSousTypeConsommable;
        private string libelleConsommable;
        private float prixConsommable;

        public Consommable(int idConsommable, int idTypeConsommable, int idSousTypeConsommable, string libelleConsommable, float prixConsommable)
        {
            this.IdConsommable = idConsommable;
            this.IdTypeConsommable = idTypeConsommable;
            this.IdSousTypeConsommable = idSousTypeConsommable;
            this.LibelleConsommable = libelleConsommable;
            this.PrixConsommable = prixConsommable;
        }

        public int IdConsommable { get => idConsommable; set => idConsommable = value; }
        public int IdTypeConsommable { get => idTypeConsommable; set => idTypeConsommable = value; }
        public int IdSousTypeConsommable { get => idSousTypeConsommable; set => idSousTypeConsommable = value; }
        public string LibelleConsommable { get => libelleConsommable; set => libelleConsommable = value; }
        public float PrixConsommable { get => prixConsommable; set => prixConsommable = value; }
    }
}
