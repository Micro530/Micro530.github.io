﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace fablab_saga.model
{
    public class ConsommablePrestation
    {
        private int idPrestation;
        private int idConsommable;
        private string libelle;
        private float quantiteConsommable;
        private float montantConsommable;


        public ConsommablePrestation(int idPrestation, int idConsommable, string libelle, float quantiteConsommable, float montantConsommable)
        {
            this.IdPrestation = idPrestation;
            this.IdConsommable = idConsommable;
            this.Libelle = libelle;
            this.QuantiteConsommable = quantiteConsommable;
            this.MontantConsommable = montantConsommable;
        }

        public int IdPrestation { get => idPrestation; set => idPrestation = value; }
        public int IdConsommable { get => idConsommable; set => idConsommable = value; }
        public string Libelle { get => libelle; set => libelle = value; }
        public float QuantiteConsommable { get => quantiteConsommable; set => quantiteConsommable = value; }
        public float MontantConsommable { get => montantConsommable; set => montantConsommable = value; }
        
    }
}
