﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace fablab_saga.model
{
    public class Adherents
    {
        private int idAdherent;
        private string nomAdherent;
        private string prenomAdherent;
        private string telAdherent;
        private string emailAdherent;
        private DateTime dateNaissanceAdherent;
        private float montantCreditsAdherent;
        private DateTime dateOuvertureAbonnement;
        private DateTime dateFinAbonnement;

        public Adherents(int idAdherent, string nomAdherent, string prenomAdherent, string telAdherent, string emailAdherent, DateTime dateNaissanceAdherent,
            float montantCreditsAdherent, DateTime dateOuvertureAbonnement, DateTime dateFinAbonnement)
        {
            this.IdAdherent = idAdherent;
            this.NomAdherent = nomAdherent;
            this.PrenomAdherent = prenomAdherent;
            this.TelAdherent = telAdherent;
            this.EmailAdherent = emailAdherent;
            this.DateNaissanceAdherent = dateNaissanceAdherent;
            this.MontantCreditsAdherent = montantCreditsAdherent;
            this.DateOuvertureAbonnement = dateOuvertureAbonnement;
            this.DateFinAbonnement = dateFinAbonnement;
        }

        public int IdAdherent { get => idAdherent; set => idAdherent = value; }
        public string NomAdherent { get => nomAdherent; set => nomAdherent = value; }
        public string PrenomAdherent { get => prenomAdherent; set => prenomAdherent = value; }
        public string TelAdherent { get => telAdherent; set => telAdherent = value; }
        public string EmailAdherent { get => emailAdherent; set => emailAdherent = value; }
        public DateTime DateNaissanceAdherent { get => dateNaissanceAdherent; set => dateNaissanceAdherent = value; }
        public float MontantCreditsAdherent { get => montantCreditsAdherent; set => montantCreditsAdherent = value; }
        public DateTime DateOuvertureAbonnement { get => dateOuvertureAbonnement; set => dateOuvertureAbonnement = value; }
        public DateTime DateFinAbonnement { get => dateFinAbonnement; set => dateFinAbonnement = value; }
    }
}
