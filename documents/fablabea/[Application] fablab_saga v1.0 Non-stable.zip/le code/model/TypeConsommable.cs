﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace fablab_saga.model
{
    public class TypeConsommable
    {
        private int idTypeConsommable;
        private string typeConsommable;
        private string uniteConsommable;

        public TypeConsommable(int idTypeConsommable, string typeConsommable, string uniteConsommable)
        {
            this.IdTypeConsommable = idTypeConsommable;
            this.LeTypeConsommable = typeConsommable;
            this.UniteConsommable = uniteConsommable;
        }

        public int IdTypeConsommable { get => idTypeConsommable; set => idTypeConsommable = value; }
        public string LeTypeConsommable { get => typeConsommable; set => typeConsommable = value; }
        public string UniteConsommable { get => uniteConsommable; set => uniteConsommable = value; }
    }
}
