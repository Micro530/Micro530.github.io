﻿using fablab_saga.vue;
using fablab_saga.dal;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using fablab_saga.model;

namespace fablab_saga.controleur
{
    public class Controle
    {
        /// <summary>
        /// Instance du formulaire principale
        /// </summary>
        private FrmPrincipal frmPrincipal;
        /// <summary>
        /// Constructeur de controle qui instancie et affiche le formulaire principal
        /// </summary>
        public Controle()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            frmPrincipal = new FrmPrincipal(this);
            Application.Run(frmPrincipal);
        }
        /// <summary>
        /// La méthode qui permet de lancer la procédure d'authentification
        /// </summary>
        /// <param name="identifiant">l'identifiant de l'utilisateur</param>
        /// <param name="pwd">le mot de passe de l'utilisateur</param>
        public bool Authentification(string identifiant, string pwd)
        {
            return AccesDonnees.Authentification(identifiant, pwd); 
        }
        /// <summary>
        /// La méthode qui permet de lancer la procédure de déconnexion
        /// </summary>
        public void Deconnexion()
        {
            AccesDonnees.Deconnexion();
        }
        
        public Adherents RecupUnAdherent(int idAdherent)
        {
            return AccesDonnees.RecupUnAdherent(idAdherent);
        }
        /// <summary>
        /// Permet de retourner sur l'id en paramètre exite dans la table en paremètre
        /// </summary>
        /// <param name="tableBdd">table de la base de données</param>
        /// <param name="idAVerifier">id à vrifier</param>
        /// <param name="nomId">nom de l'id</param>
        /// <returns>retourne la présence ou non de l'id</returns>
        public bool RecupIDTableBdd(string tableBdd, int idAVerifier, string nomId)
        {
            return AccesDonnees.RecupIDTableBdd(tableBdd, idAVerifier, nomId);
        }
        /// <summary>
        /// Permet de récupérer les adhérents et les envoyer
        /// </summary>
        /// <returns></returns>
        public List<Adherents> GetLesAdherents()
        {
            return AccesDonnees.GetLesAdherents();
        }
        public List<TypePrestation> GetLesTypesPrestations()
        {
            return AccesDonnees.GetLesTypesPrestations();
        }
        public List<TypeConsommable> GetLesTypesConsommables()
        {
            return AccesDonnees.GetLesTypesConsommables();
        }
        public List<SousTypeConsommable> GetLesSousTypesConsommables()
        {
            return AccesDonnees.GetLesSousTypesConsommables();
        }
        public List<Consommable> GetLesConsommables()
        {
            return AccesDonnees.GetLesConsommables();
        }
        /// <summary>
        /// Permet de récupérer et d'envoyer les rechargements d'un adherent
        /// </summary>
        /// <param name="idAdherent"></param>
        /// <returns></returns>
        public List<Object> GetLesRechargements(int idAdherent, string dateTrie)
        {
            return AccesDonnees.GetLesRechargements(idAdherent, dateTrie);
        }
        /// <summary>
        /// Permet de récupérer et d'envoyer les prestations d'un adherent
        /// </summary>
        /// <param name="idAdherent"></param>
        /// <returns></returns>
        public List<Object> GetLesPrestations(int idAdherent, string dateTrie)
        {
            return AccesDonnees.GetLesPrestations(idAdherent, dateTrie);
        }
        /// <summary>
        /// Permet de récupérer et d'envoyer les consommables d'une prestation
        /// </summary>
        /// <param name="idPrestation"></param>
        /// <returns></returns>
        public List<ConsommablePrestation> GetLesConsommablePrestation(int idPrestation)
        {
            return AccesDonnees.GetLesConsommablePrestation(idPrestation);
        }
        /// <summary>
        /// Permet de récupérer un type consommable avec son libelle et son unité
        /// </summary>
        /// <param name="LeTypeConsommable">le libelle du type</param>
        /// <param name="UniteConsommable">l'unite du type</param>
        /// <returns>le type</returns>
        public TypeConsommable RecupUnTypeConsommable(string LeTypeConsommable, string UniteConsommable)
        {
            return AccesDonnees.RecupUnTypeConsommable(LeTypeConsommable, UniteConsommable);
        }
        /// <summary>
        /// Permet de récupérer un sous type de consommable
        /// </summary>
        /// <param name="IdTypeConsommable">id du type de consomamble</param>
        /// <param name="Libelle">son libelle</param>
        /// <returns>un sous type</returns>
        public SousTypeConsommable RecupUnSousTypeConsommable(int IdTypeConsommable, string Libelle)
        {
            return AccesDonnees.RecupUnSousTypeConsommable(IdTypeConsommable, Libelle);
        }
        #region Méthode/fonction d'ajout/modification/suppression
        /// <summary>
        /// Précédure d'ajout d'un adhérent
        /// </summary>
        /// <param name="nom">nom de l'adherent</param>
        /// <param name="prenom">prenom de l'adherent</param>
        /// <param name="telephone">telephone de l'adherent</param>
        /// <param name="email">email de l'adherent</param>
        /// <param name="dateNaissance">deta de naissance de l'adherent</param>
        public void AjoutAdherent(string nom, string prenom, string telephone, string email, DateTime dateNaissance)
        {
            AccesDonnees.AjoutAdherent(nom, prenom, telephone, email, dateNaissance);
            //return false;
        }
        public void AjoutNouvellePrestation(int idTypePrestation, int idAdherent, DateTime datePrestation, string libelle)
        {
            AccesDonnees.AjoutNouvellePrestation(idTypePrestation, idAdherent, datePrestation, libelle);
        }
        public Prestation RecupUnePrestation(int idAdherent, string datePrestation)
        {
            return AccesDonnees.RecupUnePrestation(idAdherent, datePrestation);
        }
        public void AjoutLignesPrestation(List<ConsommablePrestation> lesLignes)
        {
            AccesDonnees.AjoutLignesPrestation(lesLignes);
        }
        public void AjoutCredits(int idAdherent, DateTime dateRechargement, float montantCredit)
        {
            AccesDonnees.AjoutCredits(idAdherent, dateRechargement, montantCredit);
        }
        /// <summary>
        /// Permet d'ajouter un nouveau type de consommable
        /// </summary>
        /// <param name="unTypeConsommable">le consommable à ajouter</param>
        public void AjoutNewTypeConsommable(TypeConsommable unTypeConsommable)
        {
            AccesDonnees.AjoutNewTypeConsommable(unTypeConsommable);
        }
        /// <summary>
        /// Permet d'ajouter un type de prestation 
        /// </summary>
        /// <param name="libelle">le nom du nouveau type</param>
        public void AjouterUnTypePrestation(string libelle)
        {
            AccesDonnees.AjouterUnTypePrestation(libelle);
        }
        /// <summary>
        /// Permet d'ajouter un sous type de consommable
        /// </summary>
        /// <param name="unSousTypeConsommable">le sous type à ajouter</param>
        public void AjoutSousTypeConsommable(SousTypeConsommable unSousTypeConsommable)
        {
            AccesDonnees.AjoutSousTypeConsommable(unSousTypeConsommable);
        }
        /// <summary>
        /// Permet d'ajouter un consommable
        /// </summary>
        /// <param name="unConsommable">le consommable à ajouter</param>
        public void AjoutConsommable(Consommable unConsommable)
        {
            AccesDonnees.AjoutConsommable(unConsommable);
        }
        /// <summary>
        /// Permet de transmettre l'adherent à modifier
        /// </summary>
        /// <param name="unAdherent"></param>
        public void ModificationAdherent(Adherents unAdherent)
        {
            AccesDonnees.ModificationAdherent(unAdherent);
        }
        /// <summary>
        /// Permet de modifier le type prestation passé en paramétre
        /// </summary>
        /// <param name="unTypePrestation">le type de prestation modifié</param>
        public void ModifierUnTypePrestation(TypePrestation unTypePrestation)
        {
            AccesDonnees.ModifierUnTypePrestation(unTypePrestation);
        }
        /// <summary>
        /// Permet d'ajouter un consommable
        /// </summary>
        /// <param name="unConsommable">le consommable à modifier</param>
        public void ModificationConsommable(Consommable unConsommable)
        {
            AccesDonnees.ModificationConsommable(unConsommable);
        }
        /// <summary>
        /// Permet de supprimer une prestation avec l'id de la prestation
        /// </summary>
        /// <param name="idPrestationSelectionnee">id de la prestation</param>
        public void SuppressionPrestation(int idPrestationSelectionnee)
        {
            AccesDonnees.SuppressionPrestation(idPrestationSelectionnee);
        }
        /// <summary>
        /// Permet de supprimer un rechargement avec l'adherent et la date des paramètres
        /// </summary>
        /// <param name="idAdherent">l'adherent de la prestation</param>
        /// <param name="datePrestation">la date de la prestation</param>
        public void SuppressionRechargement(int idAdherent, string dateRechargement)
        {
            AccesDonnees.SuppressionRechargement(idAdherent, dateRechargement);
        }
        /// <summary>
        /// Permet de supprimer le type prestation passé en paramètre
        /// </summary>
        /// <param name="unTypePrestation">le type prestation à supprimer</param>
        public void SupprimerUnTypePrestation(TypePrestation unTypePrestation)
        {
            AccesDonnees.SupprimerUnTypePrestation(unTypePrestation);
        }
        /// <summary>
        /// Permet de supprimer un consommable
        /// </summary>
        /// <param name="unConsommable">le consommable à supprimer</param>
        public void SuppressionConsommable(Consommable unConsommable)
        {
            AccesDonnees.SuppressionConsommable(unConsommable);
        }
        #endregion
    }
}
