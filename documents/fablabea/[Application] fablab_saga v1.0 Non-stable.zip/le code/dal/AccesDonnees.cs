﻿using fablab_saga.connexion;
using fablab_saga.model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace fablab_saga.dal
{
    class AccesDonnees
    {
        #region Propriétés
        /// <summary>
        /// l'adresse du serveur
        /// </summary>
        //private static string adresseServeur = "127.0.0.1";
        private static string adresseServeur = "makotache.hopto.org";
        /// <summary>
        /// le nom de la base de données
        /// </summary>
        private static string nomBDD = "fablabsaga";
        /// <summary>
        /// le port de connexion
        /// </summary>
        //private static string port = "3306";
        private static string port = "8033";
        /// <summary>
        /// la chaine de connexion pas encore instancié
        /// </summary>
        private static string chaineConnexion;
        #endregion
        #region Préparatif connexion
        /// <summary>
        /// permet de construire le chaine de connexion avec les identifiants de connexion reçu en paramètres
        /// </summary>
        /// <param name="identifiant"></param>
        /// <param name="pwd"></param>
        public static bool Authentification(string identifiant, string pwd)
        {
            chaineConnexion = "Server=" + adresseServeur + "; Port=" + port + "; user id=" + identifiant + ";password=" + pwd + "; " +
                "persistsecurityinfo=True; database=" + nomBDD + ";SSL Mode=None";
            ConnexionBDD bdd = ConnexionBDD.getInstance(chaineConnexion);
            return bdd.IsRuning();
        }
        /// <summary>
        /// Permet de réinitialisé la chaine de connexion
        /// </summary>
        public static void Deconnexion()
        {
            ConnexionBDD.CloseConnection();
        }
        #endregion
        #region Requetes de récupération
        /// <summary>
        /// Évenement de récupération des adhérents
        /// </summary>
        /// <returns>la liste des adherents</returns>
        public static List<Adherents> GetLesAdherents()
        {
            List<Adherents> lesAdherents = new List<Adherents>();
            ConnexionBDD bdd = ConnexionBDD.getInstance(chaineConnexion);
            Dictionary<string, object> parameters = new Dictionary<string, object>();
            bdd.ReqSelect("SELECT * FROM adherent order by NOM;", parameters);
            while (bdd.Read())
            {
                lesAdherents.Add(new Adherents(int.Parse(bdd.Field("IDADHERENT").ToString()), (string)bdd.Field("NOM"), (string)bdd.Field("PRENOM"),
                    (string)bdd.Field("TELEPHONE"), (string)bdd.Field("EMAIL"), (DateTime)bdd.Field("DATENAISSANCE"), (float)bdd.Field("MONTANTCREDITS"),
                    (DateTime)bdd.Field("DATE_OUVERTURE_ABONNEMENT"), (DateTime)bdd.Field("DATE_FIN_ABONNEMENT")));
            }
            bdd.close();
            return lesAdherents;
        }
        /// <summary>
        /// Évenement de récupération des TypePrestation
        /// </summary>
        /// <returns>la liste des TypePrestation</returns>
        public static List<TypePrestation> GetLesTypesPrestations()
        {
            List<TypePrestation> lesTypesPrestations = new List<TypePrestation>();
            ConnexionBDD bdd = ConnexionBDD.getInstance(chaineConnexion);
            Dictionary<string, object> parameters = new Dictionary<string, object>();
            bdd.ReqSelect("SELECT * FROM typeprestation;", parameters);
            while (bdd.Read())
            {
                lesTypesPrestations.Add(new TypePrestation(int.Parse(bdd.Field("IDTYPEPRESTATION").ToString()), (string)bdd.Field("NOMPRESTATION")));
            }
            bdd.close();
            return lesTypesPrestations;
        }
        /// <summary>
        /// Évenement de récupération des TypeConsommable
        /// </summary>
        /// <returns>la liste des TypeConsommable</returns>
        public static List<TypeConsommable> GetLesTypesConsommables()
        {
            List<TypeConsommable> lesTypesConsommables = new List<TypeConsommable>();
            ConnexionBDD bdd = ConnexionBDD.getInstance(chaineConnexion);
            Dictionary<string, object> parameters = new Dictionary<string, object>();
            bdd.ReqSelect("SELECT * FROM typeconsommable;", parameters);
            while (bdd.Read())
            {
                lesTypesConsommables.Add(new TypeConsommable(int.Parse(bdd.Field("IDTYPECONSOMMABLE").ToString()), (string)bdd.Field("TYPE"), (string)bdd.Field("UNITE")));
            }
            bdd.close();
            return lesTypesConsommables;
        }
        /// <summary>
        /// Évenement de récupération des SousTypeConsommable
        /// </summary>
        /// <returns>la listedes SousTypeConsommable</returns>
        public static List<SousTypeConsommable> GetLesSousTypesConsommables()
        {
            List<SousTypeConsommable> lesSousTypesConsommables = new List<SousTypeConsommable>();
            ConnexionBDD bdd = ConnexionBDD.getInstance(chaineConnexion);
            Dictionary<string, object> parameters = new Dictionary<string, object>();
            bdd.ReqSelect("SELECT * FROM sous_type_consommable;", parameters);
            while (bdd.Read())
            {
                lesSousTypesConsommables.Add(new SousTypeConsommable(int.Parse(bdd.Field("IDSOUSTYPECONSOMMABLE").ToString()), int.Parse(bdd.Field("IDTYPECONSOMMABLE").ToString()), (string)bdd.Field("LIBELLE")));
            }
            bdd.close();
            return lesSousTypesConsommables;
        }
        /// <summary>
        /// Évenement de récupération des Consommable
        /// </summary>
        /// <returns>le liste des Consommable</returns>
        public static List<Consommable> GetLesConsommables()
        {
            List<Consommable> lesConsommables = new List<Consommable>();
            ConnexionBDD bdd = ConnexionBDD.getInstance(chaineConnexion);
            Dictionary<string, object> parameters = new Dictionary<string, object>();
            bdd.ReqSelect("SELECT * FROM consommable;", parameters);
            while (bdd.Read())
            {
                lesConsommables.Add(new Consommable(int.Parse(bdd.Field("IDCONSOMMABLE").ToString()), (int.Parse(bdd.Field("IDTYPECONSOMMABLE").ToString())), 
                    (int.Parse(bdd.Field("IDSOUSTYPECONSOMMABLE").ToString())), (string)bdd.Field("LIBELLE"), (float)bdd.Field("PRIX")));
            }
            bdd.close();
            return lesConsommables;
        }
        /// <summary>
        /// Permet de récupérer et d'envoyer les rechargements d'un adherent
        /// </summary>
        /// <param name="idAdherent"></param>
        /// <returns></returns>
        public static List<Object> GetLesRechargements(int idAdherent, string dateTrie)
        {
            List<Object> lesRechargements = new List<Object>();
            ConnexionBDD bdd = ConnexionBDD.getInstance(chaineConnexion);
            Dictionary<string, object> parameters = new Dictionary<string, object>();
            parameters.Add("@idAdherent", idAdherent);
            parameters.Add("@dateTrie", dateTrie);
            bdd.ReqSelect("SELECT * FROM rechargement where IDADHERENT = @idAdherent AND DATE >= @dateTrie;", parameters);
            while (bdd.Read())
            {
                lesRechargements.Add(new Rechargement(int.Parse(bdd.Field("IDADHERENT").ToString()), (DateTime)bdd.Field("DATE"),
                    float.Parse(bdd.Field("NBCREDIT").ToString())));
            }
            bdd.close();
            return lesRechargements;
        }
        /// <summary>
        /// Permet de récupérer et d'envoyer les prestations d'un adherent
        /// </summary>
        /// <param name="idAdherent"></param>
        /// <returns>liste des prestations</returns>
        public static List<Object> GetLesPrestations(int idAdherent, string dateTrie)
        {
            List<Object> lesPrestations = new List<Object>();
            ConnexionBDD bdd = ConnexionBDD.getInstance(chaineConnexion);
            Dictionary<string, object> parameters = new Dictionary<string, object>();
            parameters.Add("@idAdherent", idAdherent);
            parameters.Add("@dateTrie", dateTrie);
            bdd.ReqSelect("SELECT * FROM prestation where IDADHERENT = @idAdherent AND DATE >= @dateTrie;", parameters);
            while (bdd.Read())
            {
                lesPrestations.Add(new Prestation(int.Parse(bdd.Field("IDPRESTATION").ToString()), int.Parse(bdd.Field("IDTYPEPRESTATION").ToString()), 
                    int.Parse(bdd.Field("IDADHERENT").ToString()), (DateTime)bdd.Field("DATE"), float.Parse(bdd.Field("MONTANTTOTAL").ToString()), 
                    bdd.Field("LIBELLE").ToString()));
            }
            bdd.close();
            return lesPrestations;
        }
        /// <summary>
        /// Permet de retourner sur l'id en paramètre exite dans la table en paremètre
        /// </summary>
        /// <param name="tableBdd">table de la base de données</param>
        /// <param name="idAVerifier">id à vrifier</param>
        /// <param name="nomId">nom de l'id</param>
        /// <returns>retourne la présence ou non de l'id</returns>
        public static bool RecupIDTableBdd(string tableBdd, int idAVerifier, string nomId)
        {
            List<int> lesid = new List<int>();
            ConnexionBDD bdd = ConnexionBDD.getInstance(chaineConnexion);
            Dictionary<string, object> parameters = new Dictionary<string, object>();
            parameters.Add("@idAVerifier", idAVerifier);
            bdd.ReqSelect("SELECT * FROM "+ tableBdd +" WHERE " + nomId + " = @idAVerifier;", parameters);
            if(bdd.Read())
            {
                bdd.close();
                return true;
            }
            bdd.close();
            return false;
        }
        /// <summary>
        /// Permet de récupérer et d'envoyer les consommables d'une prestation
        /// </summary>
        /// <param name="idPrestation"></param>
        /// <returns></returns>
        public static List<ConsommablePrestation> GetLesConsommablePrestation(int idPrestation)
        {
            List<ConsommablePrestation> lesConsommablesPrestations = new List<ConsommablePrestation>();
            ConnexionBDD bdd = ConnexionBDD.getInstance(chaineConnexion);
            Dictionary<string, object> parameters = new Dictionary<string, object>();
            parameters.Add("@idPrestation", idPrestation);
            bdd.ReqSelect("SELECT * FROM consommable_prestation where IDPRESTATION = @idPrestation;", parameters);
            while (bdd.Read())
            {
                lesConsommablesPrestations.Add(new ConsommablePrestation(int.Parse(bdd.Field("IDPRESTATION").ToString()), int.Parse(bdd.Field("IDCONSOMMABLE").ToString()),
                    bdd.Field("LIBELLE").ToString(), float.Parse(bdd.Field("QUANTITE").ToString()), float.Parse(bdd.Field("MONTANT").ToString())));
            }
            bdd.close();
            return lesConsommablesPrestations;
        }
        /// <summary>
        /// Permet de récupérer une prestation en particulier
        /// </summary>
        /// <param name="idAdherent">l'idAdherent de la prestation</param>
        /// <param name="datePrestation">la datePrestation de la prestation</param>
        /// <returns>la prestation rechercher</returns>
        public static Prestation RecupUnePrestation(int idAdherent, string datePrestation)
        {
            Prestation unePrestation = null;
            ConnexionBDD bdd = ConnexionBDD.getInstance(chaineConnexion);
            Dictionary<string, object> parameters = new Dictionary<string, object>();
            parameters.Add("@idAdherent", idAdherent);
            parameters.Add("@datePrestation", datePrestation);
            bdd.ReqSelect("SELECT * FROM prestation WHERE IDADHERENT = @idAdherent AND DATE = @datePrestation;", parameters);
            while (bdd.Read())
            {
                unePrestation = new Prestation(int.Parse(bdd.Field("IDPRESTATION").ToString()), (int.Parse(bdd.Field("IDTYPEPRESTATION").ToString())),
                    (int.Parse(bdd.Field("IDADHERENT").ToString())), (DateTime)bdd.Field("DATE"), (float)bdd.Field("MONTANTTOTAL"), (string)bdd.Field("LIBELLE"));
            }
            bdd.close();
            return unePrestation;
        }
        /// <summary>
        /// Permet de récupérer un adherent avec sont ID
        /// </summary>
        /// <param name="idAdherent">l'idadherent de l'adherent recherché</param>
        /// <returns>l'adherent recherché</returns>
        public static Adherents RecupUnAdherent(int idAdherent)
        {
            Adherents unAdherent = null;
            ConnexionBDD bdd = ConnexionBDD.getInstance(chaineConnexion);
            Dictionary<string, object> parameters = new Dictionary<string, object>();
            parameters.Add("@idAdherent", idAdherent);
            bdd.ReqSelect("SELECT * FROM adherent WHERE IDADHERENT = @idAdherent;", parameters);
            while (bdd.Read())
            {
                unAdherent = new Adherents(int.Parse(bdd.Field("IDADHERENT").ToString()), (string)bdd.Field("NOM"), (string)bdd.Field("PRENOM"),
                    (string)bdd.Field("TELEPHONE"), (string)bdd.Field("EMAIL"), (DateTime)bdd.Field("DATENAISSANCE"), (float)bdd.Field("MONTANTCREDITS"),
                    (DateTime)bdd.Field("DATE_OUVERTURE_ABONNEMENT"), (DateTime)bdd.Field("DATE_FIN_ABONNEMENT"));
            }
            bdd.close();
            return unAdherent;
        }
        /// <summary>
        /// Permet de récupérer un type consommable avec son libelle et son unité
        /// </summary>
        /// <param name="LeTypeConsommable">le libelle du type</param>
        /// <param name="UniteConsommable">l'unite du type</param>
        /// <returns>le type</returns>
        public static TypeConsommable RecupUnTypeConsommable(string LeTypeConsommable, string UniteConsommable)
        {
            TypeConsommable unTypeConsommable = null;
            ConnexionBDD bdd = ConnexionBDD.getInstance(chaineConnexion);
            Dictionary<string, object> parameters = new Dictionary<string, object>();
            parameters.Add("@libelle", LeTypeConsommable);
            parameters.Add("@unite", UniteConsommable);
            bdd.ReqSelect("SELECT * FROM typeconsommable WHERE TYPE = @libelle AND UNITE = @unite;", parameters);
            while (bdd.Read())
            {
                unTypeConsommable = new TypeConsommable(int.Parse(bdd.Field("IDTYPECONSOMMABLE").ToString()), (string)bdd.Field("TYPE"), (string)bdd.Field("UNITE"));
            }
            bdd.close();
            return unTypeConsommable;
        }
        /// <summary>
        /// Permet de récupérer un sous type de consommable
        /// </summary>
        /// <param name="IdTypeConsommable">id du type de consomamble</param>
        /// <param name="Libelle">son libelle</param>
        /// <returns>un sous type</returns>
        public static SousTypeConsommable RecupUnSousTypeConsommable(int IdTypeConsommable, string Libelle)
        {
            SousTypeConsommable unSousTypeConsommable = null;
            ConnexionBDD bdd = ConnexionBDD.getInstance(chaineConnexion);
            Dictionary<string, object> parameters = new Dictionary<string, object>();
            parameters.Add("@idType", IdTypeConsommable);
            parameters.Add("@libelle", Libelle);
            bdd.ReqSelect("SELECT * FROM sous_type_consommable WHERE IDTYPECONSOMMABLE = @idType AND LIBELLE = @libelle;", parameters);
            while (bdd.Read())
            {
                unSousTypeConsommable = new SousTypeConsommable(int.Parse(bdd.Field("IDSOUSTYPECONSOMMABLE").ToString()), int.Parse(bdd.Field("IDTYPECONSOMMABLE").ToString()), (string)bdd.Field("UNITE"));
            }
            bdd.close();
            return unSousTypeConsommable;
        }
        #endregion
        /// <summary>
        /// Évenement d'ajout d'un nouvel adherent
        /// </summary>
        /// <param name="nom">nom de l'adherent</param>
        /// <param name="prenom">prenom de l'adherent</param>
        /// <param name="telephone">telephone de l'adherent</param>
        /// <param name="email">email de l'adherent</param>
        /// <param name="dateNaissance">deta de naissance de l'adherent</param>
        public static void AjoutAdherent(string nom, string prenom, string telephone, string email, DateTime dateNaissance)
        {
            ConnexionBDD bdd = ConnexionBDD.getInstance(chaineConnexion);
            Dictionary<string, object> parameters = new Dictionary<string, object>();
            parameters.Add("@nom", nom);
            parameters.Add("@prenom", prenom);
            parameters.Add("@telephone", telephone);
            parameters.Add("@email", email);
            parameters.Add("@dateNaissance", dateNaissance);
            bdd.ReqUpdate("insert into adherent (NOM, PRENOM, TELEPHONE, EMAIL, DATENAISSANCE) " +
                "VALUES (@nom, @prenom, @telephone, @email, @dateNaissance);", parameters);
        }
        
        /// <summary>
        /// Permet d'ajouter une prestation
        /// </summary>
        /// <param name="idTypePrestation">l'idTypePrestation à ajouter</param>
        /// <param name="idAdherent">l'idAdherent à ajouter</param>
        /// <param name="datePrestation">la datePrestation à ajouter</param>
        /// <param name="libelle">le libellé à ajouter</param>
        public static void AjoutNouvellePrestation(int idTypePrestation, int idAdherent, DateTime datePrestation, string libelle)
        {
            ConnexionBDD bdd = ConnexionBDD.getInstance(chaineConnexion);
            Dictionary<string, object> parameters = new Dictionary<string, object>();
            parameters.Add("@idTypePrestation", idTypePrestation);
            parameters.Add("@idAdherent", idAdherent);
            parameters.Add("@datePrestation", datePrestation);
            parameters.Add("@libelle", libelle);
            bdd.ReqUpdate("insert into prestation (IDTYPEPRESTATION, IDADHERENT, DATE, LIBELLE) " +
                "VALUES (@idTypePrestation, @idAdherent, @datePrestation, @libelle);", parameters);
            bdd.close();
        }
        
        /// <summary>
        /// Permet d'ajouter une ligne à une prestation définie
        /// </summary>
        /// <param name="lesLignes">les lignes à ajouter</param>
        public static void AjoutLignesPrestation(List<ConsommablePrestation> lesLignes)
        {
            ConnexionBDD bdd = ConnexionBDD.getInstance(chaineConnexion);
            for(int i = 0; i < lesLignes.Count; i++)
            {
                Dictionary<string, object> parameters = new Dictionary<string, object>();
                parameters.Add("@idPrestation", lesLignes[i].IdPrestation);
                parameters.Add("@idConsommable", lesLignes[i].IdConsommable);
                parameters.Add("@libelle", lesLignes[i].Libelle);
                parameters.Add("@quantite", lesLignes[i].QuantiteConsommable);
                bdd.ReqUpdate("insert into consommable_prestation (IDPRESTATION, IDCONSOMMABLE, LIBELLE, QUANTITE) " +
                    "VALUES (@idPrestation, @idConsommable, @libelle, @quantite);", parameters);
            }
            bdd.close();
        }
        /// <summary>
        /// Permet d'ajouter un rechargement à une adherent défini
        /// </summary>
        /// <param name="idAdherent"></param>
        /// <param name="dateRechargement"></param>
        /// <param name="montantCredit"></param>
        public static void AjoutCredits(int idAdherent, DateTime dateRechargement, float montantCredit)
        {
            ConnexionBDD bdd = ConnexionBDD.getInstance(chaineConnexion);
            Dictionary<string, object> parameters = new Dictionary<string, object>();
            parameters.Add("@idAdherent", idAdherent);
            parameters.Add("@dateRechargement", dateRechargement);
            parameters.Add("@montantCredits", montantCredit);
            bdd.ReqUpdate("insert into rechargement (IDADHERENT, DATE, NBCREDIT) " +
                "VALUES (@idAdherent, @dateRechargement, @montantCredits);", parameters);
            bdd.close();
        }
        /// <summary>
        /// Permet d'ajouter un type de prestation 
        /// </summary>
        /// <param name="libelle">le nom du nouveau type</param>
        public static void AjouterUnTypePrestation(string libelle)
        {
            ConnexionBDD bdd = ConnexionBDD.getInstance(chaineConnexion);
            Dictionary<string, object> parameters = new Dictionary<string, object>();
            parameters.Add("@libelle", libelle);
            bdd.ReqUpdate("insert into typeprestation (NOMPRESTATION) VALUES (@libelle);", parameters);
            bdd.close();
        }
        /// <summary>
        /// Permet d'ajouter un nouveau type de consommable
        /// </summary>
        /// <param name="unTypeConsommable">le consommable à ajouter</param>
        public static void AjoutNewTypeConsommable(TypeConsommable unTypeConsommable)
        {
            ConnexionBDD bdd = ConnexionBDD.getInstance(chaineConnexion);
            Dictionary<string, object> parameters = new Dictionary<string, object>();
            parameters.Add("@libelle", unTypeConsommable.LeTypeConsommable);
            parameters.Add("@unite", unTypeConsommable.UniteConsommable);
            bdd.ReqUpdate("insert into typeconsommable (TYPE, UNITE) VALUES (@libelle, @unite);", parameters);
            bdd.close();
        }
        /// <summary>
        /// Permet d'ajouter un sous type de consommable
        /// </summary>
        /// <param name="unSousTypeConsommable">le sous type à ajouter</param>
        public static void AjoutSousTypeConsommable(SousTypeConsommable unSousTypeConsommable)
        {
            ConnexionBDD bdd = ConnexionBDD.getInstance(chaineConnexion);
            Dictionary<string, object> parameters = new Dictionary<string, object>();
            parameters.Add("@idTypeConsommable", unSousTypeConsommable.IdTypeConsommable);
            parameters.Add("@libelle", unSousTypeConsommable.Libelle);
            bdd.ReqUpdate("insert into sous_type_consommable (IDTYPECONSOMMABLE, LIBELLE) VALUES (@idTypeConsommable, @libelle);", parameters);
            bdd.close();
        }
        /// <summary>
        /// Permet d'ajouter un consommable
        /// </summary>
        /// <param name="unConsommable">le consommable à ajouter</param>
        public static void AjoutConsommable(Consommable unConsommable)
        {
            ConnexionBDD bdd = ConnexionBDD.getInstance(chaineConnexion);
            Dictionary<string, object> parameters = new Dictionary<string, object>();
            parameters.Add("@idTypeConsommable", unConsommable.IdTypeConsommable);
            parameters.Add("@idSousTypeConsommable", unConsommable.IdSousTypeConsommable);
            parameters.Add("@libelle", unConsommable.LibelleConsommable);
            parameters.Add("@prix", unConsommable.PrixConsommable);
            bdd.ReqUpdate("insert into consommable (IDTYPECONSOMMABLE, IDSOUSTYPECONSOMMABLE, LIBELLE, PRIX) VALUES (@idTypeConsommable, @idSousTypeConsommable, @libelle, @prix);", parameters);
            bdd.close();
        }
        /// <summary>
        /// Évenement de modification d'un adherent
        /// </summary>
        /// <param name="unAdherent">l'adherent à modifier</param>
        public static void ModificationAdherent(Adherents unAdherent)
        {
            ConnexionBDD bdd = ConnexionBDD.getInstance(chaineConnexion);
            Dictionary<string, object> parameters = new Dictionary<string, object>();
            parameters.Add("@idAdherent", unAdherent.IdAdherent);
            parameters.Add("@nom", unAdherent.NomAdherent);
            parameters.Add("@prenom", unAdherent.PrenomAdherent);
            parameters.Add("@telephone", unAdherent.TelAdherent);
            parameters.Add("@email", unAdherent.EmailAdherent);
            parameters.Add("@dateNaissance", unAdherent.DateNaissanceAdherent);
            parameters.Add("@montantCredits", unAdherent.MontantCreditsAdherent);
            parameters.Add("@dateOuvertureAbonnement", unAdherent.DateOuvertureAbonnement);
            parameters.Add("@dateFinAbonnement", unAdherent.DateFinAbonnement);
            bdd.ReqUpdate("UPDATE adherent set NOM = @nom, PRENOM = @prenom, TELEPHONE = @telephone, EMAIL = @email, " +
                "DATENAISSANCE = @dateNaissance, MONTANTCREDITS = @montantCredits, DATE_OUVERTURE_ABONNEMENT = @dateOuvertureAbonnement, " +
                "DATE_FIN_ABONNEMENT = @dateFinAbonnement where IDADHERENT = @idAdherent;", parameters);
            bdd.close();
        }
        /// <summary>
        /// Permet de modifier le type prestation passé en paramètre
        /// </summary>
        /// <param name="unTypePrestation">le type de prestation modifié</param>
        public static void ModifierUnTypePrestation(TypePrestation unTypePrestation)
        {
            ConnexionBDD bdd = ConnexionBDD.getInstance(chaineConnexion);
            Dictionary<string, object> parameters = new Dictionary<string, object>();
            parameters.Add("@idTypePrestation", unTypePrestation.IdTypePrestation);
            parameters.Add("@nom", unTypePrestation.NomPrestation);
            bdd.ReqUpdate("UPDATE typeprestation set NOMPRESTATION = @nom WHERE IDTYPEPRESTATION = @idTypePrestation;", parameters);
            bdd.close();
        }
        /// <summary>
        /// Permet d'ajouter un consommable
        /// </summary>
        /// <param name="unConsommable">le consommable à modifier</param>
        public static void ModificationConsommable(Consommable unConsommable)
        {
            ConnexionBDD bdd = ConnexionBDD.getInstance(chaineConnexion);
            Dictionary<string, object> parameters = new Dictionary<string, object>();
            parameters.Add("@idConsommable", unConsommable.IdConsommable);
            parameters.Add("@idTypeConsommable", unConsommable.IdTypeConsommable);
            parameters.Add("@idSousTypeConsommable", unConsommable.IdSousTypeConsommable);
            parameters.Add("@libelle", unConsommable.LibelleConsommable);
            parameters.Add("@prix", unConsommable.PrixConsommable);
            bdd.ReqUpdate("UPDATE consommable set IDTYPECONSOMMABLE = @idTypeConsommable, IDSOUSTYPECONSOMMABLE = @idSousTypeConsommable, " +
                "LIBELLE = @libelle, PRIX = @prix WHERE IDCONSOMMABLE = @idConsommable;", parameters);
            bdd.close();
        }
        /// <summary>
        /// Permet de supprimer une prestation avec l'adherent et la date des paramètres
        /// </summary>
        /// <param name="idAdherent">l'adherent de la prestation</param>
        /// <param name="datePrestation">la date de la prestation</param>
        public static void SuppressionPrestation(int idPrestationSelectionnee)
        {
            ConnexionBDD bdd = ConnexionBDD.getInstance(chaineConnexion);
            Dictionary<string, object> parameters = new Dictionary<string, object>();
            parameters.Add("@idPrestationSelectionnee", idPrestationSelectionnee);
            bdd.ReqUpdate("DELETE FROM prestation WHERE IDPRESTATION = @idPrestationSelectionnee;", parameters);
            bdd.ReqUpdate("DELETE FROM consommable_prestation WHERE IDPRESTATION = @idPrestationSelectionnee;", parameters);
            bdd.close();
        }
        /// <summary>
        /// Permet de supprimer un rechargement avec l'adherent et la date des paramètres
        /// </summary>
        /// <param name="idAdherent">l'adherent de la prestation</param>
        /// <param name="datePrestation">la date de la prestation</param>
        public static void SuppressionRechargement(int idAdherent, string dateRechargement)
        {
            ConnexionBDD bdd = ConnexionBDD.getInstance(chaineConnexion);
            Dictionary<string, object> parameters = new Dictionary<string, object>();
            parameters.Add("@idAdherent", idAdherent);
            parameters.Add("@dateRechargement", dateRechargement);
            bdd.ReqUpdate("DELETE FROM rechargement WHERE IDADHERENT = @idAdherent AND DATE = @dateRechargement;", parameters);
            bdd.close();
        }
        /// <summary>
        /// Permet de supprimer le type prestation passé en paramètre
        /// </summary>
        /// <param name="unTypePrestation">le type prestation à supprimer</param>
        public static void SupprimerUnTypePrestation(TypePrestation unTypePrestation)
        {
            ConnexionBDD bdd = ConnexionBDD.getInstance(chaineConnexion);
            Dictionary<string, object> parameters = new Dictionary<string, object>();
            parameters.Add("@idTypePrestation", unTypePrestation.IdTypePrestation);
            bdd.ReqUpdate("DELETE FROM typeprestation WHERE IDTYPEPRESTATION = @idTypePrestation;", parameters);
            bdd.close();
        }
        /// <summary>
        /// Permet de supprimer un consommable
        /// </summary>
        /// <param name="unConsommable">le consommable à supprimer</param>
        public static void SuppressionConsommable(Consommable unConsommable)
        {
            ConnexionBDD bdd = ConnexionBDD.getInstance(chaineConnexion);
            Dictionary<string, object> parameters = new Dictionary<string, object>();
            parameters.Add("@idConsommable", unConsommable.IdConsommable);
            bdd.ReqUpdate("DELETE FROM consommable WHERE IDCONSOMMABLE = @idConsommable;", parameters);
            bdd.close();
        }

    }
}
